import urllib.request
import re

page_urls = [
    ("https://ibb.co/Xrgy3b1R", "Bolalar honasi uchun ajoyib yechim."),
    ("https://ibb.co/RGZWRVw5", "Dikey jaluzi"),
    ("https://ibb.co/M574dLHJ", "Eco Jaluz bilan tanishing"),
    ("https://ibb.co/KcBtwLSX", "Jaluz tanlash bo'yicha maslahat"),
    ("https://ibb.co/SXf30VkD", "Rolo jaluzi"),
    ("https://ibb.co/gbvVH2DK", "Oshxona uchun mukammal variant"),
    ("https://ibb.co/S7rtYZQB", "Quyosh nuridan himoya"),
    ("https://ibb.co/cKSptPbC", "Mahsulotlarimiz sifati va kafolati")
]

lines = []
for page_url, title in page_urls:
    try:
        req = urllib.request.Request(page_url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
        html = urllib.request.urlopen(req).read().decode("utf-8")
        og = re.findall(r'property="og:image" content="([^"]+)"', html)
        lines.append(f"TITLE: {title} | OG: {og}\n")
    except Exception as e:
        lines.append(f"TITLE: {title} | ERROR: {e}\n")

with open("og_out.txt", "w") as f:
    f.writelines(lines)
print("WRITE DONE")

import { Product, PortfolioProject, ProcessStep, Order, ConsultationRequest, AdminConfig } from '../types';
import { DIKEY_GALLERY_PROJECTS } from '../data/dikeyGallery';
import { PLISSE_GALLERY_PROJECTS } from '../data/plisseGallery';
import { PRINT_GALLERY_PROJECTS } from '../data/printGallery';
import { COMBO_GALLERY_PROJECTS } from '../data/comboGallery';
import { ROLLO_GALLERY_PROJECTS } from '../data/rolloGallery';
import { ALYUMIN_GALLERY_PROJECTS } from '../data/alyuminGallery';
import { WOOD_GALLERY_PROJECTS } from '../data/woodGallery';

const PRODUCTS_KEY = 'eco_jaluzi_products_v48';
const PROJECTS_KEY = 'eco_jaluzi_projects_v56';
const PROCESS_KEY = 'eco_jaluzi_process_v1';
const ORDERS_KEY = 'eco_jaluzi_orders';
const CONSULTATIONS_KEY = 'eco_jaluzi_consultations';
const CONFIG_KEY = 'eco_jaluzi_config_v5';

// Pre-seeded high-quality products (1-KATALOG: MAHSULOTLAR VA MATOLAR KATALOGI)
const defaultProducts: Product[] = [
  {
    id: 'prod-item-1',
    name: 'Klassik Bej va Shokolad Kun-Tun Combo Jaluzi',
    description: 'Zamonaviy xonadonlar va kottejlar uchun kun-tun rejimida yorug‘likni nafis boshqaruvchi premium Combo jaluzi matosi.',
    material: 'Zich tolali chang va quyosh qaytaruvchi antistatik poliester',
    availableColors: ['Klassik bej', 'Shokolad', 'Oq marvarid', 'Krem', 'Kulrang'],
    pricePerSqm: 165000,
    image: 'https://i.ibb.co/7FsgN8t/photo-2025-10-11-10-42-24-3.jpg',
    category: 'Combo jaluzi',
    benefits: ['Kun va tun rejimini 1 harakatda sozlash', 'Turkiya va Yevropa original matosi', '100% chang va quyoshdan himoya'],
    installationInfo: 'Deraza ochiladigan qanotiga yoki romiga zich o‘rnatiladi.'
  },
  {
    id: 'prod-item-2',
    name: 'Oltin Qum va Krem Nafis Combo Jaluzi',
    description: 'Yorug‘likni xonaga muloyim va iliq taratuvchi, relyefli chiziqlarga ega eksklyuziv Combo tizimi.',
    material: 'Relyefli yorug‘lik qaytaruvchi jakkard Combo to‘qimasi',
    availableColors: ['Oltin qum', 'Sutli krem', 'Shampan', 'Bej', 'Oq'],
    pricePerSqm: 175000,
    image: 'https://i.ibb.co/qqSg1BH/photo-2025-10-11-10-42-24-2.jpg',
    category: 'Combo jaluzi',
    benefits: ['O‘zgacha jozibali nafis rang', 'Quyosh nurini yumshatuvchi tekstura', 'Oson tozalash va parvarishlash'],
    installationInfo: 'Shiftga, devorga yoki oyna romiga o‘rnatiladi.'
  },
  {
    id: 'prod-item-3',
    name: '100% Blackout Marvarid Roller (Rulonli) Parda',
    description: 'Yotoqxona va kinozallar uchun mo‘ljallangan, xonani 100% qorong‘ulashtiruvchi va issiqlikni to‘suvchi maxsus rolik parda.',
    material: '3 qavatli Germaniya Blackout termo-himoyali matosi',
    availableColors: ['Oq marvarid', 'Grafit', 'Och kulrang', 'Qora mat', 'To‘q bej'],
    pricePerSqm: 160000,
    image: 'https://i.ibb.co/jPy831TT/photo-2025-10-11-10-42-24.jpg',
    category: 'Roller jaluzi',
    benefits: ['100% to‘liq qorong‘ulik kafolati', 'Yozda xonani salqin saqlaydi', 'Silliq va shovqinsiz boshqaruv'],
    installationInfo: 'Oyna romiga yoki deraza ochilish tuynugiga o‘rnatiladi.'
  },
  {
    id: 'prod-item-4',
    name: 'Zamonaviy Mehmonxona Uchun Dikey Pardalar',
    description: 'Keng panoramali oynalar va baland zallar uchun vertikal to‘kiluvchi, saroyona burmali Dikey pardalar.',
    material: 'Zich tolali antistatik vertikal lamel to‘qimasi',
    availableColors: ['Oq', 'Krem', 'Klassik bej', 'Och kulrang', 'Zumrad'],
    pricePerSqm: 195000,
    image: 'https://i.ibb.co/CKJYZChS/photo-2026-02-27-10-40-40.jpg',
    category: 'Dikey pardalar',
    benefits: ['Saroyona vertikal burmalar', '180 gradusga buriluvchi lamellar', 'Yuvish va parvarish qilish oson'],
    installationInfo: 'Shiftga yoki devor kranisiga montaj qilinadi.'
  },
  {
    id: 'prod-item-5',
    name: 'Tabiiy Eko Bambuk Shol Jaluzi',
    description: '100% tabiiy va ekologik toza bambuk tolalari to‘qilmasidan ishlangan, sharqona shinamlik baxsh etuvchi parda.',
    material: '100% Tabiiy ishlov berilgan bambuk va qamish tolalari',
    availableColors: ['Tabiiy karamel', 'Och qum', 'To‘q yong‘oq', 'Zaytun'],
    pricePerSqm: 220000,
    image: 'https://i.ibb.co/WNK0MQ4C/photo-2026-02-27-10-41-13.jpg',
    category: 'Bambuk jaluzi',
    benefits: ['100% ekologik tabiiy mahsulot', 'Shinam va sokin atmosfera yaratadi', 'Uzoq yillar shaklini yo‘qotmaydi'],
    installationInfo: 'Kottej, ayvon, oshxona va dam olish xonalari uchun ideal.'
  },
  {
    id: 'prod-item-6',
    name: 'Akkordeon Plisse 20mm Oyna Romi Jaluzisi',
    description: 'Oyna ochilganda xalaqit bermaydigan, pastdan yuqoriga va yuqoridan pastga erkin ochiluvchi nafis Plisse tizimi.',
    material: 'Antistatik chang qaytaruvchi elastik gofre mato',
    availableColors: ['Oq', 'Och bej', 'Grafit', 'Sutli krem', 'Muz rang'],
    pricePerSqm: 190000,
    image: 'https://i.ibb.co/LzLSSy34/photo-2024-09-06-12-32-16-2.jpg',
    category: 'Plisse jaluzi',
    benefits: ['2 tomonlama (tepadan va pastdan) boshqaruv', 'Plastik oyna romiga zich fiksatsiya', 'Chang va kirlanishdan himoyalangan'],
    installationInfo: 'Oyna qanoti rezinalari orasiga ixcham o‘rnatiladi.'
  },
  {
    id: 'prod-item-7',
    name: 'Premium Yotoqxona Combo Kun-Tun Tizimi',
    description: 'Zich va shaffof chiziqlari bir-birini qoplaganda xonaga yorug‘likni to‘liq to‘suvchi zamonaviy Combo tizimi.',
    material: 'Yevropa sertifikatlangan zich tolali poliester',
    availableColors: ['Grafit', 'Klassik bej', 'Shokolad', 'Oq', 'Antratsit'],
    pricePerSqm: 170000,
    image: 'https://i.ibb.co/ZRjqVvJL/photo-2024-09-06-12-32-16.jpg',
    category: 'Combo jaluzi',
    benefits: ['Kun-tun yorug‘lik nazorati', 'Mustahkam kassetali boshqaruv', 'Uzoq xizmat muddati'],
    installationInfo: 'Deraza qanotiga yoki teshigiga o‘rnatiladi.'
  },
  {
    id: 'prod-item-8',
    name: 'Ofis va Kabinet Alyumin Gorizontal Jaluzisi',
    description: 'Namlikka, quyoshga va harorat o‘zgarishiga 100% chidamli, oson tozalanuvchi 25mm alyuminiy gorizontal jaluzi.',
    material: '25mm yuqori sifatli qattiq alyuminiy qotishmasi',
    availableColors: ['Kumush metallik', 'Oq mat', 'Bej', 'Kulrang', 'Antratsit'],
    pricePerSqm: 140000,
    image: 'https://i.ibb.co/23VRwLSy/photo-2024-09-06-12-32-17.jpg',
    category: 'Alyumin jaluzi',
    benefits: ['100% namlikka va suvga chidamli', 'Ofislar, oshxona va sanuzellar uchun ayni muddao', 'Lamellarni 360° burish imkoni'],
    installationInfo: 'Plastik yoki alyuminiy oynalar romiga qotiriladi.'
  },
  {
    id: 'prod-item-9',
    name: 'Eksklyuziv Tabiiy Eman Yog‘och (Wood) 50mm',
    description: 'Klassik va nufuzli interyerlar uchun tabiiy eman va lipa yog‘ochidan ishlangan premium gorizontal jaluzi.',
    material: '100% Tabiiy ishlov berilgan Kanada lipa va eman yog‘ochi',
    availableColors: ['To‘q yong‘oq', 'Klassik eman', 'Oltin kashtan', 'Oq emal'],
    pricePerSqm: 350000,
    image: 'https://i.ibb.co/fz1QjQ7v/photo-2026-02-27-10-46-34.jpg',
    category: 'Wood (Yog‘och) jaluzi',
    benefits: ['100% olijanob tabiiy yog‘och', 'Hashamatli va statusli ko‘rinish', 'Ekologik sof va mustahkam'],
    installationInfo: 'Devor yoki shiftga mustahkam kranis bilan montaj qilinadi.'
  },
  {
    id: 'prod-item-10',
    name: 'Klassik Dizaynerlik Rim Pardalari',
    description: 'Ko‘tarilganda chiroyli kaskadli burmalar hosil qiluvchi, tabiiy zig‘ir va paxta to‘qimali Rim pardalari.',
    material: 'Tabiiy zig‘ir (Linen), paxta va nafis ipak tolalari',
    availableColors: ['Tabiiy zig‘ir bej', 'Sutli krem', 'Och kulrang', 'Kofe'],
    pricePerSqm: 260000,
    image: 'https://i.ibb.co/nMgFNxy9/photo-2025-10-11-12-34-27.jpg',
    category: 'Rim pardalari',
    benefits: ['Nafis kaskadli burmalar', 'Ekologik toza tabiiy to‘qima', 'Har qanday xonaga shinamlik beradi'],
    installationInfo: 'Deraza tepasiga maxsus rolikli kranis bilan o‘rnatiladi.'
  },
  {
    id: 'prod-item-11',
    name: 'Hashamatli Saroy Zali Dikey Vertikal Pardasi',
    description: 'Katta zallar va hashamatli xonadonlar uchun 22XH seriyasidagi maxsus burmali Dikey parda tizimi.',
    material: 'Saroyona to‘qimali ipak va tyul aralashmasi',
    availableColors: ['Oltin-krem', 'Marvarid oq', 'Zumrad', 'Grafit'],
    pricePerSqm: 230000,
    image: 'https://i.ibb.co/Z1NmyQPB/photo-2025-12-12-12-57-38.jpg',
    category: 'Dikey pardalar',
    benefits: ['Saroyona to‘kiluvchi mato teksturasi', 'Quyosh nurini nafis taratish', '180° erkin burilish'],
    installationInfo: 'Shiftga mahkamlanadi.'
  },
  {
    id: 'prod-item-12',
    name: 'Termo-Izolyatsion Honeycomb (Uyali) Jaluzi',
    description: 'Ichki chuqurchali uyali tuzilishi evaziga qishda sovuqni, yozda issiqlikni xonaga kiritmaydigan innovatsion parda.',
    material: 'Termo-izolyatsiyalangan uyali (asalari uyasi) to‘qima',
    availableColors: ['Oq qor', 'Och bej', 'Kulrang', 'Antratsit'],
    pricePerSqm: 240000,
    image: 'https://i.ibb.co/ds3w7vhs/photo-2025-12-12-11-35-03.jpg',
    category: 'Honeycomb jaluzi',
    benefits: ['Maksimal termo va shovqin izolyatsiyasi', 'Elektr va konditsioner xarajatlarini tejash', 'Zamonaviy minimalizm'],
    installationInfo: 'Oyna romiga zich o‘rnatiladi.'
  },
  {
    id: 'prod-item-13',
    name: 'Kassetali Oyna Romi Mini Combo Jaluzi',
    description: 'Oyna ochilganda va shamollatish rejimida tushib ketmaydigan, yon yo‘naltiruvchilarga ega kassetali Combo.',
    material: 'Alyumin himoya kasseta va antistatik mato',
    availableColors: ['Oq', 'Krem', 'Jigarrang', 'Antratsit'],
    pricePerSqm: 185000,
    image: 'https://i.ibb.co/SDF1rtq9/photo-2025-01-22-10-52-34-2.jpg',
    category: 'Combo jaluzi',
    benefits: ['Shamolda qimirlamaydi va osilib ketmaydi', 'Kassetasi matoni changdan asraydi', 'Ixcham va qulay'],
    installationInfo: 'Plastik oyna ramkasiga zich o‘rnatiladi.'
  },
  {
    id: 'prod-item-14',
    name: 'Mansarda va Vitraj Oynalar Uchun Plisse',
    description: 'Qiya, uchburchak va nostandart mansarda oynalari uchun maxsus trossli fiksatsiyali Plisse tizimi.',
    material: 'Yevropa termo-himoyali zich gofre matosi',
    availableColors: ['Klassik bej', 'Oq', 'Zangori pastel', 'Kulrang'],
    pricePerSqm: 210000,
    image: 'https://i.ibb.co/YSd3yDR/photo-2025-01-22-10-52-34.jpg',
    category: 'Plisse jaluzi',
    benefits: ['Qiya holatda ham osilib ketmaydi', 'Nostandart oynalar uchun 100% mos', 'Kuchli issiqlik qaytarish'],
    installationInfo: 'Maxsus yo‘naltiruvchi trosslar bilan montaj qilinadi.'
  },
  {
    id: 'prod-item-15',
    name: 'Oshxona va Balkon Uchun Roller Jaluzi',
    description: 'Namlik, yog‘ va chang o‘tkazmaydigan maxsus teflon qoplamali, yuvish juda oson bo‘lgan rolikli parda.',
    material: 'Teflon qoplamali namlikka chidamli poliester',
    availableColors: ['Oq', 'Och bej', 'Kulrang', 'Shampan'],
    pricePerSqm: 155000,
    image: 'https://i.ibb.co/vRT3Gwy/photo-2025-01-22-10-52-35-2.jpg',
    category: 'Roller jaluzi',
    benefits: ['Nam latta bilan osongina artiladi', 'Yog‘ va kirlarni o‘ziga singdirmaydi', 'Ixcham dizayn'],
    installationInfo: 'Deraza romiga yoki devorga mahkamlanadi.'
  },
  {
    id: 'prod-item-16',
    name: 'Kottej Verandasi Uchun Tabiiy Bambuk',
    description: 'Ochiq ayvonlar, shiyponlar va yozgi oshxonalar uchun quyosh nurlaridan asrovchi tabiiy bambuk jaluzi.',
    material: 'Quyosh va shamolga chidamli to‘qilgan bambuk',
    availableColors: ['Tabiiy daraxt', 'Karamel', 'To‘q shokolad'],
    pricePerSqm: 225000,
    image: 'https://i.ibb.co/nMz55Lkj/photo-2025-01-22-10-52-35.jpg',
    category: 'Bambuk jaluzi',
    benefits: ['Tabiiy shamollatish va salqinlik', 'Ekologik toza mahsulot', 'Juda mustahkam to‘qima'],
    installationInfo: 'Shiftga yoki devor to‘siniga o‘rnatiladi.'
  },
  {
    id: 'prod-item-17',
    name: 'Oq Mat Tabiiy Yog‘och (Wood) 25mm Jaluzi',
    description: 'Plastik va yog‘och oynalar qanotiga moslashtirilgan, nafis va yengil 25mm yog‘och gorizontal lamel jaluzilari.',
    material: 'Yengil ishlov berilgan Kanada lipa yog‘ochi',
    availableColors: ['Oq mat', 'Krem', 'Tabiiy eman', 'Shokolad'],
    pricePerSqm: 320000,
    image: 'https://i.ibb.co/jtbNYnB/photo-2026-05-04-19-54-48.jpg',
    category: 'Wood (Yog‘och) jaluzi',
    benefits: ['Skandinav va neo-klassik uslub', '100% tabiiy yog‘och', 'Yorug‘likni aniq yo‘naltirish'],
    installationInfo: 'Oyna romiga ixcham o‘rnatiladi.'
  },
  {
    id: 'prod-item-18',
    name: 'Zamonaviy Yotoqxona Zebra Combo Jaluzi',
    description: 'Yotoqxonalarda qulay uyqu va sokinlikni ta’minlovchi, pastel rangli yumshoq matoli Combo tizimi.',
    material: 'Antistatik chang qaytaruvchi yumshoq tola',
    availableColors: ['Pastel krem', 'Oq', 'Och kulrang', 'Pushti pastel'],
    pricePerSqm: 165000,
    image: 'https://i.ibb.co/F4fbTPWt/photo-2025-01-31-09-39-12.jpg',
    category: 'Combo jaluzi',
    benefits: ['Sokin va shinam muhit', 'Quyosh nurini istalgancha to‘sish', 'Uzoq muddatli mexanizm'],
    installationInfo: 'Deraza ochilish qismiga o‘rnatiladi.'
  },
  {
    id: 'prod-item-19',
    name: 'Panoramali Deraza Uchun Dikey Pardalar',
    description: 'Katta vitraj oynalar va ofis zallari uchun quyosh nurini 180° boshqaruvchi vertikal lamel tizimi.',
    material: 'Yuqori zichlikdagi quyoshdan himoyalovchi mato',
    availableColors: ['Oq', 'Kulrang', 'Bej', 'Antratsit'],
    pricePerSqm: 200000,
    image: 'https://i.ibb.co/F4gTWsmN/photo-2026-05-04-14-41-43.jpg',
    category: 'Dikey pardalar',
    benefits: ['Katta maydonlarni to‘liq qoplash', 'Zamonaviy ishchan va shinam muhit', 'Oson suriluvchi roliklar'],
    installationInfo: 'Shiftga mahkamlanadi.'
  },
  {
    id: 'prod-item-20',
    name: 'Ikki Tomonlama Ochiluvchi Plisse Tizimi',
    description: 'Xonadon oynalariga o‘rnatiladigan, deraza qanotiga zich yopishuvchi yuqori sifatli plisse pardasi.',
    material: 'Yuviladigan yuqori zichlikdagi plisse matosi',
    availableColors: ['Oq marvarid', 'Bej', 'Kulrang', 'Krem'],
    pricePerSqm: 195000,
    image: 'https://i.ibb.co/S44Vvm77/photo-2026-05-04-14-41-44.jpg',
    category: 'Plisse jaluzi',
    benefits: ['10 yil akkordeon shakli buzilmaydi', 'Pastdan ham, tepadan ham ochiladi', 'Oyna ochilganda xalaqit bermaydi'],
    installationInfo: 'Oyna romiga bevosita o‘rnatiladi.'
  },
  {
    id: 'prod-item-21',
    name: 'Kumush Rangli Alyumin Gorizontal Jaluzi',
    description: 'Ofislar, kabinetlar va oshxonalar uchun nur qaytaruvchi yengil 25mm alyumin jaluzi.',
    material: 'Mikro-ishlov berilgan porlashga qarshi alyuminiy',
    availableColors: ['Kumush', 'Metallik kulrang', 'Oq', 'Qora'],
    pricePerSqm: 145000,
    image: 'https://i.ibb.co/hFxM9z4Q/photo-2026-05-04-14-50-37-2.jpg',
    category: 'Alyumin jaluzi',
    benefits: ['Quyosh nurini 100% qaytarish', 'Suv va namlikdan qo‘rqmaydi', 'Tez va qulay boshqaruv'],
    installationInfo: 'Plastik oynaga fiksatorlar bilan qotiriladi.'
  },
  {
    id: 'prod-item-22',
    name: 'Relyefli Naqshli Lux Combo Jaluzi',
    description: 'Nafis 3D jakkard to‘qimali naqshlarga ega, interyerga hashamat baxsh etuvchi Combo jaluzisi.',
    material: '3D Jakkard relyefli maxsus to‘qima',
    availableColors: ['Oltin-bej', 'Oq naqshli', 'Shampan', 'Kofe'],
    pricePerSqm: 180000,
    image: 'https://i.ibb.co/DPW4WYLX/photo-2026-05-04-14-50-37.jpg',
    category: 'Combo jaluzi',
    benefits: ['Hashamatli 3D naqshlar', 'Yorug‘likni nafis taratish', 'O‘chmas sifatli bo‘yoq'],
    installationInfo: 'Deraza yoki devorga o‘rnatiladi.'
  },
  {
    id: 'prod-item-23',
    name: 'Shinam Kottej Uchun Nafis Rim Pardasi',
    description: 'Ekologik sof tabiiy zig‘ir va paxta to‘qimali, xonadonga iliq muhit ulashuvchi Rim pardasi.',
    material: 'Tabiiy zig‘ir va paxta to‘qimasi',
    availableColors: ['Tabiiy bej', 'Och qum', 'Sut rang', 'Grafit'],
    pricePerSqm: 270000,
    image: 'https://i.ibb.co/SXsL72F2/photo-2026-05-04-14-57-54-2.jpg',
    category: 'Rim pardalari',
    benefits: ['100% ekologik tabiiy xomashyo', 'Nafis to‘kiluvchi tekstura', 'Hashamatli ko‘rinish'],
    installationInfo: 'Shift yoki devor kranisiga montaj qilinadi.'
  },
  {
    id: 'prod-item-24',
    name: '3D Honeycomb Shovqindan Himoya Pardasi',
    description: 'Ko‘cha shovqini va haroratini to‘suvchi maxsus havo kamerali 3D Honeycomb (uyali) jaluzi.',
    material: 'Akustik va termo-himoyali uyali kompozit mato',
    availableColors: ['Oq', 'Kulrang', 'Bej', 'Antratsit'],
    pricePerSqm: 250000,
    image: 'https://i.ibb.co/5XTTfWLL/photo-2026-05-04-14-57-54.jpg',
    category: 'Honeycomb jaluzi',
    benefits: ['Maksimal shovqin pasaytirish', 'Qishda issiq, yozda salqin', 'Juda ixcham va estetik'],
    installationInfo: 'Oyna romiga zich o‘rnatiladi.'
  }
];

// Pre-seeded high-quality real portfolio projects (2-KATALOG: QILINGAN ISHLAR REAL LOYIHALARI)
// FAQAT REAL O'RNATILGAN MONTAJ ISHLARI (KATALOG MATOLARI VA NAMUNALARI EMAS)
const defaultProjects: PortfolioProject[] = [
  ...DIKEY_GALLERY_PROJECTS,
  ...COMBO_GALLERY_PROJECTS,
  ...PLISSE_GALLERY_PROJECTS,
  ...ROLLO_GALLERY_PROJECTS,
  ...ALYUMIN_GALLERY_PROJECTS,
  ...WOOD_GALLERY_PROJECTS,
  ...PRINT_GALLERY_PROJECTS,
];

const defaultProcessSteps: ProcessStep[] = [
  {
    id: 'step-1',
    stepNumber: '01',
    title: 'Konsultatsiya',
    description: 'Sayt, Telegram yoki telefon orqali ariza qoldirasiz. Mutaxassislarimiz siz bilan bog‘lanib, barcha savollaringizga javob berishadi.'
  },
  {
    id: 'step-2',
    stepNumber: '02',
    title: 'O‘lchov olish',
    description: 'Bizning professional o‘lchov muhandisimiz uyingizga (yoki ofisingizga) o‘lcham namunalarini olib borib, aniq o‘lchovlarni oladi.'
  },
  {
    id: 'step-3',
    stepNumber: '03',
    title: 'Dizayn tanlash',
    description: 'Yuzlab mato turlari va ranglari katalogini ko‘rib chiqasiz, uyingiz interyeriga eng mos keladigan dizayn va materialni tasdiqlaysiz.'
  },
  {
    id: 'step-4',
    stepNumber: '04',
    title: 'Ishlab chiqarish',
    description: 'Siz tasdiqlagan o‘lcham va materiallar asosida, 2-3 kun davomida yuqori aniqlikdagi uskunalarimizda individual buyurtmangiz ishlab chiqariladi.'
  },
  {
    id: 'step-5',
    stepNumber: '05',
    title: 'Professional montaj',
    description: 'Tayyor jaluzilarni professional ustalarimiz yetkazib berib, qisqa vaqt ichida toza va mustahkam o‘rnatib berishadi.'
  }
];

const defaultOrders: Order[] = [];

const defaultConsultations: ConsultationRequest[] = [];

const defaultAdminConfig: AdminConfig = {
  phoneNumber: '+998 94 000 99 77',
  telegramLink: 'https://t.me/eco_jaluzi',
  instagramLink: 'https://www.instagram.com/eco_jaluzi',
  facebookLink: 'https://www.facebook.com/share/1DStoTepy9/',
  adminTelegram: 'https://t.me/eco_jaluzishtor',
  address: '',
  telegramBotToken: '8956576620:AAE5fWgi8psTQr842Axhdu2nW_bNM4rroOo',
  telegramChatId: '',
  customerBotToken: '',
  customerChatId: '',
  factoryVideoUrl: '',
  factoryVideoPoster: ''
};

// LocalStorage Helpers
const getStorageItem = <T>(key: string, defaultValue: T): T => {
  const item = localStorage.getItem(key);
  if (!item) {
    localStorage.setItem(key, JSON.stringify(defaultValue));
    return defaultValue;
  }
  try {
    return JSON.parse(item) as T;
  } catch {
    return defaultValue;
  }
};

const setStorageItem = <T>(key: string, value: T): boolean => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (err) {
    console.error(`Storage quota or write error on key ${key}:`, err);
    return false;
  }
};

export const dbService = {
  // Products API
  getProducts(): Product[] {
    return getStorageItem<Product[]>(PRODUCTS_KEY, defaultProducts);
  },
  
  saveProduct(product: Omit<Product, 'id'> & { id?: string }): Product {
    const products = this.getProducts();
    let savedProduct: Product;
    
    if (product.id) {
      // Update
      savedProduct = product as Product;
      const index = products.findIndex(p => p.id === product.id);
      if (index !== -1) {
        products[index] = savedProduct;
      }
    } else {
      // Create
      savedProduct = {
        ...product,
        id: `p-${Date.now()}`
      };
      products.push(savedProduct);
    }
    
    setStorageItem(PRODUCTS_KEY, products);
    window.dispatchEvent(new Event('cms_update'));
    return savedProduct;
  },
  
  deleteProduct(id: string): void {
    const products = this.getProducts();
    const filtered = products.filter(p => p.id !== id);
    setStorageItem(PRODUCTS_KEY, filtered);
    window.dispatchEvent(new Event('cms_update'));
  },

  // Projects API
  getProjects(): PortfolioProject[] {
    return getStorageItem<PortfolioProject[]>(PROJECTS_KEY, defaultProjects);
  },
  
  saveProject(project: Omit<PortfolioProject, 'id'> & { id?: string }): PortfolioProject {
    const projects = this.getProjects();
    let savedProject: PortfolioProject;
    
    if (project.id) {
      savedProject = project as PortfolioProject;
      const index = projects.findIndex(p => p.id === project.id);
      if (index !== -1) {
        projects[index] = savedProject;
      }
    } else {
      savedProject = {
        ...project,
        id: `proj-${Date.now()}`
      };
      projects.unshift(savedProject);
    }
    
    setStorageItem(PROJECTS_KEY, projects);
    window.dispatchEvent(new Event('cms_update'));
    return savedProject;
  },
  
  deleteProject(id: string): void {
    const projects = this.getProjects();
    const filtered = projects.filter(p => p.id !== id);
    setStorageItem(PROJECTS_KEY, filtered);
    window.dispatchEvent(new Event('cms_update'));
  },

  // Process Steps API
  getProcessSteps(): ProcessStep[] {
    // Force reset to default process steps to ensure pristine state
    localStorage.removeItem(PROCESS_KEY);
    setStorageItem(PROCESS_KEY, defaultProcessSteps);
    return defaultProcessSteps;
  },

  saveProcessStep(step: Omit<ProcessStep, 'id'> & { id?: string }): ProcessStep {
    const steps = this.getProcessSteps();
    let savedStep: ProcessStep;

    if (step.id) {
      savedStep = step as ProcessStep;
      const index = steps.findIndex(s => s.id === step.id);
      if (index !== -1) {
        steps[index] = savedStep;
      }
    } else {
      savedStep = {
        ...step,
        id: `step-${Date.now()}`
      };
      steps.push(savedStep);
    }

    setStorageItem(PROCESS_KEY, steps);
    window.dispatchEvent(new Event('cms_update'));
    return savedStep;
  },

  deleteProcessStep(id: string): void {
    const steps = this.getProcessSteps();
    const filtered = steps.filter(s => s.id !== id);
    setStorageItem(PROCESS_KEY, filtered);
    window.dispatchEvent(new Event('cms_update'));
  },

  resetProcessSteps(): ProcessStep[] {
    setStorageItem(PROCESS_KEY, defaultProcessSteps);
    window.dispatchEvent(new Event('cms_update'));
    return defaultProcessSteps;
  },

  // Orders API
  getOrders(): Order[] {
    return getStorageItem<Order[]>(ORDERS_KEY, defaultOrders);
  },
  
  addOrder(order: Omit<Order, 'id' | 'date' | 'status'>): Order {
    const orders = this.getOrders();
    const newOrder: Order = {
      ...order,
      id: `ord-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      status: 'Kutilmoqda'
    };
    orders.unshift(newOrder);
    setStorageItem(ORDERS_KEY, orders);
    window.dispatchEvent(new Event('cms_update'));
    return newOrder;
  },
  
  updateOrderStatus(id: string, status: Order['status']): void {
    const orders = this.getOrders();
    const index = orders.findIndex(o => o.id === id);
    if (index !== -1) {
      orders[index].status = status;
      setStorageItem(ORDERS_KEY, orders);
      window.dispatchEvent(new Event('cms_update'));
    }
  },

  deleteOrder(id: string): void {
    const orders = this.getOrders();
    const filtered = orders.filter(o => o.id !== id);
    setStorageItem(ORDERS_KEY, filtered);
    window.dispatchEvent(new Event('cms_update'));
  },

  // Consultations API
  getConsultations(): ConsultationRequest[] {
    return getStorageItem<ConsultationRequest[]>(CONSULTATIONS_KEY, defaultConsultations);
  },
  
  addConsultation(req: Omit<ConsultationRequest, 'id' | 'date' | 'status'>): ConsultationRequest {
    const requests = this.getConsultations();
    const newReq: ConsultationRequest = {
      ...req,
      id: `cons-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      status: 'Kutilmoqda'
    };
    requests.unshift(newReq);
    setStorageItem(CONSULTATIONS_KEY, requests);
    window.dispatchEvent(new Event('cms_update'));
    return newReq;
  },
  
  updateConsultationStatus(id: string, status: ConsultationRequest['status']): void {
    const requests = this.getConsultations();
    const index = requests.findIndex(r => r.id === id);
    if (index !== -1) {
      requests[index].status = status;
      setStorageItem(CONSULTATIONS_KEY, requests);
      window.dispatchEvent(new Event('cms_update'));
    }
  },

  deleteConsultation(id: string): void {
    const requests = this.getConsultations();
    const filtered = requests.filter(r => r.id !== id);
    setStorageItem(CONSULTATIONS_KEY, filtered);
    window.dispatchEvent(new Event('cms_update'));
  },

  // Admin Config API
  getAdminConfig(): AdminConfig {
    const saved = getStorageItem<AdminConfig>(CONFIG_KEY, defaultAdminConfig);
    return { ...defaultAdminConfig, ...saved };
  },
  
  updateAdminConfig(config: AdminConfig): void {
    setStorageItem(CONFIG_KEY, config);
    window.dispatchEvent(new Event('cms_update'));
  },

  // Visits API
  getVisitCount(): number {
    const current = localStorage.getItem('eco_jaluzi_visits');
    if (!current) {
      localStorage.setItem('eco_jaluzi_visits', '0');
      return 0;
    }
    return Number(current);
  },

  incrementVisitCount(): number {
    const current = this.getVisitCount();
    const next = current + 1;
    localStorage.setItem('eco_jaluzi_visits', String(next));
    window.dispatchEvent(new Event('cms_update'));
    return next;
  }
};

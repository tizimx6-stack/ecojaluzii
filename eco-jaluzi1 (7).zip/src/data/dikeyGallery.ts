import { PortfolioProject } from "../types";

export interface DikeyProjectItem extends PortfolioProject {
  roomType?: string;
  fabricType?: string;
}

export const DIKEY_GALLERY_PROJECTS: DikeyProjectItem[] = [
{
    id: "dikey-real-1",
    title: "Oltin-Krem Jiloli Premium Dikey Pardalar (№1)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/WpRJBvVk/photo-2026-07-07-11-53-34.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-2",
    title: "Marvarid Oq Tyul Va Dikey Pardalari Uyg‘unligi (№2)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/C50jK8dn/photo-2026-06-06-18-05-54.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-3",
    title: "Katta Zal va Panoramik Derazalar Uchun Dikey (№3)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/LWmMZyc/photo-2026-06-06-17-56-05.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-4",
    title: "Ofis va Nufuzli Kabinetlar Uchun Zamonaviy Dikey (№4)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/gM3JbnSc/photo-2026-04-29-09-42-00-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-5",
    title: "Yotoqxona Uchun Sokin va Shinam Dikey Modeli (№5)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/DgRf5RjH/photo-2026-04-29-09-42-00.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-6",
    title: "Restoran va Tadbirlar Zali Uchun Maxsus Dikey (№6)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/08Tjg9y/photo-2026-04-29-09-40-44-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-7",
    title: "Yevropa Standartidagi 180° Buriluvchi Dikey (№7)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/rRF1K2P1/photo-2026-04-29-09-40-44.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-8",
    title: "Nafis Ipak To‘qimali Eksklyuziv Dikey Tizimi (№8)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/C5Gy0gvy/photo-2026-04-29-09-34-49.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-9",
    title: "Hashamatli Kottej Zali Uchun Saroyona Dikey Parda (№9)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/8DB1Y0yG/photo-2026-04-29-09-34-48.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-10",
    title: "Klassik 22XH Burmali Eksklyuziv Dikey Pardasi (№10)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/pvtx8Ygm/photo-2026-04-29-11-21-46.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-11",
    title: "Zamonaviy Vitraj Derazalar Uchun Dikey Tizimi (№11)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/kVyH2d4N/photo-2026-04-29-11-21-10.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-12",
    title: "Yashash Xonasi va Mehmonxona Uchun Nafis Dikey (№12)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/wN2PF6RD/photo-2026-04-29-11-19-54.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-13",
    title: "Oltin-Krem Jiloli Premium Dikey Pardalar (№13)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/S77mtGFd/photo-2025-08-15-14-32-10-4.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-14",
    title: "Marvarid Oq Tyul Va Dikey Pardalari Uyg‘unligi (№14)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/dsNMwQJM/photo-2025-08-15-14-32-10-3.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-15",
    title: "Katta Zal va Panoramik Derazalar Uchun Dikey (№15)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/Mk1dVHHz/photo-2025-08-15-14-32-10-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-16",
    title: "Ofis va Nufuzli Kabinetlar Uchun Zamonaviy Dikey (№16)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/fVjfpXd1/photo-2025-08-15-14-32-10.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-17",
    title: "Yotoqxona Uchun Sokin va Shinam Dikey Modeli (№17)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/q3fwvqvX/photo-2025-08-15-14-32-09-3.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-18",
    title: "Restoran va Tadbirlar Zali Uchun Maxsus Dikey (№18)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/jPKGW7pN/photo-2025-08-15-14-32-09-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-19",
    title: "Yevropa Standartidagi 180° Buriluvchi Dikey (№19)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/6JRR4JmF/photo-2025-08-15-14-32-09.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-20",
    title: "Nafis Ipak To‘qimali Eksklyuziv Dikey Tizimi (№20)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/TBPW853C/photo-2025-04-22-15-19-51-5.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-21",
    title: "Hashamatli Kottej Zali Uchun Saroyona Dikey Parda (№21)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/TxP5Sky7/photo-2025-04-22-15-19-51-4.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-22",
    title: "Klassik 22XH Burmali Eksklyuziv Dikey Pardasi (№22)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/3YyFpKrG/photo-2025-04-22-15-19-51-3.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-23",
    title: "Zamonaviy Vitraj Derazalar Uchun Dikey Tizimi (№23)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/BKgpbxFp/photo-2025-04-22-15-19-51-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-24",
    title: "Yashash Xonasi va Mehmonxona Uchun Nafis Dikey (№24)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/Knnrmzx/photo-2025-04-22-15-19-51.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-25",
    title: "Oltin-Krem Jiloli Premium Dikey Pardalar (№25)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/mFRzrs3f/photo-2025-09-03-11-12-55-6.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-26",
    title: "Marvarid Oq Tyul Va Dikey Pardalari Uyg‘unligi (№26)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/pvG4Rh7C/photo-2025-09-03-11-12-55-5.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-27",
    title: "Katta Zal va Panoramik Derazalar Uchun Dikey (№27)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/dJWTwjsV/photo-2025-09-03-11-12-55-4.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-28",
    title: "Ofis va Nufuzli Kabinetlar Uchun Zamonaviy Dikey (№28)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/KxMT4jLY/photo-2025-09-03-11-12-55-3.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-29",
    title: "Yotoqxona Uchun Sokin va Shinam Dikey Modeli (№29)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/svVPgMDq/photo-2025-09-03-11-12-55-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-30",
    title: "Restoran va Tadbirlar Zali Uchun Maxsus Dikey (№30)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/1Yv0Sw5D/photo-2025-09-03-11-12-55.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-31",
    title: "Yevropa Standartidagi 180° Buriluvchi Dikey (№31)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/Df3JgfrM/photo-2025-09-03-11-12-54.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-32",
    title: "Nafis Ipak To‘qimali Eksklyuziv Dikey Tizimi (№32)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/vxb2r4J8/photo-2025-09-03-11-12-53-3.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-33",
    title: "Hashamatli Kottej Zali Uchun Saroyona Dikey Parda (№33)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/5fbNc49/photo-2025-09-03-11-12-53-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-34",
    title: "Klassik 22XH Burmali Eksklyuziv Dikey Pardasi (№34)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/Nn3F9Zpq/photo-2025-09-03-17-49-14-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-35",
    title: "Zamonaviy Vitraj Derazalar Uchun Dikey Tizimi (№35)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/7NdD1BXt/photo-2025-09-03-11-12-52-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-36",
    title: "Yashash Xonasi va Mehmonxona Uchun Nafis Dikey (№36)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/0yRRtq67/photo-2025-12-10-18-24-36-6.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-37",
    title: "Oltin-Krem Jiloli Premium Dikey Pardalar (№37)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/N2myZ7HB/photo-2025-12-10-18-24-36-5.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-38",
    title: "Marvarid Oq Tyul Va Dikey Pardalari Uyg‘unligi (№38)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/ksKmYWf7/photo-2025-12-10-18-24-36-4.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-39",
    title: "Katta Zal va Panoramik Derazalar Uchun Dikey (№39)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/23x32rr4/photo-2025-12-10-18-24-35-8.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-40",
    title: "Ofis va Nufuzli Kabinetlar Uchun Zamonaviy Dikey (№40)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/hF8WHXM2/photo-2025-12-10-18-24-35-7.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-41",
    title: "Yotoqxona Uchun Sokin va Shinam Dikey Modeli (№41)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/s9ks7Wtv/photo-2025-12-10-18-24-35-6.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-42",
    title: "Restoran va Tadbirlar Zali Uchun Maxsus Dikey (№42)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/BH7q76bL/photo-2025-12-10-18-24-35-5.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-43",
    title: "Yevropa Standartidagi 180° Buriluvchi Dikey (№43)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/6cb6jCZc/photo-2025-12-10-18-23-47-5.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-44",
    title: "Nafis Ipak To‘qimali Eksklyuziv Dikey Tizimi (№44)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/CKHgsR6w/photo-2025-12-10-18-23-47-4.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-45",
    title: "Hashamatli Kottej Zali Uchun Saroyona Dikey Parda (№45)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/934GS38H/photo-2025-12-10-18-23-47-3.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-46",
    title: "Klassik 22XH Burmali Eksklyuziv Dikey Pardasi (№46)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/27xY9k6Y/photo-2025-12-10-18-23-47-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-47",
    title: "Zamonaviy Vitraj Derazalar Uchun Dikey Tizimi (№47)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/Tjskkym/photo-2025-12-10-18-23-47.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Saroyona to‘qima"
  },
  {
    id: "dikey-real-48",
    title: "Yashash Xonasi va Mehmonxona Uchun Nafis Dikey (№48)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/jkyT95cB/photo-2025-12-10-18-23-46.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "22XH Premium Ipak"
  },
  {
    id: "dikey-real-49",
    title: "Oltin-Krem Jiloli Premium Dikey Pardalar (№49)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/BH15dJpy/photo-2025-12-10-18-23-45.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Kottej & Mehmonxona",
    fabricType: "Tyul + Dikey"
  },
  {
    id: "dikey-real-50",
    title: "Marvarid Oq Tyul Va Dikey Pardalari Uyg‘unligi (№50)",
    category: "Dikey pardalar",
    image: "https://i.ibb.co/CgKm9gn/photo-2025-12-10-18-23-44-2.jpg",
    description: "Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.",
    roomType: "Zal & Vitraj oyna",
    fabricType: "Saroyona to‘qima"
  }
];

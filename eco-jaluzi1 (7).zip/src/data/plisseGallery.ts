import { PortfolioProject } from '../types';

export interface PlisseProjectItem extends PortfolioProject {
  roomType?: string;
  fabricColor?: string;
}

export const PLISSE_GALLERY_PROJECTS: PlisseProjectItem[] = [
  {
    id: 'plisse-real-1',
    title: 'Oyna Romi Tavaqasiga Zich O‘rnatilgan Plisse Montaji',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/b5RVxZx5/photo-2026-02-08-12-54-12.jpg',
    description: 'Plastik va alyumin oynalarning har bir tavaqasiga zich va qulay o‘rnatiladigan ikki tomonlama plisse tizimi.',
    roomType: 'Deraza & Balkon',
    fabricColor: 'Oq'
  },
  {
    id: 'plisse-real-2',
    title: 'Nafis Bej Rangli Premium Xonadon Plisse Pardasi',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/jPCdSXb2/photo-2026-02-08-12-54-11.jpg',
    description: 'Tepadan ham, pastdan ham ochiluvchi ikki tomonlama boshqaruvga ega zamonaviy plisse pardasi.',
    roomType: 'Mehmonxona',
    fabricColor: 'Krem-bej'
  },
  {
    id: 'plisse-real-3',
    title: 'Vitraj va Fransuz Oynalar Uchun Quyoshdan Himoya Plissesi',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/23V8xhpw/photo-2026-02-06-11-57-49.jpg',
    description: 'Quyoshning to‘g‘ridan-to‘g‘ri issiqligini to‘suvchi va xona haroratini saqlab beruvchi maxsus qatlamli plisse.',
    roomType: 'Vitraj',
    fabricColor: 'Kumushrang'
  },
  {
    id: 'plisse-real-4',
    title: 'Ikki Tomonlama Ochiluvchi Qulay Deraza Plisse Tizimi',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/7NphXGqR/photo-2026-02-06-11-57-47.jpg',
    description: 'Xohlagan balandlikda to‘xtatish imkonini beruvchi qulay va nozik mexanizmli plisse montaji.',
    roomType: 'Deraza & Balkon',
    fabricColor: 'Oq-bej'
  },
  {
    id: 'plisse-real-5',
    title: 'Klassik Xonadon Yotoqxonasi Uchun Nozik Plisse',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/JRqfHWDH/photo-2026-02-06-11-57-46.jpg',
    description: 'Shinam muhit yaratuvchi, yorug‘likni yumshoq filtrlovchi zamonaviy akkordeon plisse pardasi.',
    roomType: 'Yotoqxona',
    fabricColor: 'Pastel bej'
  },
  {
    id: 'plisse-real-6',
    title: 'Oshxona Derazasi Uchun Namlikka Chidamli Plisse Pardasi',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/ynRP24LM/photo-2026-02-06-11-57-45.jpg',
    description: 'Namlik va yog‘ tomchilariga chidamli antistatik to‘qimali matodan tikilgan oshxona plisse pardasi.',
    roomType: 'Oshxona',
    fabricColor: 'Oq'
  },
  {
    id: 'plisse-real-7',
    title: 'Baland va Keng Derazalar Uchun Ekologik Plisse Montaji',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/whXYnrkR/photo-2026-02-06-11-57-43.jpg',
    description: 'Katta oyna konstruksiyalariga chiroyli va qulay mos tushgan ekologik toza plisse pardalari.',
    roomType: 'Katta zal',
    fabricColor: 'Krem'
  },
  {
    id: 'plisse-real-8',
    title: 'Yorug‘likni Mayin O‘tkazuvchi Shinam Plisse Jaluzi',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/hJXRPddz/photo-2026-02-06-11-57-42.jpg',
    description: 'Yorug‘likni bir maromda mayin tarqatuvchi zamonaviy xonadon plisse jaluzi montaji.',
    roomType: 'Mehmonxona',
    fabricColor: 'Oltin qum'
  },
  {
    id: 'plisse-real-9',
    title: 'Tinch Uyqu va Dam Olish Zonasi Uchun Plisse Parda',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/qLWThY28/photo-2026-02-06-11-57-41.jpg',
    description: 'Dam olish va uyqu paytida tinch va qulay muhit yaratuvchi jozibador plisse parda.',
    roomType: 'Yotoqxona',
    fabricColor: 'Sut rangli'
  },
  {
    id: 'plisse-real-10',
    title: 'Gofre Burmali Nafis Xonadon Plisse Loyihasi',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/Dg65RtQS/photo-2026-02-06-11-57-39.jpg',
    description: 'Interyer dizayniga mukammal monand tushgan chiroyli gofre burmali plisse loyihasi.',
    roomType: 'Zal & Mehmonxona',
    fabricColor: 'Marvarid bej'
  },
  {
    id: 'plisse-real-11',
    title: 'Maxsus Buyurtma Asosida Tayyorlangan Deraza Plissesi',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/vx3Q4st0/photo-2026-02-06-11-57-36.jpg',
    description: 'Har bir rom o‘lchamiga millimetrigacha moslashtirib o‘rnatilgan yuqori sifatli plisse tizimi.',
    roomType: 'Ish xonasi',
    fabricColor: 'Kulrang-oq'
  },
  {
    id: 'plisse-real-12',
    title: 'Mansarda va Qiya Oynalar Uchun Trossli Plisse Tizimi',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/pBm045pc/photo-2026-02-06-11-57-31.jpg',
    description: 'Qiya romga osilib qolmasdan mustahkam harakatlanuvchi maxsus trossli plisse montaji.',
    roomType: 'Mansarda',
    fabricColor: 'Oq'
  },
  {
    id: 'plisse-real-13',
    title: 'Kompakt va Qulay Deraza Romi Plisse Jaluzisi',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/MysxfSH1/photo-2026-02-06-11-57-28.jpg',
    description: 'Romga zarar yetkazmagan holda mustahkam biriktiriladigan qulay plisse mahsuloti.',
    roomType: 'Deraza',
    fabricColor: 'Oq marvarid'
  },
  {
    id: 'plisse-real-14',
    title: 'Neoklassik Uslubdagi Kottej Oynasi Plisse Montaji',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/gLMwKMZ2/photo-2026-02-06-11-57-25.jpg',
    description: 'Klassik va neoklassik interyerlar bilan ajoyib mos keluvchi nozik plisse pardalari.',
    roomType: 'Kottej zali',
    fabricColor: 'Krem-bej'
  },
  {
    id: 'plisse-real-15',
    title: 'Zamonaviy Ofis va Uy Kabineti Uchun Plisse Jaluzi',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/TDLb4Cmh/photo-2026-02-03-15-43-59.jpg',
    description: 'Ham zamonaviy ofis, ham shinam uy muhitida a’lo darajada xizmat qiluvchi plisse jaluzi.',
    roomType: 'Kabinet',
    fabricColor: 'Oq'
  },
  {
    id: 'plisse-real-16',
    title: 'Ikki Tomonlama Moslashuvchan Harakatli Plisse Tizimi',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/twNPnCn0/photo-2026-02-03-15-43-58.jpg',
    description: 'Derazani xohlagan qismida ochib qo‘yish imkonini beruvchi ikki tutqichli plisse.',
    roomType: 'Deraza',
    fabricColor: 'Bej'
  },
  {
    id: 'plisse-real-17',
    title: 'Premium Jakkard To‘qimali Nafis Plisse Pardasi',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/m5ynnhgN/photo-2026-02-03-15-43-57.jpg',
    description: 'Maxsus yorug‘lik o‘tkazuvchan to‘qimaga ega qimmatbaho plisse pardasi.',
    roomType: 'Yashash xonasi',
    fabricColor: 'Oltin-krem'
  },
  {
    id: 'plisse-real-18',
    title: 'Balkon va Vitraj Uchun Quyosh Nurlarini To‘suvchi Plisse',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/xqPyXcGr/photo-2026-02-03-15-43-56.jpg',
    description: 'To‘g‘ridan-to‘g‘ri quyosh nurlarining ko‘zni qamashtirishiga yo‘l qo‘ymaydigan plisse tizimi.',
    roomType: 'Balkon',
    fabricColor: 'Kulrang'
  },
  {
    id: 'plisse-real-19',
    title: 'Mayin Tabiiy Yorug‘lik Ulashuvchi Xonadon Plissesi',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/s0ZdxWt/photo-2026-02-03-15-43-55.jpg',
    description: 'Ko‘zni qamashtirmaydigan, mayin tabiiy yorug‘lik muhitini yaratuvchi plisse montaji.',
    roomType: 'Yashash xonasi',
    fabricColor: 'Sutli oq'
  },
  {
    id: 'plisse-real-20',
    title: 'Nostandart va Burchakli Oynalar Uchun Plisse Montaji',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/2YHgkQBG/photo-2026-01-27-14-07-54.jpg',
    description: 'Burchakli va qiya joylashgan deraza tavaqalariga qotirilgan maxsus mustahkam plisse.',
    roomType: 'Nostandart oyna',
    fabricColor: 'Oq'
  },
  {
    id: 'plisse-real-21',
    title: 'Shinam Xonadon Interyeri Uchun Go‘zal Plisse Tizimi',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/RpFTrTwL/photo-2026-01-27-14-07-52.jpg',
    description: 'Har qanday xona dizaynini boyituvchi va xonaga shinamlik bag‘ishlovchi plisse tizimi.',
    roomType: 'Xonadon',
    fabricColor: 'Bej'
  },
  {
    id: 'plisse-real-22',
    title: 'Panoramali Katta Vitraj Tavaqalari Plisse Loyihasi',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/zhn09Brx/photo-2026-01-27-14-00-34.jpg',
    description: 'Katta maydonli oyna konstruksiyalariga alohida tavaqa asosida yig‘ilgan plisse montaji.',
    roomType: 'Panoramali deraza',
    fabricColor: 'Oq marvarid'
  },
  {
    id: 'plisse-real-23',
    title: 'Mustahkam Prujinali Mexanizmga Ega Silliq Plisse',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/PZn13Ywv/photo-2026-01-27-14-00-35.jpg',
    description: 'Mustahkam prujina va arqonli mexanizmlar bilan uzoq yillar silliq ishlovchi plisse.',
    roomType: 'Deraza',
    fabricColor: 'Krem'
  },
  {
    id: 'plisse-real-24',
    title: 'Zamonaviy Yotoqxona Oynasi Uchun Nozik Plisse',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/fVTy22Kx/photo-2023-11-20-13-20-58.jpg',
    description: 'Quyosh erta uyg‘otmasligi uchun maxsus termo to‘qimali matodan tayyorlangan plisse.',
    roomType: 'Yotoqxona',
    fabricColor: 'Kulrang'
  },
  {
    id: 'plisse-real-25',
    title: 'Individual Tanlangan Ranglar Bilan Ishlangan Plisse',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/ccgnNHg4/photo-2022-09-17-09-12-32.jpg',
    description: 'Turli rangdagi mato kataloglaridan tanlab o‘rnatilgan qulay boshqaruvli plisse.',
    roomType: 'Mehmonxona',
    fabricColor: 'Bej-jigarrang'
  },
  {
    id: 'plisse-real-26',
    title: 'Kottej Balkon Tavaqalari Uchun Plisse Pardalari',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/H3cS4yw/photo-2022-09-17-09-12-31.jpg',
    description: 'Barcha deraza tavaqalari bir maromda ochilishi uchun maxsus o‘rnatilgan plisse to‘plami.',
    roomType: 'Balkon',
    fabricColor: 'Oq'
  },
  {
    id: 'plisse-real-27',
    title: 'Plastik Oyna Romiga Zich Plisse Akkordeon Jaluzi',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/b5PqB8mp/photo-2022-09-12-12-14-46.jpg',
    description: 'Plastik va alyumin oynalarning har bir tavaqasiga zich va qulay o‘rnatiladigan plisse tizimi.',
    roomType: 'Deraza & Balkon',
    fabricColor: 'Oq'
  },
  {
    id: 'plisse-real-28',
    title: 'Ikki Tomonlama Ochiluvchi Nafis Plisse Pardasi',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/LhkqMKFT/photo-2022-09-10-01-40-11.jpg',
    description: 'Tepadan ham, pastdan ham ochiluvchi ikki tomonlama boshqaruvga ega plisse pardasi.',
    roomType: 'Mehmonxona',
    fabricColor: 'Bej'
  },
  {
    id: 'plisse-real-29',
    title: 'Chang va Kir Yuqtirmaydigan Antistatik Plisse',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/BHQrfDXL/photo-2022-09-03-16-50-44-2.jpg',
    description: 'Chang va yog‘ yuqmaydigan maxsus singdiruvchan to‘qimali mato bilan ishlangan plisse.',
    roomType: 'Oshxona & Balkon',
    fabricColor: 'Kulrang'
  },
  {
    id: 'plisse-real-30',
    title: 'Katta Fransuz Oynalari Uchun Keng Plisse Montaji',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/yFBzppSP/photo-2022-09-03-16-50-47.jpg',
    description: 'Baland fransuz oynalarida ham shaklini yo‘qotmaydigan mustahkam plisse tizimi.',
    roomType: 'Fransuz oyna',
    fabricColor: 'Oq marvarid'
  },
  {
    id: 'plisse-real-31',
    title: 'Shinam Yotoqxona Uchun Sokin Pastel Plisse Parda',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/0RbLf4fQ/photo-2022-09-03-16-50-46.jpg',
    description: 'Uyqu va dam olish vaqtida sokin va yoqimli muhit yaratuvchi nozik plisse montaji.',
    roomType: 'Yotoqxona',
    fabricColor: 'Pastel pushti'
  },
  {
    id: 'plisse-real-32',
    title: 'Yon Simli Fiksatorli Mustahkam Plisse Jaluzisi',
    category: 'Plisse jaluzi',
    image: 'https://i.ibb.co/0jHfB9SH/photo-2022-09-03-16-50-45.jpg',
    description: 'Oyna ochilib-yopilganda tebranmaydigan, yon simli mustahkam fiksatorli plisse montaji.',
    roomType: 'Deraza & Eshik',
    fabricColor: 'Krem'
  }
];

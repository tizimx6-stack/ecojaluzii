import { PortfolioProject } from '../types';

export interface ComboProjectItem extends PortfolioProject {
  roomType?: string;
  fabricColor?: string;
}

// REAL QILINGAN ISHLAR — COMBO JALUZI MONTAJLARI (PORTFOLIO)
export const COMBO_GALLERY_PROJECTS: ComboProjectItem[] = [
  {
    id: 'combo-gallery-1',
    title: 'Kottej Oshxonasi Uchun Zich To‘qimali Combo Pardasi',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/k27GbDXC/photo-2022-02-03-22-00-18.jpg',
    description: 'Chang va quyoshdan 100% himoyalovchi antistatik tolalardan ishlangan Combo jaluzi montaji.',
    roomType: 'Oshxona',
    fabricColor: 'Klassik bej'
  },
  {
    id: 'combo-gallery-2',
    title: 'Katta Zaldagi Deraza Tavaqalariga Combo O‘rnatilishi',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/RpYNGdQK/photo-2022-02-03-22-00-02.jpg',
    description: 'Har bir deraza qanotiga alohida zich fiksatorlar bilan o‘rnatilgan Combo tizimi.',
    roomType: 'Zal',
    fabricColor: 'Sutli krem'
  },
  {
    id: 'combo-gallery-3',
    title: 'Neo-Klassik Interyer Uchun Shokolad Rangli Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/jvtPnfjG/photo-2022-08-18-12-26-36.jpg',
    description: 'Quyosh nurini me’yorida sozlovchi va hashamatli ko‘rinish beruvchi qoramtir Combo matosi.',
    roomType: 'Mehmonxona',
    fabricColor: 'Shokolad'
  },
  {
    id: 'combo-gallery-4',
    title: 'Oq Emal Romlar Uchun Moslashtirilgan Combo Jaluzi',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/35CvKLdZ/photo-2022-08-18-12-26-35.jpg',
    description: 'Oynaning ochilishiga xalaqit bermaydigan ixcham o‘lchamdagi qulay Combo o‘rnatilishi.',
    roomType: 'Yotoqxona',
    fabricColor: 'Oq'
  },
  {
    id: 'combo-gallery-5',
    title: 'Panoramali Oyna Uchun Keng Qamrovli Combo Loyihasi',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/3YvXF6f9/photo-2021-11-14-10-31-01.jpg',
    description: 'Katta maydonli oyna uchun maxsus kuchaytirilgan rolik mexanizmi bilan o‘rnatildi.',
    roomType: 'Vitraj',
    fabricColor: 'Grafit'
  },
  {
    id: 'combo-gallery-6',
    title: 'Ofis va Ish Kabineti Uchun Nufuzli Combo Jaluzi',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/9mzzL9C6/photo-2022-02-14-18-52-01.jpg',
    description: 'Ish muhiti uchun qulay yorug‘lik taratuvchi, jiddiy va toza dizayndagi Combo tizimi.',
    roomType: 'Ofis',
    fabricColor: 'Kulrang'
  },
  {
    id: 'combo-gallery-7',
    title: 'Kvartira Balkon va Lodjiyasi Uchun Combo Jaluzi',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/ccqrpvvH/photo-2021-11-11-16-37-28.jpg',
    description: 'Yozgi quyosh jaziramasidan saqlovchi va xonani salqin tutuvchi Combo pardalari.',
    roomType: 'Balkon',
    fabricColor: 'Oq-krem'
  },
  {
    id: 'combo-gallery-8',
    title: 'Hashamatli Zallar Uchun Maxsus Jakard Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/TV8fvf0/photo-2025-03-15-03-12-11.jpg',
    description: 'Maxsus yaltiroq va relyefli naqshlarga ega Yevropa matosidan tayyorlangan Combo.',
    roomType: 'Zal',
    fabricColor: 'Oltin bej'
  },
  {
    id: 'combo-gallery-9',
    title: 'Katta Derazali Kottej Uchun Combo Jaluzilari',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/VYZymtTN/photo-2025-03-15-03-12-09.jpg',
    description: 'Shiftga mahkamlangan va deraza bo‘ylab silliq harakatlanuvchi zamonaviy Combo montaji.',
    roomType: 'Kottej',
    fabricColor: 'Bej'
  },
  {
    id: 'combo-gallery-10',
    title: 'Qulay Oshxona Uchun Namlikka Chidamli Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/PkPT4ky/photo-2025-03-15-03-06-09.jpg',
    description: 'Oson tozalanadigan, antistatik chang qaytaruvchi qoplamali Combo jaluzi.',
    roomType: 'Oshxona',
    fabricColor: 'Oq'
  },
  {
    id: 'combo-gallery-11',
    title: 'Pastel Rangli Yotoqxona Kun-Tun Combo Jaluzi',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/0jLTv8zp/photo-2025-03-15-02-58-27.jpg',
    description: 'Tungi uyqu uchun to‘liq yorug‘lik to‘suvchi va kunduzi yumshoq yorug‘lik beruvchi tizim.',
    roomType: 'Yotoqxona',
    fabricColor: 'Sutli krem'
  },
  {
    id: 'combo-gallery-12',
    title: 'Mehmonxona Oynalariga O‘rnatilgan Elegant Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/GQPDh9Yd/photo-2025-03-15-02-58-25.jpg',
    description: 'Interyer ranglariga 100% moslab tanlangan original Turkiya Combo matosi.',
    roomType: 'Mehmonxona',
    fabricColor: 'Klassik bej'
  },

  {
    id: 'combo-gallery-20',
    title: 'Naqshli Relyefli Lux Combo Loyihasi',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/j95KQNG0/photo-2026-02-27-10-40-43.jpg',
    description: 'Yangi binodagi zamonaviy oshxona oynalariga o‘rnatilgan relyefli nafis to‘qimali Combo.',
    roomType: 'Oshxona',
    fabricColor: 'Oltin krem'
  },
  {
    id: 'combo-gallery-21',
    title: 'Plastik Oyna Romiga Kassetali Mini Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/zTfLD9Fv/photo-2026-09-01-12-13-43.jpg',
    description: 'Yon yo‘naltiruvchilari bilan deraza ochilganda osilib qolmaydigan kassetali montaj.',
    roomType: 'Balkon',
    fabricColor: 'Oq'
  },
  {
    id: 'combo-gallery-22',
    title: '100% Blackout Zebra Combo O‘rnatilishi',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/jvPzG1Dd/photo-2026-09-03-21-24-44.jpg',
    description: 'Zich qora qatlamli chiziqlari yordamida yopiq holatda xonani qorong‘i qiluvchi maxsus montaj.',
    roomType: 'Yotoqxona',
    fabricColor: 'Grafit'
  }
];

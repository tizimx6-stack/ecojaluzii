import { PortfolioProject } from '../types';

export interface RolloProjectItem extends PortfolioProject {
  roomType?: string;
  fabricType?: string;
}

// REAL QILINGAN ISHLAR — ROLLO (RULONLI) JALUZI MONTAJLARI (PORTFOLIO)
export const ROLLO_GALLERY_PROJECTS: RolloProjectItem[] = [
  {
    id: 'rollo-montaj-1',
    title: 'Kottej Mehmonxonasi Uchun Zamonaviy Rollo Montaji',
    category: 'Roller jaluzi',
    image: 'https://i.ibb.co/ksrTr7fr/photo-2025-11-19-22-40-12.jpg',
    description: 'Katta vitraj derazalarga o‘rnatilgan, quyosh nurini 100% to‘suvchi va xonaga nafis salqinlik baxsh etuvchi premium rollo montaji.',
    roomType: 'Kottej & Mehmonxona',
    fabricType: 'Blackout / Termo-himoya'
  },
  {
    id: 'rollo-montaj-2',
    title: 'Zamonaviy Ofis Derazalariga O‘rnatilgan Rollo Parda',
    category: 'Roller jaluzi',
    image: 'https://i.ibb.co/jkcvwbT1/photo-2026-09-01-12-14-19.jpg',
    description: 'Ish muhiti uchun qulay yorug‘lik yaratuvchi, kompyuter ekranidagi quyosh aksini to‘suvchi zamonaviy rollo tizimi.',
    roomType: 'Ofis & Kabinet',
    fabricType: 'Screen / Antistatik to‘r'
  },
  {
    id: 'rollo-montaj-3',
    title: 'Klassik va Shinam Xonadon Uchun Rollo (Rulonli) Parda Montaji',
    category: 'Roller jaluzi',
    image: 'https://i.ibb.co/V0yMHf3G/photo-2025-11-19-22-42-32.jpg',
    description: 'Sut rangli bej matoli, xonaga nozik yorug‘lik ulashuvchi va quyosh qizishidan himoyalovchi zamonaviy rollo parda montaji.',
    roomType: 'Yashash xonasi & Zal',
    fabricType: 'Dimout / Yumshoq nur'
  },
  {
    id: 'rollo-montaj-4',
    title: 'Zamonaviy Kottej Uchun Nafis To‘qimali Rollo Parda O‘rnatilishi',
    category: 'Roller jaluzi',
    image: 'https://i.ibb.co/Dgbrp4cm/photo-2025-11-19-22-42-31.jpg',
    description: 'Oltin-jigarrang tusdagi relyefli matoga ega, derazaga mustahkam o‘rnatilgan zanjirli boshqaruvdagi rollo parda montaji.',
    roomType: 'Kottej & Yotoqxona',
    fabricType: 'Klassik relyefli to‘qima'
  },
  {
    id: 'rollo-montaj-5',
    title: 'Plastik Deraza Romi Tavaqalariga Kassetali Mini Rollo Montaji',
    category: 'Roller jaluzi',
    image: 'https://i.ibb.co/ZznV0Zc2/photo-2026-09-01-12-14-47.jpg',
    description: 'Deraza qanotlariga zich o‘rnatilgan, shamolda tebranmaydigan va deraza ochilganda osilib qolmaydigan kassetali rollo montaji.',
    roomType: 'Oyna tavaqasi & Balkon',
    fabricType: 'Mini kassetali'
  }
];

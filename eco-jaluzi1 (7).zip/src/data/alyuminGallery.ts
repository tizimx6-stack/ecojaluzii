import { PortfolioProject } from '../types';

export interface AlyuminProjectItem extends PortfolioProject {
  roomType?: string;
  fabricColor?: string;
}

export const ALYUMIN_GALLERY_PROJECTS: AlyuminProjectItem[] = [
  {
    id: 'alyumin-gallery-1',
    title: 'Oshxona va Sanuzel Uchun 25mm Alyumin Gorizontal Jaluzi',
    category: 'Alyumin jaluzi',
    image: 'https://i.ibb.co/svmxwdTm/photo-2026-07-11-23-06-09.jpg',
    description: '100% namlikka, suv tomchilariga va haroratga chidamli mustahkam 25mm alyuminiy gorizontal jaluzi tizimi.',
    roomType: 'Oshxona & Sanuzel',
    fabricColor: 'Kumushrang metallik'
  },
  {
    id: 'alyumin-gallery-2',
    title: 'Zamonaviy Ofis va Ish Kabineti Alyuminiy Jaluzisi',
    category: 'Alyumin jaluzi',
    image: 'https://i.ibb.co/79JK2DK/photo-2026-01-27-14-02-22.jpg',
    description: 'Quyoshning ko‘zni qamashtiruvchi nurlarini 360° lamellar burilishi bilan aniq yo‘naltiruvchi sifatli montaj.',
    roomType: 'Ofis & Kabinet',
    fabricColor: 'Oq mat'
  },
  {
    id: 'alyumin-gallery-3',
    title: 'Plastik Deraza Romiga Mahkamlangan Alyuminiy Jaluzi',
    category: 'Alyumin jaluzi',
    image: 'https://i.ibb.co/PZn0Wh08/photo-2026-01-27-14-02-21-4.jpg',
    description: 'Oyna tavaqasiga zich o‘rnatilgan, shamollatish rejimida osilib qolmaydigan yon fiksatorli ixcham tizim.',
    roomType: 'Deraza & Balkon',
    fabricColor: 'Klassik bej'
  }
];

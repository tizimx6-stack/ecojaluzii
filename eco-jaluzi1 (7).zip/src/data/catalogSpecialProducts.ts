import { Product } from '../types';

export interface CatalogFolderItem {
  id: string;
  name: string;
  category: string;
  image: string;
  description: string;
  material?: string;
  pricePerSqm?: number;
  texture?: string;
  roomType?: string;
}

// 1. ROLLO JALUZI KATALOGI (Mahsulotlar katalogidagi barcha real namunalar)
export const ROLLO_CATALOG_ITEMS: CatalogFolderItem[] = [
  {
    id: 'cat-rollo-1',
    name: 'Premium Rollo Blackout 100% — To‘liq Qorong‘ilashtiruvchi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/3y3FB3sn/photo-2026-10-01-20-48-17.jpg',
    description: 'Quyosh nurlarini 100% to‘suvchi va xonada mukammal qulaylik, salqinlik yaratuvchi maxsus 3 qatlamli Blackout rollo pardasi.',
    material: '100% Blackout / Termo-himoya',
    pricePerSqm: 165000,
    roomType: 'Yotoqxona & Mehmonxona'
  },
  {
    id: 'cat-rollo-2',
    name: 'Skandinavcha Shinam Rollo Dimout Matoli Parda',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/ZRvkB213/photo-2026-10-01-20-45-04-2.jpg',
    description: 'Yorug‘likni muloyim taratuvchi, xonaga nafis tabiiy yorug‘lik va iliqlik bag‘ishlovchi teksturali Dimout matosi.',
    material: 'Dimout / Yumshoq nur',
    pricePerSqm: 155000,
    roomType: 'Yashash xonasi & Zal'
  },
  {
    id: 'cat-rollo-3',
    name: 'Zamonaviy Ofis va Kabinet Uchun Rollo Screen Tizimi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/8LTq7QQR/photo-2026-10-01-20-44-41.jpg',
    description: 'Tashqi ko‘rinishni to‘smagan holda kompyuter ekranidagi quyosh aksini (blik) yo‘qotuvchi yuqori texnologiyali Screen matosi.',
    material: 'Screen / Antistatik to‘r',
    pricePerSqm: 170000,
    roomType: 'Ofis & Ish kabineti'
  },
  {
    id: 'cat-rollo-4',
    name: 'Klassik Bej Teksturali Rollo Jaluzi — Shinam Xonadon',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/HfC6zdjZ/photo-2026-10-01-20-44-06-2.jpg',
    description: 'Nafis to‘qimasi bilan mehmonxona va yotoqxonalar uchun qulaylik yaratuvchi klassik rulonli parda.',
    material: 'Klassik teksturali poliester',
    pricePerSqm: 150000,
    roomType: 'Kottej & Mehmonxona'
  },
  {
    id: 'cat-rollo-5',
    name: 'Oshxona va Oshxona Zonasi Uchun Namlikka Chidamli Rollo',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/Q3dNs8Mc/photo-2026-10-01-20-44-14.jpg',
    description: 'Yog‘ va namlikni o‘ziga tortmaydigan, nam latta bilan bir zumda tozalanadigan oshxona uchun ideal rollo parda.',
    material: 'Namlikka chidamli gidrofob mato',
    pricePerSqm: 160000,
    roomType: 'Oshxona & Oshxona zonasi'
  },
  {
    id: 'cat-rollo-6',
    name: 'Hashamatli Jakkar To‘qimali Rollo Parda Modeli',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/bMYCRP30/photo-2026-10-01-20-43-57.jpg',
    description: 'Nafis bo‘rtma naqshli jakkard matosidan ishlangan, xonaga nafislik va did bag‘ishlovchi eksklyuziv model.',
    material: 'Jakkard naqshli premium to‘qima',
    pricePerSqm: 180000,
    roomType: 'Mehmonxona & Dam olish xonasi'
  },
  {
    id: 'cat-rollo-7',
    name: 'Minimalistik Kulrang Grafit Rollo Jaluzi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/8gQfNcHB/photo-2026-10-01-20-43-43.jpg',
    description: 'Zamonaviy minimalizm va loft interyerlar uchun mo‘ljallangan toza, aniq chiziqlarga ega rollo tizimi.',
    material: 'Zich tolali monoxrom mato',
    pricePerSqm: 155000,
    roomType: 'Zal & Zamonaviy ofis'
  },
  {
    id: 'cat-rollo-8',
    name: 'Oltin Qum Jiloli Elegance Rollo Parda',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/9HPTG0LZ/photo-2026-10-01-20-43-28.jpg',
    description: 'Quyosh nurlari tushganda mayin jilo beruvchi, xonaga iliqlik va yorug‘lik baxsh etuvchi jozibali model.',
    material: 'Jiloli mikro-tolali mato',
    pricePerSqm: 175000,
    roomType: 'Mehmonxona & Kottej'
  },
  {
    id: 'cat-rollo-9',
    name: 'Sut Rangli Marvarid Nafis Rollo Jaluzi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/DHxwwZCc/photo-2026-10-01-20-43-19.jpg',
    description: 'Har qanday rangdagi interyerga 100% mos tushuvchi, ko‘zni charchatmaydigan tinchlantiruvchi sutli krem matosi.',
    material: 'Tabiiy mato effekti',
    pricePerSqm: 150000,
    roomType: 'Yotoqxona & Bolalar xonasi'
  },
  {
    id: 'cat-rollo-10',
    name: 'Panoramali Vitraj Derazalar Uchun Keng Formatli Rollo',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/G3MmBzHC/photo-2026-10-01-20-42-59.jpg',
    description: 'Katta maydonli oynalar uchun maxsus mustahkamlangan val va silliq rolik mexanizmi bilan jihozlangan kuchli tizim.',
    material: 'Kuchaytirilgan zich tolali mato',
    pricePerSqm: 185000,
    roomType: 'Vitraj & Katta zallar'
  },
  {
    id: 'cat-rollo-11',
    name: 'Bolalar Xonasi Uchun Ekologik Sof Rollo Jaluzi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/Qv9ffWhZ/photo-2026-10-01-20-42-48.jpg',
    description: 'Gipoallergen, hidsiz va bolalar salomatligi uchun to‘liq xavfsiz OEKO-TEX sertifikatiga ega ekologik toza mato.',
    material: 'Ekologik sof tola',
    pricePerSqm: 160000,
    roomType: 'Bolalar xonasi & Yotoqxona'
  },
  {
    id: 'cat-rollo-12',
    name: 'Kassetali Mini Rollo (Plastik Deraza Romiga Zich)',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/bqwxq2B/photo-2026-10-01-20-42-33.jpg',
    description: 'Oyna qanotiga bevosita mahkamlanadigan, deraza ochilganda shamolda tebranmaydigan ixcham qulay tizim.',
    material: 'Kassetali poliester matosi',
    pricePerSqm: 165000,
    roomType: 'Oyna qanoti & Balkon'
  },
  {
    id: 'cat-rollo-13',
    name: 'Klassik Shokolad Rangi Blackout Rollo Parda',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/KzxYsJqz/photo-2026-10-01-20-42-26.jpg',
    description: 'Chuqur shokolad tusidagi quyuq rang, quyosh nurini mukammal to‘sadi va xonaga hashamatli qiyofa beradi.',
    material: 'To‘liq qorong‘ulashtiruvchi Blackout',
    pricePerSqm: 170000,
    roomType: 'Kinozal & Yotoqxona'
  },
  {
    id: 'cat-rollo-14',
    name: 'Yengil Zig‘ir Teksturali Natural Rollo Jaluzi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/N6LJsPtS/photo-2026-10-01-20-41-53.jpg',
    description: 'Tabiiy zig‘ir to‘qimasini eslatuvchi ekologik uslubdagi xonalar uchun eng mos nafis tanlov.',
    material: 'Zig‘ir effekti beruvchi to‘qima',
    pricePerSqm: 165000,
    roomType: 'Mehmonxona & Oshxona'
  },
  {
    id: 'cat-rollo-15',
    name: 'Zamonaviy Restoran va Kafelar Uchun Rollo Tizimi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/Dfy72Qfy/photo-2026-10-01-20-41-41.jpg',
    description: 'Mijozlar uchun sokin va shinam atmosfera yaratuvchi, tashqi ko‘cha shovqini va oftobni me’yorida to‘suvchi parda.',
    material: 'Yuqori sifatli qalin to‘qima',
    pricePerSqm: 175000,
    roomType: 'Restoran & Qahvaxona'
  },
  {
    id: 'cat-rollo-16',
    name: 'Pastel Krem Rangli Elegant Rollo Modeli',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/ch8vtJ2s/photo-2026-10-01-20-41-06.jpg',
    description: 'Yumshoq pastel tonlarda ishlangan, har qanday xonaga shinamlik va tinchlik olib kiruvchi model.',
    material: 'Yumshoq mato to‘qimasi',
    pricePerSqm: 155000,
    roomType: 'Yotoqxona & Mehmonxona'
  },
  {
    id: 'cat-rollo-17',
    name: 'Antratsit Mat Rangli Loft Rollo Parda',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/5NYBQF2/photo-2026-10-01-20-40-51.jpg',
    description: 'To‘q qora-kulrang antratsit matosi, zamonaviy uslubdagi kabinetlar va xonadonlar uchun eng zamonaviy yechim.',
    material: 'Mat antratsit tola',
    pricePerSqm: 170000,
    roomType: 'Loft & Ish kabineti'
  },
  {
    id: 'cat-rollo-18',
    name: 'Balkon va Terassa Uchun Quyoshdan Himoya Rollo',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/4gVbsQbK/photo-2026-10-01-20-40-41.jpg',
    description: 'Yozgi jaziramadan xonadonni salqin saqlashga yordam beruvchi ultrabinafsha nurlarini qaytaruvchi parda.',
    material: 'UV-himoyali mato',
    pricePerSqm: 160000,
    roomType: 'Balkon & Ayvon'
  },
  {
    id: 'cat-rollo-19',
    name: 'Zich Bo‘rtma To‘qimali Premium Rollo Jaluzi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/6JNswKNv/photo-2026-10-01-20-40-28.jpg',
    description: 'Maxsus bo‘rtma relyefli Yevropa matosidan tayyorlangan, uzoq yillar o‘z sifatini yo‘qotmaydigan parda.',
    material: 'Relyefli poliester',
    pricePerSqm: 180000,
    roomType: 'Kottej & Zal'
  },
  {
    id: 'cat-rollo-20',
    name: 'Qoramtir-Zangori Tinchlantiruvchi Rollo Parda',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/VWWLCBwp/photo-2026-10-01-20-40-11.jpg',
    description: 'Chuqur sokin ranglar uyg‘unligi, uyqu sifatini yaxshilash va kunduzgi tinch dam olish uchun ayni muddao.',
    material: 'Zich qalin mato',
    pricePerSqm: 165000,
    roomType: 'Yotoqxona'
  },
  {
    id: 'cat-rollo-21',
    name: 'Quyosh Nurini Taratuvchi Silk-Effect Rollo',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/B2sk11hr/photo-2026-10-01-20-40-00.jpg',
    description: 'Ipak jilosi beruvchi nafis silliq to‘qima, derazalarga nafislik va yengillik baxsh etadi.',
    material: 'Ipak effekti tola',
    pricePerSqm: 175000,
    roomType: 'Zal & Katta xona'
  },
  {
    id: 'cat-rollo-22',
    name: 'Yumshoq Bej Qum Tusidagi Rollo Jaluzi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/Lzs2M6fx/photo-2026-10-01-20-39-43.jpg',
    description: 'Klassik qum rangi, oyna romiga o‘rnatilganda xonadagi haroratni 4-6 darajaga pasaytiradi.',
    material: 'Termo-izolyatsiyalovchi tola',
    pricePerSqm: 160000,
    roomType: 'Oshxona & Balkon'
  },
  {
    id: 'cat-rollo-23',
    name: 'Neo-Klassik Interyer Uchun Oq-Krem Rollo Tizimi',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/ZRnBnfKp/photo-2026-10-01-20-38-29.jpg',
    description: 'Neo-klassik va zamonaviy xonadonlar uchun eng ommabop va chiroyli rulonli pardalarimizdan biri.',
    material: 'Oliy navli poliester',
    pricePerSqm: 155000,
    roomType: 'Mehmonxona & Xonadon'
  },
  {
    id: 'cat-rollo-24',
    name: 'Yotoqxona Uchun Sokin Qorong‘ulashtiruvchi Rollo',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/HLBHvghF/photo-2026-10-01-20-38-12.jpg',
    description: 'Ertalabki quyosh nuri uyquni buzmasligi uchun 100% yorug‘lik to‘suvchi maxsus qatlamli model.',
    material: 'Blackout 3 qavatli',
    pricePerSqm: 170000,
    roomType: 'Yotoqxona'
  },
  {
    id: 'cat-rollo-25',
    name: 'Ofis Muzokaralar Xonasi Uchun Rollo Screen',
    category: 'Rollo jaluzi',
    image: 'https://i.ibb.co/sd6LrLR5/photo-2026-10-01-20-37-51.jpg',
    description: 'Projektor va ekranlar bilan ishlashda qulaylik yaratuvchi zamonaviy ofis rulonli pardasi.',
    material: 'Texnik Screen to‘qima',
    pricePerSqm: 175000,
    roomType: 'Ofis & Majlislar zali'
  }
];

// 2. DIKEY JALUZI KATALOGI (Foydalanuvchi yuborgan 28 ta real katalog namunalari)
export const DIKEY_CATALOG_ITEMS: CatalogFolderItem[] = [
  {
    id: 'cat-dikey-1',
    name: 'Hashamatli Kottej Zali Uchun Saroyona Dikey Parda (№1)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/zTTkNdF2/photo-2026-08-28-11-39-23.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: '22XH Premium Ipak & Tyul',
    pricePerSqm: 195000,
    roomType: 'Kottej & Mehmonxona'
  },
  {
    id: 'cat-dikey-2',
    name: 'Klassik 22XH Burmali Eksklyuziv Dikey Pardasi (№2)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/JFRMRW0F/photo-2026-08-28-11-39-22.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: 'Tyul + Dikey kombi',
    pricePerSqm: 195000,
    roomType: 'Zal & Vitraj oyna'
  },
  {
    id: 'cat-dikey-3',
    name: 'Zamonaviy Vitraj Derazalar Uchun Dikey Tizimi (№3)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/67p0Jpgc/photo-2026-08-28-11-39-20.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: 'Saroyona to‘qima',
    pricePerSqm: 200000,
    roomType: 'Kottej & Mehmonxona'
  },
  {
    id: 'cat-dikey-4',
    name: 'Yashash Xonasi va Mehmonxona Uchun Nafis Dikey (№4)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/LdKdNfPn/photo-2026-08-28-11-39-19.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: '22XH Premium Ipak',
    pricePerSqm: 195000,
    roomType: 'Zal & Vitraj oyna'
  },
  {
    id: 'cat-dikey-5',
    name: 'Oltin-Krem Jiloli Premium Dikey Pardalar (№5)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/SDYrxK1S/photo-2026-08-28-11-39-18.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: 'Tyul + Dikey',
    pricePerSqm: 205000,
    roomType: 'Kottej & Mehmonxona'
  },
  {
    id: 'cat-dikey-6',
    name: 'Marvarid Oq Tyul Va Dikey Pardalari Uyg‘unligi (№6)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/HT4NrvfP/photo-2026-08-28-11-39-17.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: 'Saroyona to‘qima',
    pricePerSqm: 195000,
    roomType: 'Zal & Vitraj oyna'
  },
  {
    id: 'cat-dikey-7',
    name: 'Katta Zal va Panoramik Derazalar Uchun Dikey (№7)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/DPj0Qxy5/photo-2026-08-28-11-39-15.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: '22XH Premium Ipak',
    pricePerSqm: 210000,
    roomType: 'Kottej & Mehmonxona'
  },
  {
    id: 'cat-dikey-8',
    name: 'Ofis va Nufuzli Kabinetlar Uchun Zamonaviy Dikey (№8)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/HpfYkL2y/photo-2026-08-28-11-39-14.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: 'Tyul + Dikey',
    pricePerSqm: 190000,
    roomType: 'Zal & Vitraj oyna'
  },
  {
    id: 'cat-dikey-9',
    name: 'Yotoqxona Uchun Sokin va Shinam Dikey Modeli (№9)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/b5WF4kt6/photo-2026-08-28-11-39-13.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: 'Saroyona to‘qima',
    pricePerSqm: 195000,
    roomType: 'Kottej & Mehmonxona'
  },
  {
    id: 'cat-dikey-10',
    name: 'Restoran va Tadbirlar Zali Uchun Maxsus Dikey (№10)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/CKwWqtV2/photo-2026-08-28-11-39-11.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: '22XH Premium Ipak',
    pricePerSqm: 215000,
    roomType: 'Zal & Vitraj oyna'
  },
  {
    id: 'cat-dikey-11',
    name: 'Yevropa Standartidagi 180° Buriluvchi Dikey (№11)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/bgk3sMym/photo-2026-08-28-11-39-10.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: 'Tyul + Dikey',
    pricePerSqm: 195000,
    roomType: 'Kottej & Mehmonxona'
  },
  {
    id: 'cat-dikey-12',
    name: 'Nafis Ipak To‘qimali Eksklyuziv Dikey Tizimi (№12)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/7dLKRG0b/photo-2026-08-28-11-39-09.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: 'Saroyona to‘qima',
    pricePerSqm: 200000,
    roomType: 'Zal & Vitraj oyna'
  },
  {
    id: 'cat-dikey-13',
    name: 'Pastel Krem Rangi 22XH Nafis Dikey Modeli (№13)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/yFJ9LwFV/photo-2026-08-28-11-39-07.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: '22XH Premium Ipak',
    pricePerSqm: 195000,
    roomType: 'Kottej & Mehmonxona'
  },
  {
    id: 'cat-dikey-14',
    name: 'Vitraj Oyna Uchun Saroyona Vertikal Dikey (№14)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/9mY09GHM/photo-2026-06-06-17-47-56-2.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: 'Tyul + Dikey',
    pricePerSqm: 210000,
    roomType: 'Zal & Vitraj oyna'
  },
  {
    id: 'cat-dikey-15',
    name: 'Quyosh Nurini Mayin Taratuvchi Oq Tyul Dikey (№15)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/NdPm66DW/photo-2026-08-28-11-39-06.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: 'Saroyona to‘qima',
    pricePerSqm: 195000,
    roomType: 'Kottej & Mehmonxona'
  },
  {
    id: 'cat-dikey-16',
    name: 'Keng Deraza Romlari Uchun Mustahkam Dikey (№16)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/DfJJfRM2/photo-2026-08-28-11-38-59.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: '22XH Premium Ipak',
    pricePerSqm: 200000,
    roomType: 'Zal & Vitraj oyna'
  },
  {
    id: 'cat-dikey-17',
    name: 'Shinam Mehmonxona Uchun Burmali Dikey Pardasi (№17)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/MDHLVHMG/photo-2026-08-28-11-38-57.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: 'Tyul + Dikey',
    pricePerSqm: 195000,
    roomType: 'Kottej & Mehmonxona'
  },
  {
    id: 'cat-dikey-18',
    name: 'Neo-Klassik Interyer Uchun Oltin Bej Dikey (№18)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/Kxpk553w/photo-2026-08-28-11-38-56.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: 'Saroyona to‘qima',
    pricePerSqm: 205000,
    roomType: 'Zal & Vitraj oyna'
  },
  {
    id: 'cat-dikey-19',
    name: 'Sutli Shampan Rangi Hashamatli Dikey Modeli (№19)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/d4F14Wy4/photo-2026-08-28-11-38-55.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: '22XH Premium Ipak',
    pricePerSqm: 200000,
    roomType: 'Kottej & Mehmonxona'
  },
  {
    id: 'cat-dikey-20',
    name: 'Kottej Panoramik Zali Uchun 180° Dikey (№20)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/twnH7xH8/photo-2026-07-13-17-00-56-3.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: 'Tyul + Dikey',
    pricePerSqm: 215000,
    roomType: 'Zal & Vitraj oyna'
  },
  {
    id: 'cat-dikey-21',
    name: 'Baland Shiftli Xonadon Uchun Vertikal Dikey (№21)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/fVhD0Rcq/photo-2026-07-13-17-00-56-2.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: 'Saroyona to‘qima',
    pricePerSqm: 195000,
    roomType: 'Kottej & Mehmonxona'
  },
  {
    id: 'cat-dikey-22',
    name: 'Restoran va Tadbirlar Zali Uchun Maxsus Dikey (№22)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/vyZ56vg/photo-2026-07-13-17-00-56.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: '22XH Premium Ipak',
    pricePerSqm: 210000,
    roomType: 'Zal & Vitraj oyna'
  },
  {
    id: 'cat-dikey-23',
    name: 'Yevropa Standartidagi 180° Buriluvchi Dikey (№23)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/8gbV9P5m/photo-2026-07-13-17-00-55-7.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: 'Tyul + Dikey',
    pricePerSqm: 195000,
    roomType: 'Kottej & Mehmonxona'
  },
  {
    id: 'cat-dikey-24',
    name: 'Nafis Ipak To‘qimali Eksklyuziv Dikey Tizimi (№24)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/yFw6x2ft/photo-2026-07-13-17-00-55-6.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: 'Saroyona to‘qima',
    pricePerSqm: 200000,
    roomType: 'Zal & Vitraj oyna'
  },
  {
    id: 'cat-dikey-25',
    name: 'Hashamatli Kottej Zali Uchun Saroyona Dikey Parda (№25)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/1SvqtWv/photo-2026-07-13-17-00-55-5.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: '22XH Premium Ipak',
    pricePerSqm: 205000,
    roomType: 'Kottej & Mehmonxona'
  },
  {
    id: 'cat-dikey-26',
    name: 'Klassik 22XH Burmali Eksklyuziv Dikey Pardasi (№26)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/bD0VD8C/photo-2026-07-13-17-00-55-4.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: 'Tyul + Dikey',
    pricePerSqm: 195000,
    roomType: 'Zal & Vitraj oyna'
  },
  {
    id: 'cat-dikey-27',
    name: 'Zamonaviy Vitraj Derazalar Uchun Dikey Tizimi (№27)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/KxBQQ0Vv/photo-2026-07-13-17-00-55-3.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: 'Saroyona to‘qima',
    pricePerSqm: 200000,
    roomType: 'Kottej & Mehmonxona'
  },
  {
    id: 'cat-dikey-28',
    name: 'Yashash Xonasi va Mehmonxona Uchun Nafis Dikey (№28)',
    category: 'Dikey pardalar',
    image: 'https://i.ibb.co/Zzr2PKTm/photo-2026-07-13-17-00-55-2.jpg',
    description: 'Katta zallar, mehmonxonalar va kottejlar uchun 180° erkin buriluvchi, nafis burmali va quyosh nurini jozibali taratuvchi oliy toifali Dikey parda tizimi.',
    material: '22XH Premium Ipak',
    pricePerSqm: 200000,
    roomType: 'Zal & Vitraj oyna'
  }
];

// 3. COMBO (KUN-TUN) JALUZI KATALOGI (Foydalanuvchi yuborgan 14 ta real katalog namunalari)
export const COMBO_CATALOG_ITEMS: CatalogFolderItem[] = [
  {
    id: 'cat-combo-1',
    name: 'Hashamatli Mehmonxona Uchun Premium Kun-Tun Combo Jaluzi',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/Kp5XQX4n/photo-2026-10-01-20-53-09.jpg',
    description: 'Quyosh nurini 2 qavatli shaffof va qalin to‘qimalar orqali nozik boshqaruvchi yangi modeldagi Combo jaluzi.',
    material: 'Krem-Oltin jiloli mato',
    pricePerSqm: 175000,
    roomType: 'Mehmonxona & Zal'
  },
  {
    id: 'cat-combo-2',
    name: 'Keng Panoramik Derazalar Uchun Zamonaviy Combo Montaji',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/yFH4VRgg/photo-2026-10-01-20-52-57.jpg',
    description: 'Katta oynali kottej va xonadonlar uchun qulay zanjirli va pishiq mexanizmli Combo tizimi.',
    material: 'Klassik bej antistatik tola',
    pricePerSqm: 165000,
    roomType: 'Kottej & Zal'
  },
  {
    id: 'cat-combo-3',
    name: 'Yotoqxona Uchun Sokin va Shinam Combo (Zebra) Pardasi',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/3tPF198/photo-2026-10-01-20-52-48.jpg',
    description: 'Tungi to‘liq qorong‘ulik va kunduzgi mayin yorug‘lik rejimlariga ega qulay yotoqxona jaluzisi.',
    material: 'Pastel Krem gofre tola',
    pricePerSqm: 170000,
    roomType: 'Yotoqxona'
  },
  {
    id: 'cat-combo-4',
    name: 'Klassik va Neoklassik Interyer Uchun Jakard Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/Y4bNTyr6/photo-2026-10-01-20-52-15.jpg',
    description: 'Yevropa sifat standartlariga javob beruvchi antistatik chang tutmaydigan jakard to‘qimali Combo.',
    material: 'Marvarid Oq jakkard',
    pricePerSqm: 180000,
    roomType: 'Mehmonxona'
  },
  {
    id: 'cat-combo-5',
    name: 'Kottej Oshxonasi va Ovqatlanish Zonasi Uchun Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/h17FN87y/photo-2026-10-01-20-51-53.jpg',
    description: 'Namlikka chidamli va oson tozalanuvchi maxsus tolalardan ishlangan zamonaviy Combo tizimi.',
    material: 'Shokolad Bej namlikka chidamli',
    pricePerSqm: 165000,
    roomType: 'Oshxona'
  },
  {
    id: 'cat-combo-6',
    name: 'Xonadon Yashash Xonasi Uchun Nafis Kun-Tun Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/TxFFVkL6/photo-2026-10-01-20-51-39.jpg',
    description: 'Xona dizayniga uyg‘un tushuvchi, oynaning har bir qanotiga alohida mustahkam o‘rnatilgan Combo.',
    material: 'Krem poliester',
    pricePerSqm: 160000,
    roomType: 'Yashash xonasi'
  },
  {
    id: 'cat-combo-7',
    name: 'Zamonaviy Ofis va Kabinet Uchun Jiddiy Grafit Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/xKMgQtTq/photo-2026-10-01-20-51-26.jpg',
    description: 'Ish jarayoni uchun kompyuter ekraniga quyosh nuri tushishini to‘suvchi va qulay muhit yaratuvchi Combo.',
    material: 'Kulrang / Grafit texnik tola',
    pricePerSqm: 175000,
    roomType: 'Ofis & Kabinet'
  },
  {
    id: 'cat-combo-8',
    name: 'Balkon va Vitraj Oynalar Uchun Kun-Tun Combo Jaluzi',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/0RJN4k1b/photo-2026-10-01-20-50-45.jpg',
    description: 'Jazirama issiqdan xonani salqin tutuvchi va quyosh nurlarini 100% qaytaruvchi mustahkam tizim.',
    material: 'Sutli oq UV-himoya',
    pricePerSqm: 165000,
    roomType: 'Balkon & Terassa'
  },
  {
    id: 'cat-combo-9',
    name: 'Bolalar Xonasi Uchun Ekologik Toza Havfsiz Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/HD8pyPd5/photo-2026-10-01-20-50-25.jpg',
    description: 'Gipoallergen, hidsiz va bolalar salomatligi uchun to‘liq xavfsiz materiallardan tayyorlangan Combo.',
    material: 'Yorqin bej eko-tola',
    pricePerSqm: 170000,
    roomType: 'Bolalar xonasi'
  },
  {
    id: 'cat-combo-10',
    name: 'Hashamatli Mehmonxona Uchun Oltin Jiloli Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/RWnL0sV/photo-2026-10-01-20-50-04.jpg',
    description: 'Interyerga boy va zamonaviy ko‘rinish bag‘ishlovchi jiloli iplar bilan to‘qilgan oliy sifat Combo.',
    material: 'Oltin Bej jiloli to‘qima',
    pricePerSqm: 185000,
    roomType: 'Mehmonxona'
  },
  {
    id: 'cat-combo-11',
    name: 'Romga To‘g‘ridan-to‘g‘ri Mahkamlangan Ixcham Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/PvBWxmNj/photo-2026-10-01-20-49-40.jpg',
    description: 'Deraza ochilganda osilib qolmaydigan yon fiksatorli qulay va tartibli mini Combo montaji.',
    material: 'Klassik Krem mini kassetali',
    pricePerSqm: 170000,
    roomType: 'Yotoqxona'
  },
  {
    id: 'cat-combo-12',
    name: 'Restoran va Qahvaxona Uchun Shinam Combo Jaluzisi',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/0jtxgnd1/photo-2026-10-01-20-49-26.jpg',
    description: 'Mijozlar uchun sokin va qulay muhit hosil qiluvchi yarim shaffof chiziqli Combo pardalari.',
    material: 'Kofe / Bej qulay to‘qima',
    pricePerSqm: 175000,
    roomType: 'Restoran & Kafe'
  },
  {
    id: 'cat-combo-13',
    name: 'Katta Zallar Uchun Maxsus Keng O‘lchamli Combo',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/Lz8wZLWS/photo-2026-10-01-20-58-40.jpg',
    description: 'Keng maydonli derazalar uchun mustahkamlangan alyumin val va silliq rolik tizimli Combo.',
    material: 'Krem kuchaytirilgan tola',
    pricePerSqm: 180000,
    roomType: 'Katta zal'
  },
  {
    id: 'cat-combo-14',
    name: 'Minimalist Interyer Uchun Monoxrom Combo Pardasi',
    category: 'Combo jaluzi',
    image: 'https://i.ibb.co/3y3FB3sn/photo-2026-10-01-20-48-17.jpg',
    description: 'Zamonaviy minimalizm uslubidagi xonalar uchun qulay yorug‘lik boshqaruviga ega Combo.',
    material: 'Oq / Neytral zich poliester',
    pricePerSqm: 165000,
    roomType: 'Yashash xonasi'
  }
];

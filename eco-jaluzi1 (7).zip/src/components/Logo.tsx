import React from 'react';

interface LogoProps {
  className?: string;
  showText?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export default function Logo({ className = '', showText = true, size = 'md' }: LogoProps) {
  const dimensions = {
    sm: { logo: 'h-8 w-8', text: 'text-sm' },
    md: { logo: 'h-10 w-10', text: 'text-lg' },
    lg: { logo: 'h-16 w-16', text: 'text-2xl' },
  }[size];

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* Circle Logo Mark */}
      <div className={`relative flex items-center justify-center rounded-full bg-brand-cream border border-brand-emerald/10 shadow-md transition-all duration-300 hover:scale-105 overflow-hidden ${dimensions.logo}`}>
        <img
          src="https://i.ibb.co/ddQsPr1/photo-2024-03-09-20-26-07-2.jpg"
          alt="Eco Jaluzi logo"
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
          onError={(e) => {
            e.currentTarget.src = "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=800&q=80";
          }}
        />
      </div>

      {/* Brand Typography */}
      {showText && (
        <div className="flex flex-col">
          <span className={`font-serif font-bold tracking-widest text-brand-emerald-dark ${dimensions.text}`}>
            <span translate="no" className="notranslate">ECO JALUZI</span>
          </span>
        </div>
      )}
    </div>
  );
}

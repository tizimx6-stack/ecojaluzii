import React, { useState } from 'react';
import { Sliders, RefreshCw, Layers, Sun, Moon, Sparkles, Check, DollarSign, BookmarkCheck } from 'lucide-react';

interface Designer3DProps {
  onQuoteRequest: (designSummary: string) => void;
}

export default function Designer3D({ onQuoteRequest }: Designer3DProps) {
  // Simulator States
  const [blindsHeight, setBlindsHeight] = useState(0.4); // 0 = closed, 1 = fully open
  const [slatAngle, setSlatAngle] = useState(30); // Slat angle in degrees (-90 to 90)
  const [color, setColor] = useState('#064e3b'); // Current blinds color hex
  const [colorName, setColorName] = useState('Zumrad yashil');
  const [texture, setTexture] = useState('standard'); // standard, wooden, vertical-stripe, textured
  const [wallStyle, setWallStyle] = useState('cream'); // cream, concrete, wood-panel
  const [lighting, setLighting] = useState<'day' | 'evening'>('day'); // day, evening
  const [saved, setSaved] = useState(false);

  // Pre-configured options
  const colorOptions = [
    { name: 'Zumrad yashil', hex: '#064e3b' },
    { name: 'Tabiiy bej', hex: '#f5f2eb' },
    { name: 'Krem sut', hex: '#fdfaee' },
    { name: 'Nafis kulrang', hex: '#d3d3d3' },
    { name: 'Sokin zaytun', hex: '#556b2f' },
    { name: 'Klassik yong‘oq', hex: '#5c4033' },
    { name: 'Antratsit to‘q', hex: '#383e42' }
  ];

  const wallStyles = [
    { id: 'cream', name: 'Klassik Krem', bg: 'bg-[#faf6f0]', border: 'border-amber-100' },
    { id: 'concrete', name: 'Minimalist Loft', bg: 'bg-[#e2e2e0]', border: 'border-slate-300' },
    { id: 'wood-panel', name: 'Eman Paneli', bg: 'bg-[#ebdcd0]', border: 'border-amber-200' }
  ];

  const textures = [
    { id: 'standard', name: 'Klassik mato', desc: 'Silliq ekologik poliester' },
    { id: 'wooden', name: 'Tabiiy yog‘och', desc: 'Asl eman daraxti teksturasi' },
    { id: 'sheer', name: 'Yarim shaffof', desc: 'Yengil yorug‘lik o‘tkazuvchi' },
    { id: 'blackout', name: 'Zich Blackout', desc: '100% quyoshdan himoya' }
  ];

  const handleSaveDesign = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleGetQuote = () => {
    const summary = `${colorName} rangli, ${textures.find(t => t.id === texture)?.name} turidagi, o‘lchami moslashtirilgan jaluzi dizayni (${lighting === 'day' ? 'KUNDUZGI' : 'TUNGGI'} yorug‘lik testi)`;
    onQuoteRequest(summary);
  };

  // Generate blinds slats
  const totalSlats = 22;
  const activeSlatCount = Math.floor(totalSlats * (1 - blindsHeight));

  const renderSlats = () => {
    const slats = [];
    for (let i = 0; i < totalSlats; i++) {
      const topPosition = (i / totalSlats) * 100;
      const isStacked = i >= activeSlatCount;
      const computedTop = isStacked
        ? (1 - blindsHeight) * 100 + (i - activeSlatCount) * 1.5
        : topPosition;

      // Slat background style depending on texture
      let backgroundStyle = color;
      if (texture === 'wooden') {
        backgroundStyle = `repeating-linear-gradient(90deg, ${color}, ${color} 10px, rgba(0,0,0,0.1) 12px, ${color} 14px)`;
      } else if (texture === 'sheer') {
        backgroundStyle = `${color}cc`; // transparency
      }

      slats.push(
        <div
          key={i}
          className="absolute left-0 right-0 h-3 rounded-[1px] shadow-sm transition-all duration-300 border-b border-black/10"
          style={{
            top: `${computedTop}%`,
            background: backgroundStyle,
            transform: `rotateX(${isStacked ? 0 : slatAngle}deg)`,
            opacity: isStacked && blindsHeight > 0.95 ? 0.15 : 1,
            zIndex: 10 + i,
          }}
        />
      );
    }
    return slats;
  };

  return (
    <section id="designer" className="py-24 bg-brand-beige/40 border-b border-brand-emerald/5">
      <div className="max-w-7xl mx-auto px-6 sm:px-12">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 flex flex-col items-center gap-4">
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-brand-emerald/5 text-brand-emerald text-xs font-semibold uppercase tracking-wider">
            <Sliders className="w-3.5 h-3.5" />
            <span>Interaktiv xona simulyatori</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-brand-emerald-dark">
            Derazangizni o‘zingiz dizayn qiling.
          </h2>
          <div className="h-1 w-12 bg-brand-emerald-light rounded" />
          <p className="text-brand-charcoal/60 font-light max-w-xl text-sm leading-relaxed">
            Derazangiz uchun jaluzi turlarini, ranglarini, materiallarini sinab ko‘ring va xona interyeri bilan mosligini onlayn baholang.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          
          {/* Left Panel: 3D Room Stage Visualizer */}
          <div className="lg:col-span-7 bg-brand-charcoal rounded-3xl overflow-hidden shadow-2xl relative min-h-[450px] sm:min-h-[550px] flex items-center justify-center border-4 border-white/50">
            
            {/* Ambient Wall Background */}
            <div className={`absolute inset-0 transition-colors duration-500 ${
              wallStyle === 'cream' ? 'bg-[#faf6f0]' : wallStyle === 'concrete' ? 'bg-[#e2e2e0]' : 'bg-[#ebdcd0]'
            }`} />

            {/* Simulated Indoor Lamps for Evening */}
            <div className={`absolute inset-0 bg-orange-500/10 mix-blend-color-burn z-20 pointer-events-none transition-opacity duration-500 ${
              lighting === 'evening' ? 'opacity-100' : 'opacity-0'
            }`} />

            {/* Simulated Room Shadowing / Vignette */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/10 via-transparent to-black/15 z-10 pointer-events-none" />

            {/* Outdoor Panorama View (Behind Window) */}
            <div className="absolute w-[60%] h-[75%] rounded-t-full overflow-hidden shadow-[inset_0_0_40px_rgba(0,0,0,0.5)] bg-sky-200 border-4 border-brand-cream relative">
              {/* Day Outdoor Landscape */}
              <div
                className="absolute inset-0 bg-cover bg-center transition-opacity duration-700"
                style={{
                  backgroundImage: `url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80')`,
                  opacity: lighting === 'day' ? 1 : 0
                }}
              />
              {/* Evening Outdoor City Lights */}
              <div
                className="absolute inset-0 bg-cover bg-center transition-opacity duration-700"
                style={{
                  backgroundImage: `url('https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=800&q=80')`,
                  opacity: lighting === 'evening' ? 1 : 0
                }}
              />
              
              {/* Window glass glare */}
              <div className="absolute inset-0 bg-gradient-to-tr from-white/10 via-white/5 to-transparent z-20 pointer-events-none" />

              {/* Window Panes cross grid */}
              <div className="absolute inset-0 flex justify-center z-10 pointer-events-none opacity-40">
                <div className="w-[3px] h-full bg-white" />
              </div>

              {/* The Interactive Blinds */}
              <div className="absolute top-0 left-[6%] right-[6%] h-[92%] z-15">
                {/* Header rail */}
                <div className="absolute top-0 left-0 right-0 h-3.5 bg-brand-charcoal rounded-full shadow border-b border-white/5" />
                
                {/* Slats */}
                <div className="absolute top-3.5 left-0 right-0 bottom-0 overflow-hidden">
                  {renderSlats()}
                </div>
              </div>
            </div>

            {/* Ambient Foreground Decor to Sell the Realism (A plant silhouette or modern lamp) */}
            <div className="absolute bottom-4 left-6 z-25 max-w-[120px] pointer-events-none opacity-70">
              <svg viewBox="0 0 100 120" className="w-full text-brand-emerald-dark" fill="currentColor">
                <path d="M50 120 C50 110, 45 105, 42 90 C35 90, 30 85, 30 80 C30 75, 40 75, 45 82 C48 70, 55 65, 58 50 C62 65, 68 70, 70 85 C75 85, 78 90, 78 95 C78 100, 70 105, 50 120 Z" opacity="0.3"/>
                <path d="M50 120 L50 90" stroke="currentColor" strokeWidth="2" />
                <path d="M50 100 C40 95, 30 90, 20 95 C15 90, 25 80, 35 85" stroke="currentColor" strokeWidth="1.5" fill="none" />
                <path d="M50 105 C60 100, 70 95, 80 100 C85 95, 75 85, 65 90" stroke="currentColor" strokeWidth="1.5" fill="none" />
              </svg>
            </div>

            {/* Day / Night floating badge */}
            <div className="absolute top-6 left-6 z-30 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-brand-charcoal/80 text-brand-cream text-[10px] font-semibold tracking-wider uppercase backdrop-blur-sm border border-white/10">
              {lighting === 'day' ? (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-300 animate-spin-slow" />
                  <span>KUNDUZGI REJIM</span>
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5 text-indigo-300" />
                  <span>TUNGGI REJIM</span>
                </>
              )}
            </div>

            {/* Reset simulator Button */}
            <button
              onClick={() => {
                setBlindsHeight(0.4);
                setSlatAngle(30);
                setColor('#064e3b');
                setColorName('Zumrad yashil');
                setTexture('standard');
                setWallStyle('cream');
                setLighting('day');
              }}
              className="absolute top-6 right-6 z-30 p-2.5 rounded-full bg-brand-charcoal/80 text-brand-cream hover:bg-brand-emerald hover:text-brand-cream transition-colors backdrop-blur-sm border border-white/10"
              title="Dizaynni tozalash"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>

          {/* Right Panel: Interactive Controls Board */}
          <div className="lg:col-span-5 bg-brand-cream p-6 sm:p-8 rounded-3xl shadow-lg border border-brand-emerald/10 flex flex-col justify-between">
            <div className="space-y-6">
              
              {/* Header inside Panel */}
              <div className="border-b border-brand-emerald/15 pb-4">
                <h3 className="font-serif text-lg font-bold text-brand-emerald-dark flex items-center gap-2">
                  <Layers className="w-5 h-5 text-brand-emerald-light" />
                  <span>Dizayn boshqaruv paneli</span>
                </h3>
                <p className="text-xs text-brand-charcoal/50 font-light mt-1">Ushbu elementlarni sozlab, derazangiz uchun ideal ko‘rinishni toping.</p>
              </div>

              {/* Control 1: Blinds height (Open / Close) */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-brand-emerald-dark">Parda balandligi (Araliq)</span>
                  <span className="font-mono bg-brand-beige px-2 py-0.5 rounded text-brand-emerald font-semibold">
                    {Math.round((1 - blindsHeight) * 100)}% yopiq
                  </span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="0.95"
                  step="0.01"
                  value={blindsHeight}
                  onChange={(e) => setBlindsHeight(parseFloat(e.target.value))}
                  className="w-full h-1.5 bg-brand-beige rounded-lg appearance-none cursor-pointer accent-brand-emerald"
                />
                <div className="flex justify-between text-[10px] text-brand-charcoal/40 uppercase font-semibold">
                  <span>To‘liq ochiq</span>
                  <span>To‘liq yopiq</span>
                </div>
              </div>

              {/* Control 2: Slat Angle */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-brand-emerald-dark">Lamellar (Slat) burchagi</span>
                  <span className="font-mono bg-brand-beige px-2 py-0.5 rounded text-brand-emerald font-semibold">
                    {slatAngle}° burchak
                  </span>
                </div>
                <input
                  type="range"
                  min="-75"
                  max="75"
                  value={slatAngle}
                  onChange={(e) => setSlatAngle(parseInt(e.target.value))}
                  className="w-full h-1.5 bg-brand-beige rounded-lg appearance-none cursor-pointer accent-brand-emerald"
                />
                <div className="flex justify-between text-[10px] text-brand-charcoal/40 uppercase font-semibold">
                  <span>Pastga burilgan</span>
                  <span>Gorizontal</span>
                  <span>Tepaga burilgan</span>
                </div>
              </div>

              {/* Control 3: Colors Selection */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-brand-emerald-dark block">Jaluzi rangi: <span className="font-semibold text-brand-emerald">{colorName}</span></span>
                <div className="flex flex-wrap gap-2">
                  {colorOptions.map((opt) => (
                    <button
                      key={opt.name}
                      onClick={() => {
                        setColor(opt.hex);
                        setColorName(opt.name);
                      }}
                      className={`w-7 h-7 rounded-full border shadow-sm transition-all relative flex items-center justify-center ${
                        color === opt.hex ? 'ring-2 ring-brand-emerald-light scale-110' : 'border-brand-emerald/10'
                      }`}
                      style={{ backgroundColor: opt.hex }}
                      title={opt.name}
                    >
                      {color === opt.hex && (
                        <Check className={`w-3.5 h-3.5 ${opt.hex === '#fdfaee' || opt.hex === '#f5f2eb' || opt.hex === '#d3d3d3' ? 'text-black' : 'text-white'}`} />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Control 4: Fabric Texture styles */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-brand-emerald-dark block">Mato/Material turi</span>
                <div className="grid grid-cols-2 gap-2">
                  {textures.map((txt) => (
                    <button
                      key={txt.id}
                      onClick={() => setTexture(txt.id)}
                      className={`p-2.5 rounded-xl border text-left transition-all ${
                        texture === txt.id
                          ? 'bg-brand-emerald/5 border-brand-emerald text-brand-emerald'
                          : 'bg-brand-cream border-brand-emerald/10 text-brand-emerald-dark/70 hover:border-brand-emerald/30'
                      }`}
                    >
                      <span className="text-xs font-bold block">{txt.name}</span>
                      <span className="text-[9px] font-light block mt-0.5 opacity-80">{txt.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Control 5: Extra Ambience (Walls & Light Toggle) */}
              <div className="grid grid-cols-2 gap-4 border-t border-brand-emerald/10 pt-4">
                {/* Wall selector */}
                <div className="space-y-1.5">
                  <span className="text-xs font-bold text-brand-emerald-dark block">Devor ko‘rinishi</span>
                  <div className="flex gap-1.5">
                    {wallStyles.map((wall) => (
                      <button
                        key={wall.id}
                        onClick={() => setWallStyle(wall.id)}
                        className={`w-6 h-6 rounded border transition-all ${
                          wallStyle === wall.id ? 'ring-1 ring-brand-emerald border-brand-emerald scale-105' : 'border-brand-emerald/10'
                        } ${wall.bg}`}
                        title={wall.name}
                      />
                    ))}
                  </div>
                </div>

                {/* Day / Evening toggler */}
                <div className="space-y-1.5">
                  <span className="text-xs font-bold text-brand-emerald-dark block">Ssenariy yorug‘ligi</span>
                  <div className="flex gap-1">
                    <button
                      onClick={() => setLighting('day')}
                      className={`flex-1 py-1 rounded text-[10px] font-semibold border flex items-center justify-center gap-1 transition-all ${
                        lighting === 'day'
                          ? 'bg-amber-100 text-amber-800 border-amber-300 shadow-inner'
                          : 'bg-brand-cream border-brand-emerald/10 text-brand-emerald-dark/60'
                      }`}
                    >
                      <Sun className="w-3 h-3" />
                      <span>Kunduz</span>
                    </button>
                    <button
                      onClick={() => setLighting('evening')}
                      className={`flex-1 py-1 rounded text-[10px] font-semibold border flex items-center justify-center gap-1 transition-all ${
                        lighting === 'evening'
                          ? 'bg-indigo-950 text-indigo-100 border-indigo-800 shadow-inner'
                          : 'bg-brand-cream border-brand-emerald/10 text-brand-emerald-dark/60'
                      }`}
                    >
                      <Moon className="w-3 h-3" />
                      <span>Oqshom</span>
                    </button>
                  </div>
                </div>
              </div>

            </div>

            {/* Actions Footer inside Panel */}
            <div className="flex gap-3 mt-8 pt-4 border-t border-brand-emerald/10">
              <button
                onClick={handleSaveDesign}
                className={`flex-1 py-3.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all duration-300 flex items-center justify-center gap-2 ${
                  saved
                    ? 'bg-amber-600 text-brand-cream'
                    : 'bg-brand-beige border border-brand-emerald/20 hover:bg-brand-emerald/5 text-brand-emerald-dark'
                }`}
              >
                {saved ? <BookmarkCheck className="w-4 h-4" /> : <Layers className="w-4 h-4 text-brand-emerald" />}
                <span>{saved ? "Dizayn Saqlandi!" : "Dizaynni saqlash"}</span>
              </button>

              <button
                onClick={handleGetQuote}
                className="flex-1 py-3.5 bg-brand-emerald hover:bg-brand-emerald-dark text-brand-cream text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2 hover:scale-[1.02]"
              >
                <DollarSign className="w-4 h-4 text-amber-200" />
                <span>Hisob-kitob olish</span>
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}

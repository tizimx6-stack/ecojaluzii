import React, { useState } from 'react';
import { Product } from '../types';
import { X, Check, Ruler, MessageCircle, Shield, Truck, HelpCircle, Sparkles } from 'lucide-react';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onOrder: (product: Product) => void;
  onConsult: (product: Product) => void;
}

export default function ProductDetailModal({ product, onClose, onOrder, onConsult }: ProductDetailModalProps) {
  const [selectedColor, setSelectedColor] = useState<string>('');

  React.useEffect(() => {
    if (product && product.availableColors && product.availableColors.length > 0) {
      setSelectedColor(product.availableColors[0]);
    }
  }, [product]);

  if (!product) return null;

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('uz-UZ', { style: 'currency', currency: 'UZS', maximumFractionDigits: 0 }).format(price);
  };

  // Predefined color hues for visual representation in Uzbek
  const colorMap: { [key: string]: string } = {
    'Krem': '#f5f5dc',
    'Oq': '#ffffff',
    'Tabiiy bej': '#f5f2eb',
    'Bej': '#f5f2eb',
    'Zaytun to‘q yashil': '#2d3d2c',
    'Zaytun': '#556b2f',
    'Shokolad': '#4a3c31',
    'Yengil Eman': '#e1c699',
    'Oq eman': '#eed9b5',
    'Klassik Yong‘oq': '#5c4033',
    'To‘q Shokolad': '#3d2314',
    'Tabiiy Bambuk': '#e5c158',
    'Och kulrang': '#d3d3d3',
    'Grafat': '#36454f',
    'Qum rang': '#ecdec9',
    'Sut rang': '#fdfaee',
    'Och yashil': '#90ee90',
    'Moviy': '#add8e6',
    'Tabiiy zig‘ir bej': '#e8e2d4',
    'Yumshoq krem': '#fcf7ec',
    'Zumrad yashil': '#097969',
    'Kulrang bej': '#c3bcaf',
    'Antratsit': '#383e42',
    'Qora': '#000000'
  };

  const getHexColor = (colorName: string) => {
    return colorMap[colorName] || '#064e3b'; // Fallback to brand emerald
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-brand-charcoal/60 backdrop-blur-md">
      {/* Modal backdrop closer */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Modal Card Container */}
      <div className="relative bg-brand-cream w-full max-w-4xl rounded-2xl overflow-hidden shadow-2xl border border-brand-emerald/10 z-10 flex flex-col max-h-[90vh]">
        
        {/* Header Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 bg-brand-cream/95 text-brand-emerald-dark hover:bg-brand-emerald hover:text-brand-cream rounded-full transition-colors shadow-md border border-brand-emerald/5"
          title="Yopish"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Scrollable Content wrapper */}
        <div className="overflow-y-auto p-6 sm:p-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
            
            {/* Left Column: Image & Color visualizers */}
            <div className="lg:col-span-5 space-y-6">
              <div className="relative h-64 sm:h-80 rounded-2xl overflow-hidden bg-brand-cream border border-brand-emerald/10 shadow-md">
                <img
                  src={product.image}
                  alt={product.name || "Premium Jaluzi"}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover brightness-[1.02] contrast-[1.02]"
                />
              </div>

              {/* Dynamic Color Dots selection */}
              <div className="p-4 bg-brand-beige rounded-xl border border-brand-emerald/5">
                <h4 className="text-xs font-bold text-brand-emerald-dark uppercase tracking-wider mb-3">
                  Tanlash mumkin bo‘lgan ranglar:
                </h4>
                <div className="flex flex-wrap gap-2.5">
                  {product.availableColors.map((color) => {
                    const hex = getHexColor(color);
                    const isSelected = selectedColor === color;
                    return (
                      <button
                        key={color}
                        onClick={() => setSelectedColor(color)}
                        className={`flex items-center gap-2 px-2.5 py-1.5 rounded-full border text-[11px] font-semibold transition-all ${
                          isSelected
                            ? 'bg-brand-emerald text-brand-cream border-brand-emerald shadow-sm'
                            : 'bg-brand-cream text-brand-emerald-dark/80 border-brand-emerald/10 hover:border-brand-emerald/30'
                        }`}
                      >
                        <span
                          className="w-3.5 h-3.5 rounded-full border border-black/10 inline-block"
                          style={{ backgroundColor: hex }}
                        />
                        <span>{color}</span>
                        {isSelected && <Check className="w-3 h-3 ml-0.5" />}
                      </button>
                    );
                  })}
                </div>
                <p className="text-[10px] text-brand-charcoal/50 mt-3 font-light">
                  * Bizning mutaxassisimiz o‘lchovga borganda barcha matolarning real kataloglarini olib boradi.
                </p>
              </div>
            </div>

            {/* Right Column: Descriptions, Specs, Benefits */}
            <div className="lg:col-span-7 flex flex-col space-y-6">
              <div>
                <h3 className="font-serif text-2xl sm:text-3xl font-bold text-brand-emerald-dark mb-2">
                  {product.name || 'Premium Jaluzi'}
                </h3>
              </div>

              {/* Paragraph details */}
              <div className="space-y-4">
                <p className="text-brand-charcoal/80 text-sm font-light leading-relaxed">
                  {product.description}
                </p>

                {/* Specs list */}
                <div className="grid grid-cols-2 gap-4 py-4 border-y border-brand-emerald/10 text-xs">
                  <div>
                    <span className="text-brand-charcoal/50 block font-semibold mb-1">Mato / Material</span>
                    <span className="font-bold text-brand-emerald-dark">{product.material}</span>
                  </div>
                  <div>
                    <span className="text-brand-charcoal/50 block font-semibold mb-1">Yig‘ish mexanizmi</span>
                    <span className="font-bold text-brand-emerald-dark">Premium Shovqinsiz</span>
                  </div>
                </div>
              </div>

              {/* Benefits checklist */}
              {product.benefits && product.benefits.length > 0 && (
                <div className="space-y-2.5">
                  <h4 className="text-xs font-bold text-brand-emerald-dark uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-brand-emerald-light" />
                    <span>Afzalliklari</span>
                  </h4>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {product.benefits.map((benefit, i) => (
                      <li key={i} className="flex items-start gap-2 text-xs text-brand-charcoal/80">
                        <Check className="w-4 h-4 text-brand-emerald-light flex-shrink-0 mt-0.5" />
                        <span className="font-light">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Service & Warranty block */}
              <div className="p-4 bg-brand-beige rounded-xl border border-brand-emerald/5 space-y-2 text-xs">
                <h4 className="font-bold text-brand-emerald-dark flex items-center gap-2">
                  <Truck className="w-4 h-4 text-brand-emerald" />
                  <span>Kafolat va Yetkazib Berish</span>
                </h4>
                <p className="text-brand-charcoal/70 font-light leading-relaxed">
                  {product.installationInfo || 'O‘lcham olish va yetkazib berish xizmatlari amalga oshiriladi. Mahsulotga 1 yillik rasmiy kafolat taqdim etiladi.'}
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-brand-emerald/10">
                <button
                  onClick={() => onOrder(product)}
                  className="flex-1 py-4.5 bg-brand-emerald hover:bg-brand-emerald-dark text-brand-cream text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <Ruler className="w-4 h-4" />
                  <span>Õlcham olishga buyurtma berish</span>
                </button>

                <button
                  onClick={() => onConsult(product)}
                  className="py-4.5 px-6 bg-brand-beige hover:bg-brand-emerald/10 border border-brand-emerald/20 text-brand-emerald-dark text-xs font-bold uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-4 h-4 text-brand-emerald" />
                  <span>Mutaxassis maslahati</span>
                </button>
              </div>

            </div>

          </div>
        </div>
      </div>
    </div>
  );
}

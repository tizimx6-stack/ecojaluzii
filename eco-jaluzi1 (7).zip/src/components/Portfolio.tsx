import React, { useState, useEffect } from 'react';
import { dbService } from '../services/db';
import { PortfolioProject } from '../types';
import { 
  Camera, 
  Eye, 
  X, 
  ChevronLeft, 
  ChevronRight, 
  ShoppingCart, 
  ArrowRight, 
  Layers, 
  Sparkles,
  CheckCircle2,
  Filter,
  Maximize2,
  Send,
  ArrowUpRight
} from 'lucide-react';

interface PortfolioProps {
  onOrderProject?: (project: PortfolioProject) => void;
}

export default function Portfolio({ onOrderProject }: PortfolioProps) {
  const [projects, setProjects] = useState<PortfolioProject[]>([]);
  const [isFullWindowOpen, setIsFullWindowOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('Barchasi');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const fetchProjects = () => {
    setProjects(dbService.getProjects());
  };

  useEffect(() => {
    fetchProjects();
    window.addEventListener('cms_update', fetchProjects);
    return () => {
      window.removeEventListener('cms_update', fetchProjects);
    };
  }, []);

  // Prevent background scrolling when full window or lightbox is open
  useEffect(() => {
    if (isFullWindowOpen || lightboxIndex !== null) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isFullWindowOpen, lightboxIndex]);

  // Categories list
  const categories = [
    'Barchasi',
    'Dikey pardalar',
    'Bambuk jaluzi',
    'Wood (Yog‘och) jaluzi',
    'Alyumin gorizontal',
    'Honeycomb jaluzi',
    'Roller jaluzi',
    'Print jaluzi',
    'Combo jaluzi',
    'Plisse jaluzi'
  ];

  // Filtered projects for the full modal window
  const filteredProjects = selectedCategory === 'Barchasi'
    ? projects
    : projects.filter(p => p.category.toLowerCase().includes(selectedCategory.toLowerCase()) || selectedCategory.toLowerCase().includes(p.category.toLowerCase()));

  const handleOpenFullWindow = (initialCategory = 'Barchasi') => {
    setSelectedCategory(initialCategory);
    setIsFullWindowOpen(true);
  };

  const handleCloseFullWindow = () => {
    setIsFullWindowOpen(false);
    setLightboxIndex(null);
  };

  const openLightbox = (index: number) => {
    setLightboxIndex(index);
  };

  const closeLightbox = () => {
    setLightboxIndex(null);
  };

  const handlePrev = () => {
    if (lightboxIndex === null) return;
    setLightboxIndex((lightboxIndex - 1 + filteredProjects.length) % filteredProjects.length);
  };

  const handleNext = () => {
    if (lightboxIndex === null) return;
    setLightboxIndex((lightboxIndex + 1) % filteredProjects.length);
  };

  const handleOrder = (e: React.MouseEvent, project: PortfolioProject) => {
    e.stopPropagation();
    setIsFullWindowOpen(false);
    setLightboxIndex(null);
    if (onOrderProject) {
      onOrderProject(project);
    } else {
      const formSection = document.querySelector('#order-form');
      if (formSection) {
        formSection.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  // 6 preview items on the main page
  const previewProjects = projects.slice(0, 6);

  return (
    <section id="portfolio" className="py-24 bg-brand-cream border-b border-brand-emerald/10 relative overflow-hidden">
      {/* Decorative subtle background elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-brand-emerald/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-12 relative z-10">
        
        {/* Main Section Header with Katta Text */}
        <div className="text-center max-w-4xl mx-auto mb-14 flex flex-col items-center gap-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-brand-emerald/10 text-brand-emerald text-xs font-bold uppercase tracking-widest border border-brand-emerald/15 shadow-2xs">
            <Camera className="w-4 h-4 text-brand-emerald" />
            <span>REAL NATIJALAR VA O‘RNATILGAN OBYEKTLAR</span>
          </div>

          {/* Katta Text Sarlavha */}
          <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-brand-emerald-dark leading-tight">
            QILINGAN ISHLAR
          </h2>
          
          <div className="h-1.5 w-24 bg-gradient-to-r from-brand-emerald via-amber-400 to-brand-emerald rounded-full my-1" />
          
          <p className="text-brand-charcoal/80 font-light max-w-2xl text-base sm:text-lg leading-relaxed">
            Biz o‘rnatgan 1,500+ dan ortiq real loyihalarimiz. Kottejlar, xonadonlar, ofis va mehmonxonalar uchun turli xildagi tayyor jaluzilar galereyasi bilan to‘liq tanishing.
          </p>

          {/* Big Interactive Primary CTA Button */}
          <div className="mt-3">
            <button
              onClick={() => handleOpenFullWindow('Barchasi')}
              className="group relative inline-flex items-center gap-3 px-8 py-4 bg-brand-emerald hover:bg-brand-emerald-dark text-brand-cream text-sm sm:text-base font-bold uppercase tracking-wider rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-[1.03] border border-white/20 active:scale-95"
            >
              <Sparkles className="w-5 h-5 text-amber-300 animate-pulse" />
              <span>Barcha qilingan ishlarni to‘liq oynada ko‘rish ↗</span>
              <ArrowRight className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" />
            </button>
          </div>
        </div>

        {/* Featured Projects Grid (Click opens the dedicated window) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 mb-12">
          {previewProjects.map((project, index) => (
            <div
              key={project.id}
              id={`project-card-${project.id}`}
              onClick={() => handleOpenFullWindow(project.category)}
              className="group relative bg-brand-beige rounded-3xl overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500 cursor-pointer border border-brand-emerald/10 aspect-[4/5]"
            >
              <img
                src={project.image}
                alt={project.title}
                referrerPolicy="no-referrer"
                onError={(e) => {
                  e.currentTarget.src = "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=800&q=80";
                }}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-108 brightness-[0.98]"
              />

              {/* Hover Clean Zoom / Open Badge */}
              <div className="absolute inset-0 bg-brand-charcoal/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                <span className="px-5 py-2.5 bg-brand-cream text-brand-emerald-dark rounded-full shadow-xl hover:scale-105 transition-transform flex items-center gap-2 text-xs font-bold">
                  <Eye className="w-4 h-4 text-brand-emerald" />
                  <span>Oynada ko‘rish</span>
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Banner to Open Full Showcase */}
        <div 
          onClick={() => handleOpenFullWindow('Barchasi')}
          className="relative bg-gradient-to-r from-brand-emerald-dark via-brand-emerald to-brand-emerald-dark rounded-3xl p-8 sm:p-10 text-brand-cream shadow-2xl overflow-hidden cursor-pointer group border border-white/10 hover:border-amber-400/40 transition-all duration-300"
        >
          <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-white/5 skew-x-12 pointer-events-none group-hover:scale-110 transition-transform duration-700" />
          
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
            <div className="space-y-2 max-w-2xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-white/10 text-amber-300 text-xs font-bold uppercase tracking-wider">
                <Layers className="w-4 h-4" />
                <span>BARCHA TURDAGI JALUZILAR KETMA-KET</span>
              </div>
              <h3 className="font-serif text-2xl sm:text-3xl font-bold text-white">
                Barcha qilingan ishlarimizni alohida oynada oching
              </h3>
              <p className="text-xs sm:text-sm text-brand-beige/80 font-light">
                Dikey pardalar, Bambuk, Yog‘och, Alyumin, Roller, Combo va Plisse jaluzilarning haqiqiy o‘rnatilgan loyihalari.
              </p>
            </div>

            <div className="flex-shrink-0">
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  handleOpenFullWindow('Barchasi');
                }}
                className="px-6 py-3.5 bg-amber-400 hover:bg-amber-300 text-brand-emerald-dark font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg transition-all flex items-center gap-2 group-hover:scale-105"
              >
                <span>Oynani ochish</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* DEDICATED FULL SHOWCASE WINDOW (BOSHQACHA OYNA / TO'LIQ KO'RISH OYNASI) */}
      {/* ========================================================================= */}
      {isFullWindowOpen && (
        <div className="fixed inset-0 z-50 bg-brand-cream overflow-y-auto animate-fadeIn flex flex-col">
          
          {/* Window Top Sticky Header */}
          <div className="sticky top-0 z-40 bg-brand-cream/95 backdrop-blur-md border-b border-brand-emerald/10 px-4 sm:px-8 py-4 shadow-sm">
            <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
              
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-brand-emerald text-brand-cream flex items-center justify-center shadow-md">
                  <Camera className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="font-serif text-xl sm:text-2xl font-bold text-brand-emerald-dark">
                    Qilingan ishlar galereyasi
                  </h2>
                  <p className="text-[11px] sm:text-xs text-brand-charcoal/60 font-light">
                    O‘rnatilgan barcha turdagi jaluzilar loyihalari ({filteredProjects.length} ta loyiha)
                  </p>
                </div>
              </div>

              {/* Close Button / Back */}
              <button
                onClick={handleCloseFullWindow}
                className="px-4 py-2 rounded-xl bg-brand-beige hover:bg-brand-emerald/10 text-brand-emerald-dark border border-brand-emerald/15 text-xs font-bold transition-all flex items-center gap-2 shadow-2xs hover:scale-105"
              >
                <X className="w-4 h-4" />
                <span className="hidden sm:inline">Yopish (Ortga)</span>
              </button>
            </div>
          </div>

          {/* Window Body */}
          <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-12 py-8 flex-grow w-full">
            
            {/* Telegram Channel Link Banner */}
            <div className="mb-8">
              <a
                href="https://t.me/eco_jaluzi"
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-3.5 bg-white/90 hover:bg-white p-4 rounded-2xl border border-sky-400/30 shadow-xs group transition-all hover:shadow-md"
              >
                <div className="w-11 h-11 rounded-xl bg-sky-500 text-white flex items-center justify-center shadow-md flex-shrink-0 group-hover:scale-105 transition-transform">
                  <Send className="w-5 h-5" />
                </div>
                <div className="text-left flex-grow">
                  <span className="block text-sm sm:text-base font-bold text-brand-emerald-dark group-hover:text-sky-700 transition-colors">
                    Qolgan qilingan ishlar rasmlarini Telegram kanalimizdan topishingiz mumkin
                  </span>
                  <span className="text-xs text-sky-700 font-semibold flex items-center gap-1 mt-0.5">
                    <span>@eco_jaluzi kanaliga o‘tish</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </a>
            </div>

            {/* Category Filter Tabs (Har xil jaluzilar) */}
            <div className="mb-10">
              <div className="flex items-center gap-2 mb-3 text-xs font-bold uppercase tracking-wider text-brand-emerald-dark">
                <Filter className="w-4 h-4 text-brand-emerald" />
                <span>Jaluzi turlari bo‘yicha ko‘rish:</span>
              </div>

              <div className="flex flex-wrap gap-2 sm:gap-2.5">
                {categories.map((cat) => {
                  const isSelected = selectedCategory === cat;
                  return (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-4 py-2 rounded-xl text-xs font-bold tracking-wide transition-all shadow-2xs ${
                        isSelected
                          ? 'bg-brand-emerald text-brand-cream shadow-md scale-[1.02] ring-2 ring-brand-emerald/30'
                          : 'bg-white hover:bg-brand-beige text-brand-emerald-dark border border-brand-emerald/10'
                      }`}
                    >
                      {cat}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Showcase Grid (Har xil jaluzilar ketma-ket) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 sm:gap-7">
              {filteredProjects.map((project, index) => (
                <div
                  key={project.id}
                  onClick={() => openLightbox(index)}
                  className="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 border border-brand-emerald/10 flex flex-col cursor-pointer"
                >
                  {/* Project Image */}
                  <div className="relative aspect-[4/3] bg-brand-beige overflow-hidden">
                    <img
                      src={project.image}
                      alt={project.title}
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        e.currentTarget.src = "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=800&q=80";
                      }}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-106"
                    />

                    {/* Category Tag */}
                    <div className="absolute top-3 left-3 z-10">
                      <span className="px-2.5 py-1 bg-brand-charcoal/85 backdrop-blur-sm text-brand-cream text-[10px] font-bold uppercase tracking-wider rounded-lg shadow-sm border border-white/10">
                        {project.category}
                      </span>
                    </div>

                    {/* Hover zoom overlay */}
                    <div className="absolute inset-0 bg-brand-charcoal/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                      <span className="px-3.5 py-2 bg-brand-cream text-brand-emerald-dark text-xs font-bold rounded-xl shadow-lg flex items-center gap-1.5">
                        <Eye className="w-4 h-4 text-brand-emerald" />
                        <span>Kattalashtirish</span>
                      </span>
                    </div>
                  </div>

                  {/* Project Details */}
                  <div className="p-4 flex flex-col justify-between flex-grow space-y-3">
                    <div className="space-y-1">
                      <h3 className="font-serif text-base font-bold text-brand-emerald-dark group-hover:text-brand-emerald transition-colors line-clamp-1">
                        {project.category} Jaluzisi
                      </h3>
                    </div>

                    <div className="pt-2 border-t border-brand-emerald/10 flex items-center justify-between gap-2">
                      <span className="text-[10px] text-brand-emerald font-semibold uppercase tracking-wider flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Tayyor Obyekt
                      </span>

                      <button
                        onClick={(e) => handleOrder(e, project)}
                        className="px-3 py-1.5 bg-brand-emerald hover:bg-brand-emerald-dark text-brand-cream text-[11px] font-bold rounded-lg transition-all shadow-xs flex items-center gap-1.5 active:scale-95"
                      >
                        <ShoppingCart className="w-3.5 h-3.5" />
                        <span>Buyurtma berish</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* If no projects in category */}
            {filteredProjects.length === 0 && (
              <div className="text-center py-16 space-y-3">
                <p className="text-base text-brand-charcoal/60">Ushbu toifada loyihalar tez kunda qo‘shiladi.</p>
                <button
                  onClick={() => setSelectedCategory('Barchasi')}
                  className="px-5 py-2 rounded-xl bg-brand-emerald text-brand-cream text-xs font-bold"
                >
                  Barcha loyihalarni ko‘rish
                </button>
              </div>
            )}

            {/* Bottom Back Button inside window */}
            <div className="mt-16 text-center pb-8">
              <button
                onClick={handleCloseFullWindow}
                className="px-8 py-3.5 rounded-2xl bg-brand-beige hover:bg-brand-emerald/10 text-brand-emerald-dark border border-brand-emerald/20 text-xs font-bold uppercase tracking-wider transition-all shadow-sm"
              >
                ← Asosiy sahifaga qaytish
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* HD FULLSCREEN LIGHTBOX MODAL */}
      {/* ========================================================================= */}
      {lightboxIndex !== null && filteredProjects[lightboxIndex] && (
        <div className="fixed inset-0 z-60 bg-brand-charcoal/95 backdrop-blur-md flex flex-col justify-between p-4 sm:p-6 select-none animate-fadeIn">
          {/* Top Bar */}
          <div className="flex items-center justify-between text-brand-cream z-10 pb-3 border-b border-white/10">
            <div className="flex items-center gap-2.5">
              <span className="px-2.5 py-1 bg-brand-emerald text-brand-cream text-[10px] font-bold uppercase tracking-wider rounded-lg">
                {filteredProjects[lightboxIndex].category}
              </span>
              <span className="text-sm sm:text-base font-semibold font-serif text-amber-200 line-clamp-1">
                {filteredProjects[lightboxIndex].title}
              </span>
            </div>
            <button
              onClick={closeLightbox}
              className="p-2 rounded-full bg-white/10 hover:bg-brand-emerald text-brand-cream transition-colors"
              title="Yopish"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Active Image and Navigation */}
          <div className="relative flex-grow flex items-center justify-center max-h-[75vh] my-2">
            <button
              onClick={handlePrev}
              className="absolute left-2 sm:left-4 z-10 p-3 rounded-full bg-white/10 hover:bg-brand-emerald text-brand-cream transition-all hover:scale-110"
              title="Oldingisi"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            <img
              src={filteredProjects[lightboxIndex].image}
              alt={filteredProjects[lightboxIndex].title}
              referrerPolicy="no-referrer"
              className="max-w-full max-h-full object-contain rounded-xl shadow-2xl border border-white/10"
            />

            <button
              onClick={handleNext}
              className="absolute right-2 sm:right-4 z-10 p-3 rounded-full bg-white/10 hover:bg-brand-emerald text-brand-cream transition-all hover:scale-110"
              title="Keyingisi"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>

          {/* Footer Details & Order Action */}
          <div className="text-brand-cream z-10 pt-3 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="text-center sm:text-left">
              <span className="text-[11px] font-mono text-brand-beige/70">
                Loyiha #{lightboxIndex + 1} / {filteredProjects.length}
              </span>
            </div>

            <button
              onClick={(e) => {
                const proj = filteredProjects[lightboxIndex];
                handleOrder(e, proj);
              }}
              className="px-6 py-2.5 bg-brand-emerald hover:bg-brand-emerald-dark text-brand-cream text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-lg flex items-center gap-2"
            >
              <ShoppingCart className="w-4 h-4" />
              <span>Shu modeldan buyurtma berish</span>
            </button>
          </div>
        </div>
      )}
    </section>
  );
}

import React, { useState, useEffect } from 'react';
import { PortfolioProject } from '../types';
import { ALYUMIN_GALLERY_PROJECTS, AlyuminProjectItem } from '../data/alyuminGallery';
import {
  X, Camera, ChevronLeft, ChevronRight, ShoppingCart,
  Maximize2, Sparkles, CheckCircle2, Phone, ShieldCheck,
  Search, Filter, Eye, ZoomIn, ZoomOut, RotateCcw,
  Building, Send, ArrowUpRight
} from 'lucide-react';

interface AlyuminGalleryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOrderProject: (project: PortfolioProject) => void;
}

export default function AlyuminGalleryModal({
  isOpen,
  onClose,
  onOrderProject,
}: AlyuminGalleryModalProps) {
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [zoomLevel, setZoomLevel] = useState<number>(1);

  // Lock body scroll when modal or lightbox is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // Reset zoom level whenever lightbox photo changes
  useEffect(() => {
    setZoomLevel(1);
  }, [lightboxIndex]);

  // Keyboard navigation for lightbox
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (lightboxIndex === null) return;
      if (e.key === 'Escape') setLightboxIndex(null);
      if (e.key === 'ArrowLeft') {
        setLightboxIndex((prev) => (prev !== null && prev > 0 ? prev - 1 : ALYUMIN_GALLERY_PROJECTS.length - 1));
      }
      if (e.key === 'ArrowRight') {
        setLightboxIndex((prev) => (prev !== null && prev < ALYUMIN_GALLERY_PROJECTS.length - 1 ? prev + 1 : 0));
      }
      if (e.key === '+' || e.key === '=') {
        setZoomLevel((z) => Math.min(z + 0.5, 3));
      }
      if (e.key === '-') {
        setZoomLevel((z) => Math.max(z - 0.5, 1));
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lightboxIndex]);

  if (!isOpen) return null;

  // Filter projects by search
  const filteredProjects = ALYUMIN_GALLERY_PROJECTS.filter((proj) => {
    if (!searchQuery.trim()) return true;
    return (
      proj.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (proj.fabricColor && proj.fabricColor.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  });

  return (
    <div className="fixed inset-0 z-50 bg-brand-cream overflow-y-auto animate-fadeIn flex flex-col">
      {/* Sticky Top Header */}
      <div className="sticky top-0 z-40 bg-brand-cream/95 backdrop-blur-md border-b border-brand-emerald/10 px-4 sm:px-8 py-3.5 shadow-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-cyan-700 text-white flex items-center justify-center shadow-md flex-shrink-0">
              <span className="text-xl sm:text-2xl">🏢</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-md bg-cyan-500 text-slate-950 text-[10px] font-extrabold uppercase tracking-wider">
                  Alyumin Jaluzilar Galereyasi
                </span>
                <span className="text-xs text-brand-emerald font-bold hidden sm:inline-block">
                  • {ALYUMIN_GALLERY_PROJECTS.length} ta eksklyuziv real montaj
                </span>
              </div>
              <h2 className="font-serif text-base sm:text-xl md:text-2xl font-bold text-brand-emerald-dark leading-tight line-clamp-1">
                Alyumin Gorizontal Jaluzilar — Real Qilingan Ishlar
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            <button
              onClick={onClose}
              className="px-3.5 sm:px-4 py-2 rounded-xl bg-brand-beige hover:bg-brand-emerald hover:text-white text-brand-emerald-dark border border-brand-emerald/15 text-xs font-bold transition-all flex items-center gap-1.5 shadow-2xs hover:scale-105 cursor-pointer"
            >
              <span>Ortga / Yopish</span>
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-12 py-6 sm:py-8 flex-grow w-full space-y-6 sm:space-y-8">
        
        {/* Top Info & Trust Banner */}
        <div className="bg-gradient-to-br from-brand-beige via-brand-cream to-brand-beige rounded-3xl p-5 sm:p-7 border border-brand-emerald/15 shadow-sm space-y-4">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-900 text-xs font-bold">
                <Sparkles className="w-3.5 h-3.5 text-cyan-600" />
                <span>100% Namlik va Issiqlikka Chidamli</span>
              </div>
              <h3 className="font-serif text-xl sm:text-2xl md:text-3xl font-bold text-brand-emerald-dark">
                Alyumin Gorizontal Jaluzilar Bo‘yicha Ishlarimiz ({ALYUMIN_GALLERY_PROJECTS.length} ta rasm)
              </h3>
              <p className="text-xs sm:text-sm text-brand-charcoal/70 font-light max-w-3xl leading-relaxed">
                Namlik, quyosh nurlari va bug‘ga 100% chidamli, oshxona, shifoxona, ofis va turar-joylar uchun eng ishonchli 16mm va 25mm alyuminiy gorizontal jaluzilar montaj suratlari.
              </p>
            </div>

            <a
              href="https://t.me/eco_jaluzi"
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-3 bg-white/90 hover:bg-white p-3.5 sm:p-4 rounded-2xl border border-sky-400/30 shadow-xs flex-shrink-0 group transition-all hover:shadow-md"
            >
              <div className="w-10 h-10 rounded-xl bg-sky-500 text-white flex items-center justify-center shadow-md flex-shrink-0 group-hover:scale-105 transition-transform">
                <Send className="w-5 h-5" />
              </div>
              <div className="text-left">
                <span className="block text-xs sm:text-sm font-bold text-brand-emerald-dark group-hover:text-sky-700 transition-colors">
                  Qolgan qilingan ishlar rasmlarini Telegram kanalimizdan topishingiz mumkin
                </span>
                <span className="text-[11px] text-sky-700 font-semibold flex items-center gap-1 mt-0.5">
                  <span>@eco_jaluzi kanaliga o‘tish</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </a>
          </div>

          {/* Search Control */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-brand-emerald/10">
            <div className="text-xs text-brand-emerald-dark/80 font-medium">
              Barcha rasmlar saralangan holda ko‘rsatilmoqda ({filteredProjects.length} ta montaj)
            </div>

            {/* Search Input */}
            <div className="relative w-full sm:w-72">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Model yoki rang bo‘yicha qidirish..."
                className="w-full pl-9 pr-3 py-2 bg-white rounded-xl text-xs border border-brand-emerald/15 focus:outline-hidden focus:ring-2 focus:ring-cyan-600 text-brand-emerald-dark"
              />
              <Search className="w-3.5 h-3.5 text-brand-charcoal/50 absolute left-3 top-1/2 -translate-y-1/2" />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-brand-charcoal/40 hover:text-brand-charcoal cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>

        {/* PROJECTS GRID */}
        {filteredProjects.length === 0 ? (
          <div className="text-center py-16 bg-brand-beige/40 rounded-3xl border border-dashed border-brand-emerald/20 p-8 space-y-3">
            <Camera className="w-12 h-12 text-brand-emerald/30 mx-auto" />
            <h4 className="text-base font-bold text-brand-emerald-dark">Qidiruvingiz bo‘yicha rasm topilmadi</h4>
            <p className="text-xs text-brand-charcoal/60">Barcha rasmlarni ko‘rish uchun qidiruvni tozalang.</p>
            <button
              onClick={() => setSearchQuery('')}
              className="px-4 py-2 bg-cyan-700 text-white rounded-xl text-xs font-bold cursor-pointer shadow-md"
            >
              Barcha rasmlarni ko‘rish
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7">
            {filteredProjects.map((project, idx) => (
              <div
                key={project.id}
                id={`alyumin-card-${project.id}`}
                onClick={() => setLightboxIndex(idx)}
                className="group relative bg-brand-beige rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 border border-brand-emerald/15 flex flex-col aspect-[4/5] hover:-translate-y-1 cursor-pointer"
              >
                {/* Image */}
                <img
                  src={project.image}
                  alt={project.title}
                  loading="eager"
                  decoding="async"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    e.currentTarget.src = "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80";
                  }}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 contrast-[1.03] saturate-[1.03]"
                />

                {/* Top Badges */}
                <div className="absolute top-3.5 left-3.5 right-3.5 flex items-center justify-between z-10 pointer-events-none">
                  <span className="px-3 py-1 rounded-full bg-brand-cream/95 backdrop-blur-md text-slate-900 text-[10px] font-extrabold uppercase tracking-wider shadow-sm flex items-center gap-1">
                    <span>🏢</span>
                    <span>Alyumin Jaluzi</span>
                  </span>

                  <span className="px-2.5 py-0.5 rounded-md bg-brand-charcoal/80 backdrop-blur-md text-white text-[10px] font-bold shadow-sm">
                    #{idx + 1} / {filteredProjects.length}
                  </span>
                </div>

                {/* Hover Click to Zoom indicator */}
                <div className="absolute inset-0 bg-brand-charcoal/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center pointer-events-none">
                  <div className="px-4 py-2 rounded-2xl bg-black/75 backdrop-blur-md text-white text-xs font-bold flex items-center gap-2 shadow-xl transform scale-90 group-hover:scale-100 transition-transform">
                    <Maximize2 className="w-4 h-4 text-cyan-300" />
                    <span>Tinniq ko‘rish uchun bosing</span>
                  </div>
                </div>

                {/* Bottom Action Bar - clean and unobscured */}
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-brand-charcoal/90 via-brand-charcoal/40 to-transparent p-4 sm:p-5 text-brand-cream flex flex-col justify-end">
                  <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                    <button
                      type="button"
                      onClick={() => setLightboxIndex(idx)}
                      className="px-3 py-2 rounded-xl bg-white/20 hover:bg-white/30 text-white text-[11px] font-bold backdrop-blur-sm transition-all flex items-center gap-1.5 flex-shrink-0 cursor-pointer"
                    >
                      <Maximize2 className="w-3.5 h-3.5 text-cyan-300" />
                      <span>HD Ko‘rish</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOrderProject(project);
                      }}
                      className="flex-1 px-3.5 py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 text-[11px] font-bold transition-all shadow-md flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer"
                    >
                      <ShoppingCart className="w-3.5 h-3.5" />
                      <span>Shu modelga buyurtma</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Bottom CTA & Trust Section */}
        <div className="bg-brand-emerald-dark rounded-3xl p-6 sm:p-8 text-brand-cream flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="flex items-center gap-4 text-center sm:text-left">
            <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center text-cyan-300 flex-shrink-0 shadow-inner">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-serif text-base sm:text-lg font-bold text-white">
                Alyumin Jaluzilar Bo‘yicha Bepul O‘lchash & Maslahat
              </h4>
              <p className="text-xs sm:text-sm text-brand-cream/75 font-light mt-0.5">
                Mutaxassisimiz barcha rangdagi alyumin lamel namunalarini uyingizga bepul olib boradi.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOrderProject(ALYUMIN_GALLERY_PROJECTS[0]);
              }}
              className="w-full sm:w-auto py-3 px-6 rounded-2xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs uppercase tracking-wider shadow-lg transition-all active:scale-95 text-center cursor-pointer"
            >
              O‘lchovga buyurtma berish
            </button>

            <a
              href="tel:+998940009977"
              className="w-full sm:w-auto py-3 px-5 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition-all border border-white/20 flex items-center justify-center gap-2 text-center"
            >
              <Phone className="w-4 h-4 text-cyan-300" />
              <span>+998 94 000 99 77</span>
            </a>
          </div>
        </div>

      </div>

      {/* Modal Bottom Footer */}
      <div className="bg-brand-beige border-t border-brand-emerald/10 px-4 py-4 text-center">
        <button
          onClick={onClose}
          className="px-6 py-2.5 bg-brand-emerald text-white rounded-xl text-xs font-bold shadow-md hover:bg-brand-emerald-dark transition-all cursor-pointer"
        >
          Galereyani yopish / Ortga qaytish
        </button>
      </div>

      {/* LIGHTBOX FOR FULLSCREEN VIEW */}
      {lightboxIndex !== null && filteredProjects[lightboxIndex] && (
        <div className="fixed inset-0 z-[100] bg-black/95 flex flex-col justify-between p-3 sm:p-6 animate-fadeIn select-none backdrop-blur-md">
          {/* Lightbox Top Bar */}
          <div className="flex items-center justify-between text-white z-20 pb-2 border-b border-white/10">
            <div className="flex items-center gap-2 sm:gap-3">
              <span className="px-2.5 sm:px-3 py-1 rounded-full bg-cyan-400 text-slate-950 text-[10px] sm:text-xs font-extrabold uppercase">
                Alyumin Jaluzi
              </span>
              <span className="text-xs sm:text-sm text-white/80 font-medium">
                {lightboxIndex + 1} / {filteredProjects.length}
              </span>
              <span className="hidden sm:inline-block px-2 py-0.5 rounded-md bg-white/15 text-[11px] text-cyan-300 font-semibold">
                HD Tinniq Format
              </span>
            </div>

            {/* Zoom & Action Controls */}
            <div className="flex items-center gap-2 sm:gap-3">
              {/* Zoom Buttons */}
              <div className="flex items-center bg-white/10 rounded-xl p-0.5 border border-white/15">
                <button
                  type="button"
                  onClick={() => setZoomLevel((z) => Math.max(z - 0.5, 1))}
                  disabled={zoomLevel <= 1}
                  className="p-1.5 sm:p-2 text-white hover:bg-white/20 rounded-lg disabled:opacity-30 transition-all cursor-pointer"
                  title="Kichiklashtirish (-)"
                >
                  <ZoomOut className="w-4 h-4" />
                </button>
                <span className="px-2 text-[11px] font-bold text-cyan-300">
                  {Math.round(zoomLevel * 100)}%
                </span>
                <button
                  type="button"
                  onClick={() => setZoomLevel((z) => Math.min(z + 0.5, 3))}
                  disabled={zoomLevel >= 3}
                  className="p-1.5 sm:p-2 text-white hover:bg-white/20 rounded-lg disabled:opacity-30 transition-all cursor-pointer"
                  title="Kattalashtirish (+)"
                >
                  <ZoomIn className="w-4 h-4" />
                </button>
                {zoomLevel > 1 && (
                  <button
                    type="button"
                    onClick={() => setZoomLevel(1)}
                    className="p-1.5 sm:p-2 text-white/80 hover:bg-white/20 rounded-lg transition-all cursor-pointer ml-1 border-l border-white/15"
                    title="Asl holatiga qaytarish"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <button
                type="button"
                onClick={() => {
                  const chosen = filteredProjects[lightboxIndex];
                  setLightboxIndex(null);
                  onClose();
                  onOrderProject(chosen);
                }}
                className="hidden sm:flex px-4 py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 text-xs font-bold items-center gap-1.5 shadow-lg transition-all cursor-pointer"
              >
                <ShoppingCart className="w-3.5 h-3.5" />
                <span>Shu modelga buyurtma</span>
              </button>

              <button
                type="button"
                onClick={() => setLightboxIndex(null)}
                className="p-2 sm:p-2.5 rounded-full bg-white/15 hover:bg-white/30 text-white transition-all hover:scale-110 cursor-pointer"
                title="Yopish (Esc)"
              >
                <X className="w-5 h-5 sm:w-6 sm:h-6" />
              </button>
            </div>
          </div>

          {/* Lightbox Center Image & Nav Buttons */}
          <div className="relative flex-grow flex items-center justify-center my-2 overflow-auto scrollbar-none">
            <button
              type="button"
              onClick={() =>
                setLightboxIndex((lightboxIndex - 1 + filteredProjects.length) % filteredProjects.length)
              }
              className="fixed left-2 sm:left-6 z-30 p-3 sm:p-4 rounded-full bg-black/70 hover:bg-cyan-400 hover:text-black text-white backdrop-blur-md transition-all border border-white/20 hover:scale-110 shadow-2xl cursor-pointer"
              aria-label="Oldingi rasm"
            >
              <ChevronLeft className="w-6 h-6 sm:w-8 sm:h-8" />
            </button>

            <div
              className={`transition-transform duration-300 flex items-center justify-center ${
                zoomLevel > 1 ? 'cursor-grab active:cursor-grabbing' : 'cursor-zoom-in'
              }`}
              onClick={() => {
                if (zoomLevel === 1) setZoomLevel(1.75);
                else setZoomLevel(1);
              }}
              style={{
                transform: `scale(${zoomLevel})`,
                transformOrigin: 'center center',
              }}
            >
              <img
                src={filteredProjects[lightboxIndex].image}
                alt={filteredProjects[lightboxIndex].title}
                loading="eager"
                decoding="sync"
                referrerPolicy="no-referrer"
                className="max-h-[72vh] sm:max-h-[76vh] max-w-[92vw] object-contain rounded-2xl shadow-2xl contrast-[1.04] saturate-[1.03]"
              />
            </div>

            <button
              type="button"
              onClick={() =>
                setLightboxIndex((lightboxIndex + 1) % filteredProjects.length)
              }
              className="fixed right-2 sm:right-6 z-30 p-3 sm:p-4 rounded-full bg-black/70 hover:bg-cyan-400 hover:text-black text-white backdrop-blur-md transition-all border border-white/20 hover:scale-110 shadow-2xl cursor-pointer"
              aria-label="Keyingi rasm"
            >
              <ChevronRight className="w-6 h-6 sm:w-8 sm:h-8" />
            </button>
          </div>

          {/* Lightbox Bottom Info & Thumbnails */}
          <div className="text-center text-white space-y-2 max-w-4xl mx-auto w-full z-20">
            <div>
              <h3 className="font-serif text-sm sm:text-base font-bold text-cyan-300">
                Alyumin Gorizontal Jaluzi #{lightboxIndex + 1}
              </h3>
              <p className="text-[11px] sm:text-xs text-cyan-200/90 font-medium">
                Rasmni bosib 175% kattalashtirib ko‘ring
              </p>
            </div>

            {/* Thumbnail Strip */}
            <div className="flex items-center justify-center gap-1.5 sm:gap-2 overflow-x-auto py-1 scrollbar-none max-w-full">
              {filteredProjects.map((proj, idx) => (
                <button
                  key={proj.id}
                  type="button"
                  onClick={() => setLightboxIndex(idx)}
                  className={`w-11 h-11 sm:w-14 sm:h-14 rounded-xl overflow-hidden flex-shrink-0 border-2 transition-all cursor-pointer ${
                    lightboxIndex === idx
                      ? 'border-cyan-400 scale-110 shadow-lg'
                      : 'border-white/30 opacity-60 hover:opacity-100'
                  }`}
                >
                  <img
                    src={proj.image}
                    alt={proj.title}
                    loading="lazy"
                    decoding="async"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover contrast-[1.03]"
                  />
                </button>
              ))}
            </div>

            {/* Mobile Order Button in Lightbox */}
            <div className="sm:hidden pt-1">
              <button
                type="button"
                onClick={() => {
                  const chosen = filteredProjects[lightboxIndex];
                  setLightboxIndex(null);
                  onClose();
                  onOrderProject(chosen);
                }}
                className="w-full py-2.5 rounded-xl bg-cyan-400 text-slate-950 text-xs font-bold uppercase shadow-lg flex items-center justify-center gap-2 cursor-pointer"
              >
                <ShoppingCart className="w-4 h-4" />
                <span>Shu modelga buyurtma berish</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

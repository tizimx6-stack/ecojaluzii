import React, { useState, useEffect, useMemo } from 'react';
import { dbService } from '../services/db';
import { Product, PortfolioProject } from '../types';
import SimilarJaluziModal from './SimilarJaluziModal';
import DikeyGalleryModal from './DikeyGalleryModal';
import PlisseGalleryModal from './PlisseGalleryModal';
import ComboGalleryModal from './ComboGalleryModal';
import AlyuminGalleryModal from './AlyuminGalleryModal';
import WoodGalleryModal from './WoodGalleryModal';
import RolloGalleryModal from './RolloGalleryModal';
import PrintGalleryModal from './PrintGalleryModal';
import CatalogSpecialFolderModal from './CatalogSpecialFolderModal';
import {
  ROLLO_CATALOG_ITEMS,
  DIKEY_CATALOG_ITEMS,
  COMBO_CATALOG_ITEMS,
} from '../data/catalogSpecialProducts';
import { DIKEY_GALLERY_PROJECTS } from '../data/dikeyGallery';
import { PLISSE_GALLERY_PROJECTS } from '../data/plisseGallery';
import { COMBO_GALLERY_PROJECTS } from '../data/comboGallery';
import { ALYUMIN_GALLERY_PROJECTS } from '../data/alyuminGallery';
import { WOOD_GALLERY_PROJECTS } from '../data/woodGallery';
import { ROLLO_GALLERY_PROJECTS } from '../data/rolloGallery';
import { PRINT_GALLERY_PROJECTS } from '../data/printGallery';
import {
  FolderOpen, Camera, Sparkles, ArrowRight, X, Search,
  ShoppingCart, Info, Eye, CheckCircle2, ChevronRight,
  Maximize2, ChevronLeft, Phone, Layers, ShieldCheck, Sun,
  Grid
} from 'lucide-react';

interface MainCatalogsGatewayProps {
  onViewProduct: (product: Product) => void;
  onOrderProduct: (product: Product) => void;
  onOrderProject: (project: PortfolioProject) => void;
}

// Jaluzi Types for the Products Window (Faqat katalog namunalari)
const PRODUCT_CATEGORIES = [
  { id: 'all', name: 'Barchasi', icon: '🌟', count: '141 ta' },
  { id: 'rollo', name: 'Rollo jaluzi', icon: '📜', tag: 'Alohida Papka & 25+ Model' },
  { id: 'dikey', name: 'Dikey jaluzi', icon: '🏛️', tag: 'Alohida Papka & 28 ta Model' },
  { id: 'combo', name: 'Combo jaluzi', icon: '☀️', tag: 'Alohida Papka & 14 ta Model' },
  { id: 'bambuk', name: 'Bambuk jaluzi', icon: '🎋', tag: '100% Tabiiy Eko' },
  { id: 'wood', name: 'Wood (Yog‘och) jaluzi', icon: '🪵', tag: 'Tabiiy Eman & Lipa' },
  { id: 'alyumin', name: 'Alyumin jaluzi', icon: '🏢', tag: 'Namlikka Chidamli' },
  { id: 'honeycomb', name: 'Honeycomb jaluzi', icon: '🐝', tag: 'Termo-Izolyatsiya' },
  { id: 'plisse', name: 'Plisse jaluzi', icon: '🪟', tag: 'Akkordeon & Mansarda' },
  { id: 'fabrics', name: 'Matolar & Namunalar', icon: '🎨', tag: 'Real Namunalar' },
];

// Jaluzi Types for the Portfolio / Completed Works Window (DIKEY PARDA 1-O'RINDA, PRINT JALUZI 7-O'RINDA)
const PORTFOLIO_CATEGORIES = [
  'Dikey pardalar',
  'Barchasi',
  'Combo jaluzi',
  'Plisse jaluzi',
  'Bambuk jaluzi',
  'Wood (Yog‘och) jaluzi',
  'Roller jaluzi',
  'Print jaluzi',
  'Alyumin jaluzi',
  'Honeycomb jaluzi',
  'Rim pardalari',
];

export default function MainCatalogsGateway({
  onViewProduct,
  onOrderProduct,
  onOrderProject,
}: MainCatalogsGatewayProps) {
  // Modal states
  const [isProductsModalOpen, setIsProductsModalOpen] = useState(false);
  const [isPortfolioModalOpen, setIsPortfolioModalOpen] = useState(false);
  const [isDikeyGalleryOpen, setIsDikeyGalleryOpen] = useState(false);
  const [isPlisseGalleryOpen, setIsPlisseGalleryOpen] = useState(false);
  const [isComboGalleryOpen, setIsComboGalleryOpen] = useState(false);
  const [isAlyuminGalleryOpen, setIsAlyuminGalleryOpen] = useState(false);
  const [isWoodGalleryOpen, setIsWoodGalleryOpen] = useState(false);
  const [isRolloGalleryOpen, setIsRolloGalleryOpen] = useState(false);
  const [isPrintGalleryOpen, setIsPrintGalleryOpen] = useState(false);
  const [catalogSpecialCategory, setCatalogSpecialCategory] = useState<'rollo' | 'dikey' | 'combo' | null>(null);
  const [similarJaluziTarget, setSimilarJaluziTarget] = useState<Product | null>(null);

  // Products state
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedProductCategory, setSelectedProductCategory] = useState<string>('all');
  const [productSearchQuery, setProductSearchQuery] = useState<string>('');

  // Portfolio state (Dikey parda 1-chisida turgan bo'lishi kerak)
  const [projects, setProjects] = useState<PortfolioProject[]>([]);
  const [selectedPortfolioCategory, setSelectedPortfolioCategory] = useState<string>('Dikey pardalar');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  // Fetch initial data & listen to CMS updates
  const loadData = () => {
    setProducts(dbService.getProducts());
    setProjects(dbService.getProjects());
  };

  useEffect(() => {
    loadData();
    window.addEventListener('cms_update', loadData);

    const handleOpenCatalog = () => {
      setIsProductsModalOpen(true);
      setIsPortfolioModalOpen(false);
    };

    const handleOpenPortfolio = () => {
      setIsPortfolioModalOpen(true);
      setIsProductsModalOpen(false);
    };

    window.addEventListener('open_products_catalog', handleOpenCatalog);
    window.addEventListener('open_portfolio_gallery', handleOpenPortfolio);

    return () => {
      window.removeEventListener('cms_update', loadData);
      window.removeEventListener('open_products_catalog', handleOpenCatalog);
      window.removeEventListener('open_portfolio_gallery', handleOpenPortfolio);
    };
  }, []);

  // Open category directly (Mahsulotlar katalogidagi maxsus papkalar)
  const handleOpenProductsCategory = (catId: string) => {
    if (catId === 'rollo') {
      setCatalogSpecialCategory('rollo');
      return;
    }
    if (catId === 'dikey') {
      setCatalogSpecialCategory('dikey');
      return;
    }
    if (catId === 'combo') {
      setCatalogSpecialCategory('combo');
      return;
    }
    setSelectedProductCategory(catId);
    setProductSearchQuery('');
    setIsProductsModalOpen(true);
    setIsPortfolioModalOpen(false);
  };

  // Filtered Products logic (with materials guaranteed at the beginning)
  const filteredProducts = useMemo(() => {
    const matched = products.filter((p) => {
      const matchesCategory =
        selectedProductCategory === 'all' ||
        (selectedProductCategory === 'fabrics' && (p.category.toLowerCase().includes('matolar') || p.category.toLowerCase().includes('katalog') || p.category.toLowerCase().includes('namuna'))) ||
        (selectedProductCategory === 'plisse' && (p.category.toLowerCase().includes('plisse') || p.name.toLowerCase().includes('plisse') || p.name.toLowerCase().includes('pleated'))) ||
        (selectedProductCategory === 'combo' && p.category.toLowerCase().includes('combo')) ||
        (selectedProductCategory === 'bambuk' && p.category.toLowerCase().includes('bambuk')) ||
        (selectedProductCategory === 'wood' && (p.category.toLowerCase().includes('wood') || p.category.toLowerCase().includes('yog‘och') || p.category.toLowerCase().includes('yogoch'))) ||
        ((selectedProductCategory === 'rollo' || selectedProductCategory === 'roller') && (p.category.toLowerCase().includes('roller') || p.category.toLowerCase().includes('rollo') || p.category.toLowerCase().includes('rulon'))) ||
        (selectedProductCategory === 'alyumin' && (p.category.toLowerCase().includes('alyumin') || p.category.toLowerCase().includes('alyuminiy'))) ||
        (selectedProductCategory === 'honeycomb' && p.category.toLowerCase().includes('honeycomb')) ||
        (selectedProductCategory === 'dikey' && (p.category.toLowerCase().includes('dikey') || p.category.toLowerCase().includes('vertikal') || p.category.toLowerCase().includes('premium'))) ||
        (selectedProductCategory === 'rim' && p.category.toLowerCase().includes('rim'));

      const matchesSearch =
        p.name.toLowerCase().includes(productSearchQuery.toLowerCase()) ||
        p.description.toLowerCase().includes(productSearchQuery.toLowerCase()) ||
        p.material.toLowerCase().includes(productSearchQuery.toLowerCase());

      return matchesCategory && matchesSearch;
    });

    if (selectedProductCategory === 'all' && !productSearchQuery) {
      return [...matched].sort((a, b) => {
        const isAMat = a.category.toLowerCase().includes('matolar') || a.id.startsWith('prod-matolar');
        const isBMat = b.category.toLowerCase().includes('matolar') || b.id.startsWith('prod-matolar');
        // Material samples come first at the beginning
        if (isAMat && !isBMat) return -1;
        if (!isAMat && isBMat) return 1;
        return 0;
      });
    }

    return matched;
  }, [products, selectedProductCategory, productSearchQuery]);

  // Filtered Projects logic
  const filteredProjects = projects.filter((proj) => {
    if (selectedPortfolioCategory === 'Barchasi') return true;
    const cat = proj.category.toLowerCase();
    const sel = selectedPortfolioCategory.toLowerCase();

    if (sel.includes('combo')) return cat.includes('combo');
    if (sel.includes('plisse')) return cat.includes('plisse');
    if (sel.includes('bambuk')) return cat.includes('bambuk');
    if (sel.includes('wood') || sel.includes('yog‘och') || sel.includes('yogoch')) {
      return cat.includes('wood') || cat.includes('yog‘och') || cat.includes('yogoch');
    }
    if (sel.includes('roller')) return cat.includes('roller') || cat.includes('rollo') || cat.includes('rulon');
    if (sel.includes('alyumin')) return cat.includes('alyumin') || cat.includes('alyuminiy');
    if (sel.includes('honeycomb')) return cat.includes('honeycomb');
    if (sel.includes('dikey')) return cat.includes('dikey') || cat.includes('vertikal');
    if (sel.includes('rim')) return cat.includes('rim');

    return cat.includes(sel);
  });

  // Open portfolio modal directly with a specific category
  const handleOpenPortfolioCategory = (catName: string) => {
    setSelectedPortfolioCategory(catName);
    setIsPortfolioModalOpen(true);
  };

  return (
    <>
      {/* ========================================================================= */}
      {/* 2 TA ASOSIY KATALOG BO'LIMI (VERTIKAL TO'G'RI BURCHAKLI 2 TA OYNA KARTASI) */}
      {/* ========================================================================= */}
      <section id="products" className="py-20 sm:py-28 bg-brand-cream border-b border-brand-emerald/10 relative overflow-hidden">
        {/* Subtle decorative glow */}
        <div className="absolute top-10 left-1/4 w-96 h-96 bg-brand-emerald/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-10 right-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-12 relative z-10">
          
          {/* Section Header */}
          <div className="text-center max-w-3xl mx-auto mb-14 sm:mb-16 flex flex-col items-center gap-4">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-brand-emerald/10 text-brand-emerald text-xs font-bold uppercase tracking-widest border border-brand-emerald/15 shadow-2xs">
              <Sparkles className="w-3.5 h-3.5 text-brand-emerald" />
              <span>ECO JALUZI ASOSIY BO‘LIMLARI</span>
            </div>

            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-brand-emerald-dark leading-tight">
              Jaluzilar Katalogi va Qilingan Ishlar
            </h2>
            <div className="h-1.5 w-20 bg-gradient-to-r from-brand-emerald to-amber-400 rounded-full my-0.5" />
            <p className="text-brand-charcoal/75 font-light max-w-2xl text-sm sm:text-base leading-relaxed">
              O‘zingizga kerakli bo‘limni tanlang: barcha jaluzi turlari va mahsulotlar to‘liq katalogi yoki o‘rnatilgan 1,500+ real loyihalarimiz galereyasi.
            </p>
          </div>

          {/* 2 TA VERTIKAL TO'G'RI BURCHAKLI OYNA KARTALARI (EXACT 2-CARD RECTANGULAR LAYOUT) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10 max-w-5xl mx-auto">
            
            {/* 1-KARTA: MAHSULOTLAR KATALOGI */}
            <div
              id="card-open-products-catalog"
              onClick={() => setIsProductsModalOpen(true)}
              className="group relative bg-brand-beige rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 cursor-pointer border border-brand-emerald/15 hover:border-brand-emerald/40 aspect-[4/5] flex flex-col justify-end p-6 sm:p-8 text-brand-cream hover:-translate-y-1.5"
            >
              {/* Background Image */}
              <img
                src="https://i.ibb.co/ymGJPMVL/image.png"
                alt="Jaluzilar katalogi"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  e.currentTarget.src = "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80";
                }}
                className="absolute inset-0 w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-108 brightness-[0.75] group-hover:brightness-[0.65]"
              />

              {/* Gradient Scrim */}
              <div className="absolute inset-0 bg-gradient-to-t from-brand-emerald-dark/95 via-brand-emerald-dark/50 to-transparent" />

              {/* Top Pill Badge */}
              <div className="absolute top-6 left-6 z-10">
                <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-brand-cream/90 backdrop-blur-md text-brand-emerald-dark text-xs font-bold uppercase tracking-wider shadow-md">
                  <FolderOpen className="w-3.5 h-3.5 text-brand-emerald" />
                  <span>1-Katalog: Mahsulotlar</span>
                </span>
              </div>

              {/* Content Box */}
              <div className="relative z-10 space-y-3">
                <div className="inline-block px-2.5 py-0.5 rounded-md bg-amber-400/90 text-brand-emerald-dark text-[11px] font-extrabold uppercase tracking-wider">
                  12+ JALUZI TURLARI & MATOLAR
                </div>

                <h3 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold text-white leading-tight group-hover:text-amber-300 transition-colors">
                  Jaluzilar va Mahsulotlar Katalogi
                </h3>

                <p className="text-xs sm:text-sm text-brand-cream/85 font-light line-clamp-3 leading-relaxed">
                  Plisse, Bambuk, Wood, Combo, Roller, Alyumin, Honeycomb va Dikey jaluzilarning barcha turlari, namunalari va narxlari.
                </p>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsProductsModalOpen(true);
                    }}
                    className="w-full py-3.5 px-6 rounded-2xl bg-brand-emerald hover:bg-brand-emerald-light text-brand-cream text-xs sm:text-sm font-bold uppercase tracking-wider transition-all duration-300 shadow-xl flex items-center justify-center gap-2 group-hover:shadow-2xl border border-white/20 active:scale-95"
                  >
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    <span>Katalogga kirish (Mahsulotlar)</span>
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </button>
                </div>
              </div>
            </div>

            {/* 2-KARTA: QILINGAN ISHLAR (REAL LOYIHALAR) */}
            <div
              id="card-open-portfolio-gallery"
              onClick={() => setIsPortfolioModalOpen(true)}
              className="group relative bg-brand-beige rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 cursor-pointer border border-brand-emerald/15 hover:border-amber-400/50 aspect-[4/5] flex flex-col justify-end p-6 sm:p-8 text-brand-cream hover:-translate-y-1.5"
            >
              {/* Background Image */}
              <img
                src="https://i.ibb.co/pB5B10rK/image.png"
                alt="Qilingan ishlar"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  e.currentTarget.src = "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80";
                }}
                className="absolute inset-0 w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-108 brightness-[0.75] group-hover:brightness-[0.65]"
              />

              {/* Gradient Scrim */}
              <div className="absolute inset-0 bg-gradient-to-t from-brand-charcoal/95 via-brand-charcoal/50 to-transparent" />

              {/* Top Pill Badge */}
              <div className="absolute top-6 left-6 z-10">
                <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-400/95 backdrop-blur-md text-brand-emerald-dark text-xs font-bold uppercase tracking-wider shadow-md">
                  <Camera className="w-3.5 h-3.5 text-brand-emerald-dark" />
                  <span>2-Katalog: Qilingan ishlar</span>
                </span>
              </div>

              {/* Content Box */}
              <div className="relative z-10 space-y-3">
                <div className="inline-block px-2.5 py-0.5 rounded-md bg-brand-emerald/90 text-white text-[11px] font-extrabold uppercase tracking-wider">
                  1,500+ REAL O‘RNATILGAN OBYEKTLAR
                </div>

                <h3 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold text-white leading-tight group-hover:text-amber-300 transition-colors">
                  Qilingan Ishlar Galereyasi
                </h3>

                <p className="text-xs sm:text-sm text-brand-cream/85 font-light line-clamp-3 leading-relaxed">
                  Kottejlar, xonadonlar va ofislarga o‘rnatilgan real loyihalarimiz. Har bir jaluzi turi (Combo, Plisse, Bambuk...) bo‘yicha alohida ko‘ring.
                </p>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsPortfolioModalOpen(true);
                    }}
                    className="w-full py-3.5 px-6 rounded-2xl bg-amber-400 hover:bg-amber-300 text-brand-emerald-dark text-xs sm:text-sm font-bold uppercase tracking-wider transition-all duration-300 shadow-xl flex items-center justify-center gap-2 group-hover:shadow-2xl border border-amber-300 active:scale-95"
                  >
                    <Camera className="w-4 h-4 text-brand-emerald-dark" />
                    <span>Qilingan ishlarga kirish</span>
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </button>
                </div>
              </div>
            </div>

          </div>

          {/* Quick Category Bubbles below the 2 cards */}
          <div className="mt-12 text-center">
            <p className="text-xs font-bold uppercase tracking-wider text-brand-emerald-dark/60 mb-3">
              To‘g‘ridan-to‘g‘ri jaluzi turini tanlang:
            </p>
            <div className="flex flex-wrap items-center justify-center gap-2 max-w-4xl mx-auto">
              {PRODUCT_CATEGORIES.slice(1).map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => handleOpenProductsCategory(cat.id)}
                  className="px-3.5 py-1.5 rounded-full bg-brand-beige hover:bg-brand-emerald hover:text-white text-brand-emerald-dark text-xs font-semibold border border-brand-emerald/15 transition-all shadow-2xs hover:scale-105 flex items-center gap-1.5"
                >
                  <span>{cat.icon}</span>
                  <span>{cat.name}</span>
                </button>
              ))}
            </div>
          </div>

        </div>
      </section>

      {/* ========================================================================= */}
      {/* 1-OYNA (MODAL): MAHSULOTLAR KATALOGI (DEDICATED FULL SCREEN WINDOW) */}
      {/* ========================================================================= */}
      {isProductsModalOpen && (
        <div className="fixed inset-0 z-50 bg-brand-cream overflow-y-auto animate-fadeIn flex flex-col">
          
          {/* Window Top Sticky Header */}
          <div className="sticky top-0 z-40 bg-brand-cream/95 backdrop-blur-md border-b border-brand-emerald/10 px-4 sm:px-8 py-4 shadow-sm">
            <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
              
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-brand-emerald text-brand-cream flex items-center justify-center shadow-md">
                  <FolderOpen className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="font-serif text-lg sm:text-2xl font-bold text-brand-emerald-dark">
                    Jaluzilar va Mahsulotlar Katalogi
                  </h2>
                  <p className="text-[11px] sm:text-xs text-brand-charcoal/60 font-light">
                    Barcha jaluzi turlari, xususiyatlari va narxlari ({filteredProducts.length} ta mahsulot)
                  </p>
                </div>
              </div>

              {/* Close Window Button */}
              <button
                onClick={() => setIsProductsModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-brand-beige hover:bg-brand-emerald hover:text-white text-brand-emerald-dark border border-brand-emerald/15 text-xs font-bold transition-all flex items-center gap-2 shadow-2xs hover:scale-105"
              >
                <span>Yopish / Ortga</span>
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Window Body Container */}
          <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-12 py-8 flex-grow w-full space-y-8">
            
            {/* Search Bar */}
            <div className="space-y-4">
              <div className="relative max-w-md mx-auto sm:mx-0">
                <Search className="w-4 h-4 text-brand-emerald-dark/40 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={productSearchQuery}
                  onChange={(e) => setProductSearchQuery(e.target.value)}
                  placeholder="Jaluzi nomi yoki materiali bo‘yicha qidirish..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-brand-beige/80 border border-brand-emerald/15 text-xs sm:text-sm text-brand-charcoal outline-none focus:border-brand-emerald focus:ring-2 focus:ring-brand-emerald/20 transition-all placeholder:text-brand-charcoal/40"
                />
                {productSearchQuery && (
                  <button
                    onClick={() => setProductSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-brand-charcoal/40 hover:text-brand-charcoal text-xs"
                  >
                    ✕
                  </button>
                )}
              </div>
            </div>

            {/* Category Tabs inside Modal */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none no-scrollbar">
              {PRODUCT_CATEGORIES.map((cat) => {
                const isActive = selectedProductCategory === cat.id;
                const isRollo = cat.id === 'rollo';
                const isDikey = cat.id === 'dikey';
                const isCombo = cat.id === 'combo';
                const isSpecial = isRollo || isDikey || isCombo;
                return (
                  <button
                    key={cat.id}
                    onClick={() => {
                      if (cat.id === 'rollo') {
                        setCatalogSpecialCategory('rollo');
                      } else if (cat.id === 'dikey') {
                        setCatalogSpecialCategory('dikey');
                      } else if (cat.id === 'combo') {
                        setCatalogSpecialCategory('combo');
                      } else {
                        setSelectedProductCategory(cat.id);
                        setProductSearchQuery('');
                      }
                    }}
                    className={`px-4 py-2 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap shadow-2xs cursor-pointer ${
                      isActive
                        ? isSpecial
                          ? 'bg-amber-400 text-brand-emerald-dark ring-2 ring-amber-400 ring-offset-2 ring-offset-brand-cream scale-105 shadow-md'
                          : 'bg-brand-emerald text-white shadow-md'
                        : isSpecial
                        ? 'bg-amber-100 text-amber-900 border border-amber-300/80 hover:bg-amber-200'
                        : 'bg-brand-beige hover:bg-brand-emerald/10 text-brand-emerald-dark border border-brand-emerald/10'
                    }`}
                  >
                    <span>{cat.icon}</span>
                    <span>{cat.name}</span>
                    {isSpecial && (
                      <span className="px-1.5 py-0.5 rounded-full bg-amber-500/20 text-[10px] font-black uppercase">
                        Papka
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* ROLLO JALUZILAR MAXSUS ALOHIDA OYNA KARTASI (FAQAT KATALOGDA) */}
            {(selectedProductCategory === 'all' || selectedProductCategory === 'rollo') && !productSearchQuery && (
              <div
                id="card-rollo-products-modal-gateway"
                onClick={() => setCatalogSpecialCategory('rollo')}
                className="relative bg-gradient-to-br from-teal-950 via-slate-900 to-teal-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl cursor-pointer hover:shadow-2xl transition-all duration-300 border-2 border-teal-400/80 hover:border-teal-300 group overflow-hidden animate-fadeIn"
              >
                {/* Decorative warm cyan/teal glow */}
                <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-teal-400/20 rounded-full blur-3xl group-hover:scale-125 transition-transform duration-700 pointer-events-none" />

                <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
                  <div className="space-y-3 max-w-2xl">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-3 py-1 rounded-full bg-teal-400 text-slate-950 font-extrabold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md">
                        <span>📜</span>
                        <span>MAXSUS PAPKA: ROLLO (RULONLI) JALUZI</span>
                      </span>
                      <span className="px-2.5 py-0.5 rounded-md bg-white/20 text-white text-xs font-semibold">
                        {ROLLO_CATALOG_ITEMS.length} ta Katalog Modeli
                      </span>
                    </div>

                    <h3 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold text-white group-hover:text-teal-300 transition-colors">
                      Rollo Jaluzilar — Real Mahsulotlar va Namunalar Galereyasi
                    </h3>

                    <p className="text-xs sm:text-sm text-brand-cream/85 font-light leading-relaxed">
                      100% Blackout (qorong‘ilashtiruvchi), Dimout (nur taratuvchi) va Screen matoli barcha {ROLLO_CATALOG_ITEMS.length} ta eksklyuziv rollo namunalarimizni alohida maxsus oynada ko‘ring. Shu kartani bosib to‘liq albom oynasiga kiring.
                    </p>

                    <div className="flex flex-wrap items-center gap-3 pt-1">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setCatalogSpecialCategory('rollo');
                        }}
                        className="px-5 py-3 rounded-2xl bg-teal-400 hover:bg-teal-300 text-slate-950 font-bold text-xs uppercase tracking-wider shadow-xl flex items-center gap-2 transition-all group-hover:scale-105 active:scale-95 cursor-pointer"
                      >
                        <span>Rollo rasmlarini alohida oynada ochish ({ROLLO_CATALOG_ITEMS.length} ta model)</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                      <span className="text-xs text-brand-cream/75 font-medium">
                        Barcha {ROLLO_CATALOG_ITEMS.length} ta katalog suratlari
                      </span>
                    </div>
                  </div>

                  {/* 2-photo preview collage */}
                  <div className="grid grid-cols-2 gap-3 w-full sm:w-72 lg:w-80 flex-shrink-0">
                    <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/20 shadow-md">
                      <img
                        src="https://i.ibb.co/3y3FB3sn/photo-2026-10-01-20-48-17.jpg"
                        alt="Rollo montaj 1"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                    </div>
                    <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/20 shadow-md">
                      <img
                        src="https://i.ibb.co/ZRvkB213/photo-2026-10-01-20-45-04-2.jpg"
                        alt="Rollo montaj 2"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* DIKEY JALUZILAR MAXSUS ALOHIDA OYNA KARTASI (FAQAT KATALOGDA) */}
            {(selectedProductCategory === 'all' || selectedProductCategory === 'dikey') && !productSearchQuery && (
              <div
                id="card-dikey-products-modal-gateway"
                onClick={() => setCatalogSpecialCategory('dikey')}
                className="relative bg-gradient-to-br from-amber-950 via-stone-900 to-amber-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl cursor-pointer hover:shadow-2xl transition-all duration-300 border-2 border-amber-400/80 hover:border-amber-300 group overflow-hidden animate-fadeIn"
              >
                {/* Decorative warm amber glow */}
                <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-amber-400/20 rounded-full blur-3xl group-hover:scale-125 transition-transform duration-700 pointer-events-none" />

                <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
                  <div className="space-y-3 max-w-2xl">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-3 py-1 rounded-full bg-amber-400 text-stone-950 font-extrabold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md">
                        <span>🏛️</span>
                        <span>MAXSUS PAPKA: DIKEY (VERTIKAL) PARDA</span>
                      </span>
                      <span className="px-2.5 py-0.5 rounded-md bg-white/20 text-white text-xs font-semibold">
                        {DIKEY_CATALOG_ITEMS.length} ta Katalog Modeli
                      </span>
                    </div>

                    <h3 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold text-white group-hover:text-amber-300 transition-colors">
                      Dikey Pardalar — Real Mahsulotlar va Namunalar Galereyasi
                    </h3>

                    <p className="text-xs sm:text-sm text-brand-cream/85 font-light leading-relaxed">
                      180° erkin buriluvchi, nafis burmali va hashamatli saroyona to‘qimali barcha {DIKEY_CATALOG_ITEMS.length} ta eksklyuziv dikey pardalar namunalarimizni alohida maxsus oynada ko‘ring. Shu kartani bosib to‘liq albom oynasiga kiring.
                    </p>

                    <div className="flex flex-wrap items-center gap-3 pt-1">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setCatalogSpecialCategory('dikey');
                        }}
                        className="px-5 py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold text-xs uppercase tracking-wider shadow-xl flex items-center gap-2 transition-all group-hover:scale-105 active:scale-95 cursor-pointer"
                      >
                        <span>Dikey rasmlarini alohida oynada ochish ({DIKEY_CATALOG_ITEMS.length} ta model)</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                      <span className="text-xs text-brand-cream/75 font-medium">
                        Barcha {DIKEY_CATALOG_ITEMS.length} ta katalog suratlari
                      </span>
                    </div>
                  </div>

                  {/* 2-photo preview collage */}
                  <div className="grid grid-cols-2 gap-3 w-full sm:w-72 lg:w-80 flex-shrink-0">
                    <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/20 shadow-md">
                      <img
                        src="https://i.ibb.co/zTTkNdF2/photo-2026-08-28-11-39-23.jpg"
                        alt="Dikey montaj 1"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                    </div>
                    <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/20 shadow-md">
                      <img
                        src="https://i.ibb.co/JFRMRW0F/photo-2026-08-28-11-39-22.jpg"
                        alt="Dikey montaj 2"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* COMBO (KUN-TUN) JALUZILAR MAXSUS ALOHIDA OYNA KARTASI (FAQAT KATALOGDA) */}
            {(selectedProductCategory === 'all' || selectedProductCategory === 'combo') && !productSearchQuery && (
              <div
                id="card-combo-products-modal-gateway"
                onClick={() => setCatalogSpecialCategory('combo')}
                className="relative bg-gradient-to-br from-amber-950 via-yellow-950 to-amber-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl cursor-pointer hover:shadow-2xl transition-all duration-300 border-2 border-amber-500/80 hover:border-amber-400 group overflow-hidden animate-fadeIn"
              >
                {/* Decorative warm sunshine glow */}
                <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-yellow-500/20 rounded-full blur-3xl group-hover:scale-125 transition-transform duration-700 pointer-events-none" />

                <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
                  <div className="space-y-3 max-w-2xl">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-3 py-1 rounded-full bg-amber-500 text-slate-950 font-extrabold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md">
                        <span>☀️</span>
                        <span>MAXSUS PAPKA: COMBO (KUN-TUN) JALUZI</span>
                      </span>
                      <span className="px-2.5 py-0.5 rounded-md bg-white/20 text-white text-xs font-semibold">
                        {COMBO_CATALOG_ITEMS.length} ta Katalog Modeli
                      </span>
                    </div>

                    <h3 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold text-white group-hover:text-amber-300 transition-colors">
                      Combo (Kun-Tun / Zebra) Jaluzilar — Real Mahsulotlar va Namunalar
                    </h3>

                    <p className="text-xs sm:text-sm text-brand-cream/85 font-light leading-relaxed">
                      2 qavatli almashinuvchi shaffof va qalin tolalari bilan yorug‘likni nozik sozlovchi barcha {COMBO_CATALOG_ITEMS.length} ta eksklyuziv montaj namunalarimizni alohida maxsus oynada ko‘ring. Shu kartani bosib to‘liq albom oynasiga kiring.
                    </p>

                    <div className="flex flex-wrap items-center gap-3 pt-1">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setCatalogSpecialCategory('combo');
                        }}
                        className="px-5 py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs uppercase tracking-wider shadow-xl flex items-center gap-2 transition-all group-hover:scale-105 active:scale-95 cursor-pointer"
                      >
                        <span>Combo rasmlarini alohida oynada ochish ({COMBO_CATALOG_ITEMS.length} ta model)</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                      <span className="text-xs text-brand-cream/75 font-medium">
                        Barcha {COMBO_CATALOG_ITEMS.length} ta katalog suratlari
                      </span>
                    </div>
                  </div>

                  {/* 2-photo preview collage */}
                  <div className="grid grid-cols-2 gap-3 w-full sm:w-72 lg:w-80 flex-shrink-0">
                    <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/20 shadow-md">
                      <img
                        src="https://i.ibb.co/Kp5XQX4n/photo-2026-10-01-20-53-09.jpg"
                        alt="Combo montaj 1"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                    </div>
                    <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/20 shadow-md">
                      <img
                        src="https://i.ibb.co/yFH4VRgg/photo-2026-10-01-20-52-57.jpg"
                        alt="Combo montaj 2"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}


            {/* Products Grid inside Modal */}
            {filteredProducts.length === 0 ? (
              <div className="text-center py-20 bg-brand-beige/40 rounded-3xl border border-dashed border-brand-emerald/20 p-8">
                <FolderOpen className="w-12 h-12 text-brand-emerald/30 mx-auto mb-3" />
                <h4 className="text-base font-bold text-brand-emerald-dark">Ushbu toifada mahsulot topilmadi</h4>
                <p className="text-xs text-brand-charcoal/60 mt-1">Boshqa toifani tanlang yoki qidiruv so‘zini o‘zgartiring.</p>
                <button
                  onClick={() => {
                    setSelectedProductCategory('all');
                    setProductSearchQuery('');
                  }}
                  className="mt-4 px-4 py-2 bg-brand-emerald text-white rounded-xl text-xs font-bold"
                >
                  Barcha mahsulotlarni ko‘rish
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
                {filteredProducts.map((product) => (
                  <div
                    key={product.id}
                    id={`modal-product-card-${product.id}`}
                    className="group relative bg-brand-beige rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-brand-emerald/10 flex flex-col h-full hover:-translate-y-1"
                  >
                    {/* Image Section - Clicking image opens similar jaluzi models */}
                    <div
                      onClick={() => setSimilarJaluziTarget(product)}
                      className="relative h-64 overflow-hidden bg-brand-charcoal/10 cursor-pointer"
                    >
                      <img
                        src={product.image}
                        alt={product.name}
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          e.currentTarget.src = "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=800&q=80";
                        }}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      />

                      {/* Hover Overlay Prompt */}
                      <div className="absolute inset-0 bg-brand-charcoal/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center gap-2 z-20 p-4 text-center">
                        <div className="w-12 h-12 rounded-full bg-amber-400 text-brand-emerald-dark flex items-center justify-center shadow-xl transform group-hover:scale-110 transition-transform">
                          <Eye className="w-6 h-6" />
                        </div>
                        <span className="text-white text-xs font-bold bg-brand-charcoal/80 px-3 py-1 rounded-full backdrop-blur-sm shadow-md">
                          O‘xshash jaluzi modellarini ochish
                        </span>
                      </div>
                    </div>

                    {/* Content Section */}
                    <div className="p-4 sm:p-5 flex flex-col justify-between">
                      {/* CTAs */}
                      <div className="flex items-center justify-between gap-3">
                        <button
                          onClick={() => setSimilarJaluziTarget(product)}
                          className="flex-1 justify-center px-3 py-2.5 rounded-xl text-xs font-bold text-brand-emerald-dark bg-brand-emerald/10 hover:bg-brand-emerald/20 transition-colors flex items-center gap-1.5 shadow-2xs hover:scale-102"
                        >
                          <Eye className="w-3.5 h-3.5 text-brand-emerald" />
                          <span>O‘xshash jaluzilar</span>
                        </button>

                        <button
                          onClick={() => {
                            setIsProductsModalOpen(false);
                            onOrderProduct(product);
                          }}
                          className="flex-1 justify-center px-3 py-2.5 rounded-xl text-xs font-bold text-white bg-brand-emerald-dark hover:bg-brand-emerald transition-colors flex items-center gap-1.5 shadow-sm active:scale-95"
                        >
                          <ShoppingCart className="w-3.5 h-3.5 text-amber-300" />
                          <span>Buyurtma</span>
                        </button>
                      </div>
                    </div>

                  </div>
                ))}
              </div>
            )}

          </div>

          {/* Modal Bottom Footer */}
          <div className="bg-brand-beige border-t border-brand-emerald/10 px-4 py-4 text-center">
            <button
              onClick={() => setIsProductsModalOpen(false)}
              className="px-6 py-2.5 bg-brand-emerald text-white rounded-xl text-xs font-bold shadow-md hover:bg-brand-emerald-dark transition-all"
            >
              Katalogni yopish
            </button>
          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* 2-OYNA (MODAL): QILINGAN ISHLAR (DEDICATED FULL SCREEN PORTFOLIO WINDOW) */}
      {/* ========================================================================= */}
      {isPortfolioModalOpen && (
        <div className="fixed inset-0 z-50 bg-brand-cream overflow-y-auto animate-fadeIn flex flex-col">
          
          {/* Window Top Sticky Header */}
          <div className="sticky top-0 z-40 bg-brand-cream/95 backdrop-blur-md border-b border-brand-emerald/10 px-4 sm:px-8 py-4 shadow-sm">
            <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
              
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-brand-emerald text-brand-cream flex items-center justify-center shadow-md">
                  <Camera className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="font-serif text-lg sm:text-2xl font-bold text-brand-emerald-dark">
                    Qilingan Ishlar Galereyasi
                  </h2>
                  <p className="text-[11px] sm:text-xs text-brand-charcoal/60 font-light">
                    Real o‘rnatilgan dikey va plisse jaluzi loyihalari galereyasi
                  </p>
                </div>
              </div>

              {/* Close Window Button */}
              <button
                onClick={() => setIsPortfolioModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-brand-beige hover:bg-brand-emerald hover:text-white text-brand-emerald-dark border border-brand-emerald/15 text-xs font-bold transition-all flex items-center gap-2 shadow-2xs hover:scale-105"
              >
                <span>Yopish / Ortga</span>
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Window Body Container */}
          <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-12 py-8 flex-grow w-full space-y-6 sm:space-y-8">

            {/* 1-CHISIDA TURGAN DIKEY PARDA MAXSUS OYNA KARTASI (BOSHQA OYNAGA OLIB KIRADI) */}
            <div
              id="card-dikey-dedicated-gateway"
              onClick={() => setIsDikeyGalleryOpen(true)}
              className="relative bg-gradient-to-br from-brand-emerald-dark via-brand-emerald to-brand-emerald-dark rounded-3xl p-6 sm:p-8 text-white shadow-xl cursor-pointer hover:shadow-2xl transition-all duration-300 border-2 border-amber-400/70 hover:border-amber-400 group overflow-hidden"
            >
              {/* Decorative amber glow */}
              <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-amber-400/20 rounded-full blur-3xl group-hover:scale-125 transition-transform duration-700 pointer-events-none" />

              <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
                <div className="space-y-3 max-w-2xl">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-3 py-1 rounded-full bg-amber-400 text-brand-emerald-dark font-extrabold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md">
                      <span>🏛️</span>
                      <span>1-O‘RINDAGI MAHSULOT: DIKEY PARDA</span>
                    </span>
                    <span className="px-2.5 py-0.5 rounded-md bg-white/20 text-white text-xs font-semibold">
                      {DIKEY_GALLERY_PROJECTS.length} ta Real Suratlar
                    </span>
                  </div>

                  <h3 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold text-white group-hover:text-amber-300 transition-colors">
                    Dikey Pardalar — Real Qilingan Ishlarimiz Galereyasi
                  </h3>

                  <p className="text-xs sm:text-sm text-brand-cream/85 font-light leading-relaxed">
                    Katta zallar, mehmonxonalar, vitraj va kottejlarga o‘rnatilgan barcha {DIKEY_GALLERY_PROJECTS.length} ta eksklyuziv dikey loyihalarimizni alohida maxsus oynada ko‘ring. Shu kartani bosib to‘liq albom oynasiga kiring.
                  </p>

                  <div className="flex flex-wrap items-center gap-3 pt-1">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setIsDikeyGalleryOpen(true);
                      }}
                      className="px-5 py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-brand-emerald-dark font-bold text-xs uppercase tracking-wider shadow-xl flex items-center gap-2 transition-all group-hover:scale-105 active:scale-95"
                    >
                      <span>Dikey rasmlarini alohida oynada ochish ({DIKEY_GALLERY_PROJECTS.length} ta rasm)</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                    <span className="text-xs text-brand-cream/75 font-medium">
                      Barcha montajlar fotosuratlari
                    </span>
                  </div>
                </div>

                {/* 2-photo preview collage */}
                <div className="grid grid-cols-2 gap-3 w-full sm:w-72 lg:w-80 flex-shrink-0">
                  <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/20 shadow-md">
                    <img
                      src="https://i.ibb.co/rT84vY7/photo-2026-07-26-02-54-46.jpg"
                      alt="Dikey montaj 1"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/20 shadow-md">
                    <img
                      src="https://i.ibb.co/fVXhb3Lk/photo-2026-07-29-01-00-38.jpg"
                      alt="Dikey montaj 2"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* 2-CHISIDA TURGAN PLISSE JALUZI MAXSUS OYNA KARTASI (BOSHQA OYNAGA OLIB KIRADI) */}
            <div
              id="card-plisse-dedicated-gateway"
              onClick={() => setIsPlisseGalleryOpen(true)}
              className="relative bg-gradient-to-br from-brand-charcoal via-brand-emerald-dark to-brand-charcoal rounded-3xl p-6 sm:p-8 text-white shadow-xl cursor-pointer hover:shadow-2xl transition-all duration-300 border-2 border-emerald-400/60 hover:border-amber-400 group overflow-hidden"
            >
              {/* Decorative emerald glow */}
              <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-emerald-400/15 rounded-full blur-3xl group-hover:scale-125 transition-transform duration-700 pointer-events-none" />

              <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
                <div className="space-y-3 max-w-2xl">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-3 py-1 rounded-full bg-emerald-400 text-brand-emerald-dark font-extrabold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md">
                      <span>📐</span>
                      <span>2-O‘RINDAGI MAHSULOT: PLISSE JALUZI</span>
                    </span>
                    <span className="px-2.5 py-0.5 rounded-md bg-white/20 text-white text-xs font-semibold">
                      {PLISSE_GALLERY_PROJECTS.length} ta Real Suratlar
                    </span>
                  </div>

                  <h3 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold text-white group-hover:text-amber-300 transition-colors">
                    Plisse Jaluzilar — Real Qilingan Ishlarimiz Galereyasi
                  </h3>

                  <p className="text-xs sm:text-sm text-brand-cream/85 font-light leading-relaxed">
                    Oyna romiga zich o‘rnatiluvchi, tepadan va pastdan qulay ochiluvchi nafis plisse pardalarimiz bo‘yicha montaj ishlarini alohida maxsus oynada ko‘ring. Shu kartani bosib to‘liq albom oynasiga kiring.
                  </p>

                  <div className="flex flex-wrap items-center gap-3 pt-1">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setIsPlisseGalleryOpen(true);
                      }}
                      className="px-5 py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-brand-emerald-dark font-bold text-xs uppercase tracking-wider shadow-xl flex items-center gap-2 transition-all group-hover:scale-105 active:scale-95"
                    >
                      <span>Plisse rasmlarini alohida oynada ochish ({PLISSE_GALLERY_PROJECTS.length} ta rasm)</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                    <span className="text-xs text-brand-cream/75 font-medium">
                      Barcha montajlar fotosuratlari
                    </span>
                  </div>
                </div>

                {/* 2-photo preview collage */}
                <div className="grid grid-cols-2 gap-3 w-full sm:w-72 lg:w-80 flex-shrink-0">
                  <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/20 shadow-md">
                    <img
                      src="https://i.ibb.co/b5RVxZx5/photo-2026-02-08-12-54-12.jpg"
                      alt="Plisse montaj 1"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/20 shadow-md">
                    <img
                      src="https://i.ibb.co/jPCdSXb2/photo-2026-02-08-12-54-11.jpg"
                      alt="Plisse montaj 2"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* 3-CHISIDA TURGAN COMBO (KUN-TUN) JALUZI MAXSUS OYNA KARTASI (BOSHQA OYNAGA OLIB KIRADI) */}
            <div
              id="card-combo-dedicated-gateway"
              onClick={() => setIsComboGalleryOpen(true)}
              className="relative bg-gradient-to-br from-brand-emerald via-brand-emerald-dark to-brand-charcoal rounded-3xl p-6 sm:p-8 text-white shadow-xl cursor-pointer hover:shadow-2xl transition-all duration-300 border-2 border-amber-400/80 hover:border-amber-300 group overflow-hidden"
            >
              {/* Decorative warm glow */}
              <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-amber-400/20 rounded-full blur-3xl group-hover:scale-125 transition-transform duration-700 pointer-events-none" />

              <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
                <div className="space-y-3 max-w-2xl">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-3 py-1 rounded-full bg-amber-400 text-brand-emerald-dark font-extrabold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md">
                      <span>☀️</span>
                      <span>3-O‘RINDAGI MAHSULOT: COMBO (KUN-TUN) JALUZI</span>
                    </span>
                    <span className="px-2.5 py-0.5 rounded-md bg-white/20 text-white text-xs font-semibold">
                      {COMBO_GALLERY_PROJECTS.length} ta Real Suratlar
                    </span>
                  </div>

                  <h3 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold text-white group-hover:text-amber-300 transition-colors">
                    Combo (Kun-Tun) Jaluzilar — Real Qilingan Ishlarimiz Galereyasi
                  </h3>

                  <p className="text-xs sm:text-sm text-brand-cream/85 font-light leading-relaxed">
                    Xonadonga o‘zgacha shinamlik beruvchi, kun va tun yorug‘lik oqimini bir zumda nazorat qiluvchi Combo jaluzilarimiz bo‘yicha montaj ishlarini alohida maxsus oynada ko‘ring. Shu kartani bosib to‘liq albom oynasiga kiring.
                  </p>

                  <div className="flex flex-wrap items-center gap-3 pt-1">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setIsComboGalleryOpen(true);
                      }}
                      className="px-5 py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-brand-emerald-dark font-bold text-xs uppercase tracking-wider shadow-xl flex items-center gap-2 transition-all group-hover:scale-105 active:scale-95"
                    >
                      <span>Combo rasmlarini alohida oynada ochish ({COMBO_GALLERY_PROJECTS.length} ta rasm)</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                    <span className="text-xs text-brand-cream/75 font-medium">
                      Barcha montajlar fotosuratlari
                    </span>
                  </div>
                </div>

                    {/* 2-photo preview collage */}
                <div className="grid grid-cols-2 gap-3 w-full sm:w-72 lg:w-80 flex-shrink-0">
                  <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/20 shadow-md">
                    <img
                      src="https://i.ibb.co/k27GbDXC/photo-2022-02-03-22-00-18.jpg"
                      alt="Combo montaj 1"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/20 shadow-md">
                    <img
                      src="https://i.ibb.co/RpYNGdQK/photo-2022-02-03-22-00-02.jpg"
                      alt="Combo montaj 2"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* 4-CHISIDA TURGAN ALYUMIN GORIZONTAL JALUZI MAXSUS OYNA KARTASI (BOSHQA OYNAGA OLIB KIRADI) */}
            <div
              id="card-alyumin-dedicated-gateway"
              onClick={() => setIsAlyuminGalleryOpen(true)}
              className="relative bg-gradient-to-br from-slate-900 via-brand-emerald-dark to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl cursor-pointer hover:shadow-2xl transition-all duration-300 border-2 border-cyan-400/80 hover:border-cyan-300 group overflow-hidden"
            >
              {/* Decorative cool cyan glow */}
              <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-cyan-400/20 rounded-full blur-3xl group-hover:scale-125 transition-transform duration-700 pointer-events-none" />

              <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
                <div className="space-y-3 max-w-2xl">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-3 py-1 rounded-full bg-cyan-400 text-slate-950 font-extrabold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md">
                      <span>🏢</span>
                      <span>4-O‘RINDAGI MAHSULOT: ALYUMIN GORIZONTAL JALUZI</span>
                    </span>
                    <span className="px-2.5 py-0.5 rounded-md bg-white/20 text-white text-xs font-semibold">
                      {ALYUMIN_GALLERY_PROJECTS.length} ta Real Suratlar
                    </span>
                  </div>

                  <h3 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold text-white group-hover:text-cyan-300 transition-colors">
                    Alyumin Gorizontal Jaluzilar — Real Qilingan Ishlarimiz Galereyasi
                  </h3>

                  <p className="text-xs sm:text-sm text-brand-cream/85 font-light leading-relaxed">
                    Namlik va issiqlikka 100% chidamli, oshxona, ofis va vanna xonalari uchun eng ishonchli 16mm va 25mm alyumin gorizontal jaluzilarimiz montaj ishlarini alohida maxsus oynada ko‘ring.
                  </p>

                  <div className="flex flex-wrap items-center gap-3 pt-1">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setIsAlyuminGalleryOpen(true);
                      }}
                      className="px-5 py-3 rounded-2xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs uppercase tracking-wider shadow-xl flex items-center gap-2 transition-all group-hover:scale-105 active:scale-95"
                    >
                      <span>Alyumin rasmlarini alohida oynada ochish ({ALYUMIN_GALLERY_PROJECTS.length} ta rasm)</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                    <span className="text-xs text-brand-cream/75 font-medium">
                      Barcha montajlar fotosuratlari
                    </span>
                  </div>
                </div>

                    {/* 2-photo preview collage */}
                <div className="grid grid-cols-2 gap-3 w-full sm:w-72 lg:w-80 flex-shrink-0">
                  <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/20 shadow-md">
                    <img
                      src="https://i.ibb.co/svmxwdTm/photo-2026-07-11-23-06-09.jpg"
                      alt="Alyumin montaj 1"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/20 shadow-md">
                    <img
                      src="https://i.ibb.co/79JK2DK/photo-2026-01-27-14-02-22.jpg"
                      alt="Alyumin montaj 2"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* 5-CHISIDA TURGAN WOOD (YOG'OCH) GORIZONTAL JALUZI MAXSUS OYNA KARTASI */}
            <div
              id="card-wood-dedicated-gateway"
              onClick={() => setIsWoodGalleryOpen(true)}
              className="relative bg-gradient-to-br from-amber-950 via-stone-900 to-amber-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl cursor-pointer hover:shadow-2xl transition-all duration-300 border-2 border-amber-500/80 hover:border-amber-400 group overflow-hidden"
            >
              {/* Decorative warm amber glow */}
              <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-amber-500/20 rounded-full blur-3xl group-hover:scale-125 transition-transform duration-700 pointer-events-none" />

              <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
                <div className="space-y-3 max-w-2xl">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-3 py-1 rounded-full bg-amber-500 text-stone-950 font-extrabold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md">
                      <span>🪵</span>
                      <span>5-O‘RINDAGI MAHSULOT: WOOD (YOG‘OCH) JALUZI</span>
                    </span>
                    <span className="px-2.5 py-0.5 rounded-md bg-white/20 text-white text-xs font-semibold">
                      {WOOD_GALLERY_PROJECTS.length} ta Real Suratlar
                    </span>
                  </div>

                  <h3 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold text-white group-hover:text-amber-300 transition-colors">
                    Wood (Yog‘och) Gorizontal Jaluzilar — Real Qilingan Ishlarimiz Galereyasi
                  </h3>

                  <p className="text-xs sm:text-sm text-brand-cream/85 font-light leading-relaxed">
                    100% tabiiy eman va lipa yog‘ochidan tayyorlangan, xonadonga o‘zgacha nufuz va iliqlik bag‘ishlovchi premium yog‘och gorizontal jaluzilarimiz montaj ishlarini alohida maxsus oynada ko‘ring.
                  </p>

                  <div className="flex flex-wrap items-center gap-3 pt-1">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setIsWoodGalleryOpen(true);
                      }}
                      className="px-5 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs uppercase tracking-wider shadow-xl flex items-center gap-2 transition-all group-hover:scale-105 active:scale-95"
                    >
                      <span>Wood rasmlarini alohida oynada ochish ({WOOD_GALLERY_PROJECTS.length} ta rasm)</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                    <span className="text-xs text-brand-cream/75 font-medium">
                      Barcha montajlar fotosuratlari
                    </span>
                  </div>
                </div>

                {/* 2-photo preview collage */}
                <div className="grid grid-cols-2 gap-3 w-full sm:w-72 lg:w-80 flex-shrink-0">
                  <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/20 shadow-md">
                    <img
                      src="https://i.ibb.co/jPzb3mgm/photo-2026-07-20-03-54-30-2.jpg"
                      alt="Wood montaj 1"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/20 shadow-md">
                    <img
                      src="https://i.ibb.co/qLpp6qQr/photo-2026-07-20-03-54-30.jpg"
                      alt="Wood montaj 2"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* 6-CHISIDA TURGAN ROLLO (RULONLI) JALUZI MAXSUS OYNA KARTASI */}
            <div
              id="card-rollo-dedicated-gateway"
              onClick={() => setIsRolloGalleryOpen(true)}
              className="relative bg-gradient-to-br from-teal-950 via-slate-900 to-teal-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl cursor-pointer hover:shadow-2xl transition-all duration-300 border-2 border-teal-400/80 hover:border-teal-300 group overflow-hidden"
            >
              {/* Decorative warm cyan/teal glow */}
              <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-teal-400/20 rounded-full blur-3xl group-hover:scale-125 transition-transform duration-700 pointer-events-none" />

              <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
                <div className="space-y-3 max-w-2xl">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-3 py-1 rounded-full bg-teal-400 text-slate-950 font-extrabold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md">
                      <span>📜</span>
                      <span>6-O‘RINDAGI MAHSULOT: ROLLO (RULONLI) PARDA</span>
                    </span>
                    <span className="px-2.5 py-0.5 rounded-md bg-white/20 text-white text-xs font-semibold">
                      {ROLLO_GALLERY_PROJECTS.length} ta Real Suratlar
                    </span>
                  </div>

                  <h3 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold text-white group-hover:text-teal-300 transition-colors">
                    Rollo (Rulonli) Pardalar — Real Qilingan Ishlarimiz Galereyasi
                  </h3>

                  <p className="text-xs sm:text-sm text-brand-cream/85 font-light leading-relaxed">
                    100% Blackout (qorong‘ilashtiruvchi) va Dimout matoli, quyosh nurlarini to‘liq to‘suvchi hamda derazaga bejirim turuvchi zamonaviy Rollo (rulonli) pardalarimiz montaj fotolarini alohida to‘liq oynada ko‘ring.
                  </p>

                  <div className="flex flex-wrap items-center gap-3 pt-1">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setIsRolloGalleryOpen(true);
                      }}
                      className="px-5 py-3 rounded-2xl bg-teal-400 hover:bg-teal-300 text-slate-950 font-bold text-xs uppercase tracking-wider shadow-xl flex items-center gap-2 transition-all group-hover:scale-105 active:scale-95"
                    >
                      <span>Rollo rasmlarini alohida oynada ochish ({ROLLO_GALLERY_PROJECTS.length} ta rasm)</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                    <span className="text-xs text-brand-cream/75 font-medium">
                      Barcha montajlar fotosuratlari
                    </span>
                  </div>
                </div>

                {/* 2-photo preview collage */}
                <div className="grid grid-cols-2 gap-3 w-full sm:w-72 lg:w-80 flex-shrink-0">
                  <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/20 shadow-md">
                    <img
                      src="https://i.ibb.co/ksrTr7fr/photo-2025-11-19-22-40-12.jpg"
                      alt="Rollo montaj 1"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/20 shadow-md">
                    <img
                      src="https://i.ibb.co/jkcvwbT1/photo-2026-09-01-12-14-19.jpg"
                      alt="Rollo montaj 2"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* 7-CHISIDA TURGAN PRINT (FOTO) JALUZI MAXSUS OYNA KARTASI */}
            <div
              id="card-print-dedicated-gateway"
              onClick={() => setIsPrintGalleryOpen(true)}
              className="relative bg-gradient-to-br from-purple-950 via-slate-900 to-indigo-950 rounded-3xl p-6 sm:p-8 text-white shadow-xl cursor-pointer hover:shadow-2xl transition-all duration-300 border-2 border-purple-500/80 hover:border-purple-400 group overflow-hidden"
            >
              {/* Decorative warm purple glow */}
              <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-purple-500/20 rounded-full blur-3xl group-hover:scale-125 transition-transform duration-700 pointer-events-none" />

              <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
                <div className="space-y-3 max-w-2xl">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-3 py-1 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 text-white font-extrabold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md">
                      <span>🎨</span>
                      <span>7-O‘RINDAGI MAHSULOT: PRINT (FOTO) JALUZI</span>
                    </span>
                    <span className="px-2.5 py-0.5 rounded-md bg-white/20 text-white text-xs font-semibold">
                      {PRINT_GALLERY_PROJECTS.length} ta Real Suratlar
                    </span>
                  </div>

                  <h3 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold text-white group-hover:text-purple-300 transition-colors">
                    Print (Foto) Jaluzilar — Real Qilingan Ishlarimiz Galereyasi
                  </h3>

                  <p className="text-xs sm:text-sm text-brand-cream/85 font-light leading-relaxed">
                    Bolalar xonalari, oshxona, restoran, ofis va yotoqxona derazalari uchun istalgan foto, logo yoki naqsh bosilgan maxsus UV-print foto jaluzilarimiz montaj ishlarini alohida to‘liq oynada ko‘ring.
                  </p>

                  <div className="flex flex-wrap items-center gap-3 pt-1">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setIsPrintGalleryOpen(true);
                      }}
                      className="px-5 py-3 rounded-2xl bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-400 hover:to-pink-400 text-white font-bold text-xs uppercase tracking-wider shadow-xl flex items-center gap-2 transition-all group-hover:scale-105 active:scale-95"
                    >
                      <span>Print jaluzi rasmlarini alohida oynada ochish ({PRINT_GALLERY_PROJECTS.length} ta rasm)</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                    <span className="text-xs text-brand-cream/75 font-medium">
                      Barcha montajlar fotosuratlari
                    </span>
                  </div>
                </div>

                {/* 2-photo preview collage */}
                <div className="grid grid-cols-2 gap-3 w-full sm:w-72 lg:w-80 flex-shrink-0">
                  <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/20 shadow-md">
                    <img
                      src={PRINT_GALLERY_PROJECTS[0]?.image}
                      alt="Print jaluzi montaj 1"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="aspect-[4/5] rounded-2xl overflow-hidden border border-white/20 shadow-md">
                    <img
                      src={PRINT_GALLERY_PROJECTS[1]?.image}
                      alt="Print jaluzi montaj 2"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* Modal Bottom Footer */}
          <div className="bg-brand-beige border-t border-brand-emerald/10 px-4 py-4 text-center">
            <button
              onClick={() => setIsPortfolioModalOpen(false)}
              className="px-6 py-2.5 bg-brand-emerald text-white rounded-xl text-xs font-bold shadow-md hover:bg-brand-emerald-dark transition-all"
            >
              Galereyani yopish
            </button>
          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* FAQAT JALUZILAR UCHUN O'XSHASH MODELLAR ALOHIDA OYNASI */}
      {/* ========================================================================= */}
      <SimilarJaluziModal
        isOpen={similarJaluziTarget !== null}
        targetProduct={similarJaluziTarget}
        allProducts={products}
        allProjects={projects}
        onClose={() => setSimilarJaluziTarget(null)}
        onOrderProduct={(prod) => {
          setSimilarJaluziTarget(null);
          setIsProductsModalOpen(false);
          onOrderProduct(prod);
        }}
        onViewProduct={(prod) => {
          setSimilarJaluziTarget(null);
          setIsProductsModalOpen(false);
          onViewProduct(prod);
        }}
      />

      {/* ========================================================================= */}
      {/* DIKEY PARDALAR REAL ISHLAR ALOHIDA OYNASI (33 TA RASM) */}
      {/* ========================================================================= */}
      <DikeyGalleryModal
        isOpen={isDikeyGalleryOpen}
        onClose={() => setIsDikeyGalleryOpen(false)}
        onOrderProject={(proj) => {
          setIsDikeyGalleryOpen(false);
          setIsPortfolioModalOpen(false);
          onOrderProject(proj);
        }}
      />

      {/* ========================================================================= */}
      {/* PLISSE JALUZILAR REAL ISHLAR ALOHIDA OYNASI (6 TA RASM) */}
      {/* ========================================================================= */}
      <PlisseGalleryModal
        isOpen={isPlisseGalleryOpen}
        onClose={() => setIsPlisseGalleryOpen(false)}
        onOrderProject={(proj) => {
          setIsPlisseGalleryOpen(false);
          setIsPortfolioModalOpen(false);
          onOrderProject(proj);
        }}
      />

      {/* ========================================================================= */}
      {/* COMBO (KUN-TUN) JALUZILAR REAL ISHLAR ALOHIDA OYNASI (49 TA RASM) */}
      {/* ========================================================================= */}
      <ComboGalleryModal
        isOpen={isComboGalleryOpen}
        onClose={() => setIsComboGalleryOpen(false)}
        onOrderProject={(proj) => {
          setIsComboGalleryOpen(false);
          setIsPortfolioModalOpen(false);
          onOrderProject(proj);
        }}
      />

      {/* ========================================================================= */}
      {/* ALYUMIN GORIZONTAL JALUZILAR REAL ISHLAR ALOHIDA OYNASI */}
      {/* ========================================================================= */}
      <AlyuminGalleryModal
        isOpen={isAlyuminGalleryOpen}
        onClose={() => setIsAlyuminGalleryOpen(false)}
        onOrderProject={(proj) => {
          setIsAlyuminGalleryOpen(false);
          setIsPortfolioModalOpen(false);
          onOrderProject(proj);
        }}
      />

      {/* ========================================================================= */}
      {/* WOOD (YOG'OCH) GORIZONTAL JALUZILAR REAL ISHLAR ALOHIDA OYNASI */}
      {/* ========================================================================= */}
      <WoodGalleryModal
        isOpen={isWoodGalleryOpen}
        onClose={() => setIsWoodGalleryOpen(false)}
        onOrderProject={(proj) => {
          setIsWoodGalleryOpen(false);
          setIsPortfolioModalOpen(false);
          onOrderProject(proj);
        }}
      />

      {/* ========================================================================= */}
      {/* ROLLO (RULONLI) PARDALAR REAL ISHLAR ALOHIDA OYNASI */}
      {/* ========================================================================= */}
      <RolloGalleryModal
        isOpen={isRolloGalleryOpen}
        onClose={() => setIsRolloGalleryOpen(false)}
        onOrderProject={(proj) => {
          setIsRolloGalleryOpen(false);
          setIsPortfolioModalOpen(false);
          onOrderProject(proj);
        }}
      />

      {/* ========================================================================= */}
      {/* PRINT (FOTO) JALUZILAR REAL ISHLAR ALOHIDA OYNASI */}
      {/* ========================================================================= */}
      <PrintGalleryModal
        isOpen={isPrintGalleryOpen}
        onClose={() => setIsPrintGalleryOpen(false)}
        onOrderProject={(proj) => {
          setIsPrintGalleryOpen(false);
          setIsPortfolioModalOpen(false);
          onOrderProject(proj);
        }}
      />
    </>
  );
}

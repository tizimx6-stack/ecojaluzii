import React, { useState, useEffect } from 'react';
import {
  CatalogFolderItem,
  ROLLO_CATALOG_ITEMS,
  DIKEY_CATALOG_ITEMS,
  COMBO_CATALOG_ITEMS,
} from '../data/catalogSpecialProducts';
import { Product } from '../types';
import {
  X,
  Search,
  ShoppingCart,
  Maximize2,
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  Sparkles,
  Phone,
  CheckCircle2,
  Layers,
} from 'lucide-react';

interface CatalogSpecialFolderModalProps {
  isOpen: boolean;
  categoryType: 'rollo' | 'dikey' | 'combo' | null;
  onClose: () => void;
  onOrderProduct: (product: Product) => void;
}

export default function CatalogSpecialFolderModal({
  isOpen,
  categoryType,
  onClose,
  onOrderProduct,
}: CatalogSpecialFolderModalProps) {
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [zoomLevel, setZoomLevel] = useState(1);

  // Lock body scroll
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // Reset zoom on index change
  useEffect(() => {
    setZoomLevel(1);
  }, [lightboxIndex]);

  // Pick dataset
  const items: CatalogFolderItem[] =
    categoryType === 'rollo'
      ? ROLLO_CATALOG_ITEMS
      : categoryType === 'dikey'
      ? DIKEY_CATALOG_ITEMS
      : categoryType === 'combo'
      ? COMBO_CATALOG_ITEMS
      : [];

  const meta = {
    rollo: {
      title: 'Rollo (Rulonli) Jaluzi Katalogi',
      subtitle: 'Blackout, Dimout va Screen matoli to‘liq katalog namunalari',
      badge: '📜 MAHSULOTLAR KATALOGI: ROLLO',
      icon: '📜',
      countLabel: `${ROLLO_CATALOG_ITEMS.length} ta Katalog Modeli`,
    },
    dikey: {
      title: 'Dikey (Vertikal) Jaluzi va Parda Katalogi',
      subtitle: '180° buriluvchi nafis tyul va saroyona matoli katalog namunalari',
      badge: '🏛️ MAHSULOTLAR KATALOGI: DIKEY',
      icon: '🏛️',
      countLabel: `${DIKEY_CATALOG_ITEMS.length} ta Katalog Modeli`,
    },
    combo: {
      title: 'Combo (Kun-Tun / Zebra) Jaluzi Katalogi',
      subtitle: '2 qavatli almashinuvchi matoli zamonaviy kun-tun katalog namunalari',
      badge: '☀️ MAHSULOTLAR KATALOGI: COMBO',
      icon: '☀️',
      countLabel: `${COMBO_CATALOG_ITEMS.length} ta Katalog Modeli`,
    },
  }[categoryType || 'rollo'];

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (lightboxIndex === null) return;
      if (e.key === 'Escape') setLightboxIndex(null);
      if (e.key === 'ArrowLeft') {
        setLightboxIndex((prev) => (prev !== null && prev > 0 ? prev - 1 : items.length - 1));
      }
      if (e.key === 'ArrowRight') {
        setLightboxIndex((prev) => (prev !== null && prev < items.length - 1 ? prev + 1 : 0));
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lightboxIndex, items.length]);

  if (!isOpen || !categoryType) return null;

  const filteredItems = items.filter((item) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      item.name.toLowerCase().includes(q) ||
      item.description.toLowerCase().includes(q) ||
      (item.material && item.material.toLowerCase().includes(q))
    );
  });

  const handleOrder = (item: CatalogFolderItem) => {
    const asProduct: Product = {
      id: item.id,
      name: item.name,
      category: item.category,
      description: item.description,
      material: item.material || 'Premium sifatli to‘qima',
      availableColors: ['Klassik bej', 'Oq', 'Krem', 'Kulrang'],
      pricePerSqm: item.pricePerSqm || 165000,
      image: item.image,
      benefits: ['100% sifat kafolati', 'Bepul o‘lchash va maslahat', 'Tezkor tayyorlash'],
      installationInfo: 'Oyna romiga yoki devorga professional montaj qilinadi.',
    };
    onClose();
    onOrderProduct(asProduct);
  };

  return (
    <div className="fixed inset-0 z-50 bg-brand-cream overflow-y-auto animate-fadeIn flex flex-col">
      {/* Top Header */}
      <div className="sticky top-0 z-40 bg-brand-cream/95 backdrop-blur-md border-b border-brand-emerald/10 px-4 sm:px-8 py-3.5 shadow-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-brand-emerald text-white flex items-center justify-center shadow-md text-xl flex-shrink-0">
              <span>{meta.icon}</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-md bg-amber-400 text-brand-emerald-dark text-[10px] font-extrabold uppercase tracking-wider">
                  {meta.badge}
                </span>
                <span className="text-xs text-brand-emerald font-bold hidden sm:inline-block">
                  • {meta.countLabel}
                </span>
              </div>
              <h2 className="font-serif text-base sm:text-xl font-bold text-brand-emerald-dark leading-tight line-clamp-1">
                {meta.title}
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="px-3.5 py-2 rounded-xl bg-brand-beige hover:bg-brand-emerald hover:text-white text-brand-emerald-dark border border-brand-emerald/15 text-xs font-bold transition-all flex items-center gap-1.5 shadow-2xs hover:scale-105"
          >
            <span>Katalogga qaytish</span>
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Body */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-12 py-6 flex-grow w-full space-y-6">
        {/* Info Banner */}
        <div className="bg-gradient-to-r from-brand-emerald/10 via-brand-beige to-amber-500/10 rounded-2xl p-4 sm:p-5 border border-brand-emerald/15 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-bold text-brand-emerald">
              <Sparkles className="w-3.5 h-3.5" />
              <span>MAHSULOTLAR KATALOGIDAGI EKSKLYUZIV NAMUNALAR</span>
            </div>
            <p className="text-xs sm:text-sm text-brand-charcoal/80 font-light max-w-2xl">
              {meta.subtitle}. Istalgan modelni tanlab kattalashtirib ko‘ring yoki to‘g‘ridan-to‘g‘ri o‘lcham olishga bepul buyurtma bering.
            </p>
          </div>

          <div className="relative w-full sm:w-72 flex-shrink-0">
            <Search className="w-4 h-4 text-brand-charcoal/40 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Namunani qidirish..."
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-white border border-brand-emerald/15 text-xs text-brand-charcoal outline-none focus:border-brand-emerald focus:ring-2 focus:ring-brand-emerald/20 transition-all placeholder:text-brand-charcoal/40 shadow-2xs"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-brand-charcoal/40 hover:text-brand-charcoal text-xs"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Catalog Items Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {filteredItems.map((item, idx) => (
            <div
              key={item.id}
              className="group bg-white rounded-2xl overflow-hidden border border-brand-emerald/10 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col hover:-translate-y-1"
            >
              {/* Photo Box */}
              <div
                onClick={() => setLightboxIndex(idx)}
                className="relative aspect-[4/5] bg-brand-beige overflow-hidden cursor-pointer"
              >
                <img
                  src={item.image}
                  alt={item.name}
                  referrerPolicy="no-referrer"
                  loading="lazy"
                  className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <span className="px-3 py-1.5 rounded-full bg-white/90 text-brand-emerald-dark text-xs font-bold flex items-center gap-1.5 shadow-lg">
                    <Maximize2 className="w-3.5 h-3.5" />
                    <span>Kattalashtirish</span>
                  </span>
                </div>
                <div className="absolute top-2.5 left-2.5">
                  <span className="px-2 py-0.5 rounded-md bg-brand-emerald-dark/80 backdrop-blur-md text-white text-[10px] font-bold shadow">
                    №{idx + 1}
                  </span>
                </div>
              </div>

              {/* Text & Order Box */}
              <div className="p-4 flex flex-col flex-1 justify-between gap-3">
                <div className="space-y-1.5">
                  <h3 className="font-serif text-sm font-bold text-brand-emerald-dark line-clamp-2 leading-snug group-hover:text-brand-emerald transition-colors">
                    {item.name}
                  </h3>
                  <p className="text-[11px] text-brand-charcoal/65 line-clamp-2 leading-relaxed">
                    {item.description}
                  </p>
                  {item.material && (
                    <div className="pt-1 flex items-center gap-1.5 text-[10px] font-medium text-brand-emerald/90">
                      <Layers className="w-3 h-3 flex-shrink-0" />
                      <span className="line-clamp-1">{item.material}</span>
                    </div>
                  )}
                </div>

                <div className="pt-2 border-t border-brand-emerald/10 flex items-center gap-2">
                  <button
                    onClick={() => setLightboxIndex(idx)}
                    className="p-2 rounded-xl bg-brand-beige hover:bg-brand-emerald/10 text-brand-emerald-dark border border-brand-emerald/15 transition-all"
                    title="Kattalashtirish"
                  >
                    <Maximize2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleOrder(item)}
                    className="flex-1 py-2 px-3 rounded-xl bg-brand-emerald hover:bg-brand-emerald-dark text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-sm active:scale-95"
                  >
                    <ShoppingCart className="w-3.5 h-3.5 text-amber-300" />
                    <span>O‘lcham olishga buyurtma</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      {lightboxIndex !== null && filteredItems[lightboxIndex] && (
        <div className="fixed inset-0 z-60 bg-black/95 backdrop-blur-md flex flex-col justify-between p-4 sm:p-6 animate-fadeIn">
          {/* Top Bar */}
          <div className="flex items-center justify-between gap-4 text-white z-10">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-amber-400 text-brand-emerald-dark font-extrabold text-xs">
                {lightboxIndex + 1} / {filteredItems.length}
              </span>
              <span className="font-serif text-sm sm:text-base font-bold line-clamp-1 text-white/90">
                {filteredItems[lightboxIndex].name}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setZoomLevel((z) => Math.min(z + 0.5, 3))}
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all"
                title="Kattalashtirish (+)"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                onClick={() => setZoomLevel((z) => Math.max(z - 0.5, 1))}
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all"
                title="Kichiklashtirish (-)"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <button
                onClick={() => setLightboxIndex(null)}
                className="p-2 rounded-xl bg-white/20 hover:bg-red-500 text-white transition-all ml-2"
                title="Yopish (Esc)"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Photo Center */}
          <div className="relative flex-1 flex items-center justify-center overflow-hidden my-4">
            <button
              onClick={() =>
                setLightboxIndex((prev) =>
                  prev !== null && prev > 0 ? prev - 1 : filteredItems.length - 1
                )
              }
              className="absolute left-2 sm:left-4 z-20 p-3 rounded-full bg-black/50 hover:bg-black/80 text-white transition-all border border-white/20"
              title="Oldingi"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            <img
              src={filteredItems[lightboxIndex].image}
              alt={filteredItems[lightboxIndex].name}
              referrerPolicy="no-referrer"
              style={{ transform: `scale(${zoomLevel})` }}
              className="max-h-[75vh] max-w-[90vw] object-contain transition-transform duration-200 select-none shadow-2xl rounded-lg"
            />

            <button
              onClick={() =>
                setLightboxIndex((prev) =>
                  prev !== null && prev < filteredItems.length - 1 ? prev + 1 : 0
                )
              }
              className="absolute right-2 sm:right-4 z-20 p-3 rounded-full bg-black/50 hover:bg-black/80 text-white transition-all border border-white/20"
              title="Keyingi"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>

          {/* Bottom Action Bar */}
          <div className="max-w-2xl mx-auto w-full bg-white/10 backdrop-blur-md rounded-2xl p-4 text-white flex flex-col sm:flex-row items-center justify-between gap-3 z-10 border border-white/15">
            <div className="text-center sm:text-left">
              <p className="text-xs font-light text-white/80 line-clamp-1">
                {filteredItems[lightboxIndex].description}
              </p>
            </div>
            <button
              onClick={() => handleOrder(filteredItems[lightboxIndex])}
              className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-brand-emerald-dark text-xs font-extrabold uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-all"
            >
              <ShoppingCart className="w-4 h-4" />
              <span>O‘lcham olishga bepul chaqirish</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

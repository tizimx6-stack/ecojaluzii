import React, { useState, useRef, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize2, 
  X, 
  Star, 
  CheckCircle2, 
  Sparkles, 
  Quote, 
  MessageSquareHeart, 
  ArrowRight,
  ShieldCheck,
  RotateCcw
} from 'lucide-react';

export interface VideoReviewItem {
  id: string;
  productType: string;
  rating: number;
  reviewText: string;
  posterUrl: string;
  fallbackPosterUrl: string;
  videoUrl: string;
  fallbackVideoUrl: string;
  originalLink: string;
}

interface CustomerVideoReviewsProps {
  onOrderClick?: (productNote?: string) => void;
}

const VIDEO_REVIEWS: VideoReviewItem[] = [
  {
    id: 'review-1',
    productType: 'Combo (Zebra) Jaluzi',
    rating: 5,
    reviewText: "Yotoqxonamiz uchun Combo Zebra jaluzilariga buyurtma bergan edik. Sifati a'lo darajada, o'lchovga kelib 2 kunda o'rnatib berishdi. Qorong'ulatishi va yorug'likni nazorat qilish juda qulay!",
    posterUrl: 'https://cdn.imgpile.com/f/RIIK02j_thumb.jpg',
    fallbackPosterUrl: 'https://imgpile.com/images/kv0PDzy.jpg',
    videoUrl: 'https://cdn.imgpile.com/f/RIIK02j.mp4',
    fallbackVideoUrl: 'https://cdn.imgpile.com/f/RIIK02j_lg.mp4',
    originalLink: 'https://imgpile.com/m/kv0PDzy'
  },
  {
    id: 'review-2',
    productType: 'Plisse Jaluzi',
    rating: 5,
    reviewText: "Plisse jaluzilari deraza ramkasiga juda chiroyli va qulay o‘rnatildi. Ham yuqoridan, ham pastdan ochilib-yopilishi juda qulay. Matosi chang yutmaydi va tozalash oson!",
    posterUrl: 'https://cdn.imgpile.com/f/3gLmQo5_thumb.jpg',
    fallbackPosterUrl: 'https://imgpile.com/images/0edeLhY.jpg',
    videoUrl: 'https://cdn.imgpile.com/f/3gLmQo5.mp4',
    fallbackVideoUrl: 'https://cdn.imgpile.com/f/3gLmQo5_lg.mp4',
    originalLink: 'https://imgpile.com/m/0edeLhY'
  },
  {
    id: 'review-3',
    productType: 'Rollo Jaluzi',
    rating: 5,
    reviewText: "Rollo jaluzilari xonadonga juda chiroyli yarashdi. Quyosh nurlaridan mukammal himoya qiladi va yorug'likni yaxshi to'sadi. Usta juda ozoda o'rnatib berdi!",
    posterUrl: 'https://cdn.imgpile.com/f/YMMydat_thumb.jpg',
    fallbackPosterUrl: 'https://imgpile.com/images/pCSmgOS.jpg',
    videoUrl: 'https://cdn.imgpile.com/f/YMMydat.mp4',
    fallbackVideoUrl: 'https://cdn.imgpile.com/f/YMMydat_lg.mp4',
    originalLink: 'https://imgpile.com/m/pCSmgOS'
  }
];

export default function CustomerVideoReviews({ onOrderClick }: CustomerVideoReviewsProps) {
  // Active playing video ID on main grid
  const [activePlayingId, setActivePlayingId] = useState<string | null>(null);
  const [mutedStates, setMutedStates] = useState<Record<string, boolean>>({
    'review-1': true,
    'review-2': true,
    'review-3': true
  });
  
  // Fullscreen theater modal state
  const [modalVideo, setModalVideo] = useState<VideoReviewItem | null>(null);
  const [isModalPlaying, setIsModalPlaying] = useState<boolean>(true);
  const [isModalMuted, setIsModalMuted] = useState<boolean>(false);
  const [modalCurrentTime, setModalCurrentTime] = useState<number>(0);
  const [modalDuration, setModalDuration] = useState<number>(0);

  const videoRefs = useRef<Record<string, HTMLVideoElement | null>>({});
  const modalVideoRef = useRef<HTMLVideoElement | null>(null);

  // Stop inline videos when modal opens
  useEffect(() => {
    if (modalVideo) {
      Object.values(videoRefs.current).forEach(video => {
        if (video) video.pause();
      });
      setActivePlayingId(null);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [modalVideo]);

  const handleTogglePlayInline = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const currentVideo = videoRefs.current[id];
    if (!currentVideo) return;

    if (activePlayingId === id) {
      currentVideo.pause();
      setActivePlayingId(null);
    } else {
      // Pause all other videos
      Object.entries(videoRefs.current).forEach(([otherId, otherVideo]) => {
        if (otherVideo && otherId !== id) {
          otherVideo.pause();
        }
      });
      currentVideo.play().then(() => {
        setActivePlayingId(id);
      }).catch(err => {
        console.log('Playback error:', err);
      });
    }
  };

  const handleToggleMuteInline = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const currentVideo = videoRefs.current[id];
    if (!currentVideo) return;
    const isCurrentlyMuted = mutedStates[id] ?? true;
    currentVideo.muted = !isCurrentlyMuted;
    setMutedStates(prev => ({ ...prev, [id]: !isCurrentlyMuted }));
  };

  const handleOpenModal = (review: VideoReviewItem) => {
    setModalVideo(review);
    setIsModalPlaying(true);
    setIsModalMuted(false);
  };

  const handleCloseModal = () => {
    if (modalVideoRef.current) {
      modalVideoRef.current.pause();
    }
    setModalVideo(null);
  };

  const handleModalTogglePlay = () => {
    if (!modalVideoRef.current) return;
    if (isModalPlaying) {
      modalVideoRef.current.pause();
      setIsModalPlaying(false);
    } else {
      modalVideoRef.current.play().then(() => {
        setIsModalPlaying(true);
      }).catch(() => {});
    }
  };

  const handleModalSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!modalVideoRef.current || !modalDuration) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const ratio = Math.max(0, Math.min(1, clickX / rect.width));
    const newTime = ratio * modalDuration;
    modalVideoRef.current.currentTime = newTime;
    setModalCurrentTime(newTime);
  };

  const handleOrder = (productType?: string) => {
    if (modalVideo) {
      handleCloseModal();
    }
    const note = productType 
      ? `Mijoz videoroligidagi [${productType}] modelidan buyurtma bermoqchiman.`
      : "Mijozlar video sharhidagi jaluzilardan buyurtma bermoqchiman.";
    if (onOrderClick) {
      onOrderClick(note);
    } else {
      const formSection = document.querySelector('#order-form');
      if (formSection) {
        formSection.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  const formatTime = (seconds: number) => {
    if (isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <section id="customer-reviews" className="py-20 sm:py-28 bg-brand-cream border-b border-brand-emerald/10 relative overflow-hidden">
      {/* Decorative ambient background accents */}
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[800px] h-[350px] bg-brand-emerald/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-10 right-10 w-80 h-80 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 sm:mb-18 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-brand-emerald/10 border border-brand-emerald/20 text-brand-emerald-dark text-xs sm:text-sm font-semibold shadow-sm">
            <MessageSquareHeart className="w-4 h-4 text-brand-emerald" />
            <span>Xaridorlarimiz Fikrlari & Otzivlar</span>
          </div>

          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-brand-emerald-dark tracking-tight leading-tight">
            Mijozlarimizdan <span className="text-brand-emerald italic">Haqiqiy Video</span> Sharhlar
          </h2>

          <p className="text-brand-charcoal/70 text-sm sm:text-base lg:text-lg font-light max-w-2xl mx-auto leading-relaxed">
            ECO JALUZI mahsulotlarini xarid qilgan va xonadoniga o‘rnatgan mijozlarimizning samimiy taassurotlari va video sharhlarini tomosha qiling.
          </p>
        </div>

        {/* 3 Side-by-Side Video Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 items-stretch">
          {VIDEO_REVIEWS.map((review, index) => {
            const isPlaying = activePlayingId === review.id;
            const isMuted = mutedStates[review.id] ?? true;

            return (
              <div
                key={review.id}
                id={`customer-video-card-${index + 1}`}
                className="group relative bg-white rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl border border-brand-emerald/10 transition-all duration-300 flex flex-col hover:-translate-y-1.5"
              >
                {/* Vertical Video / Reel Container */}
                <div 
                  className="relative aspect-[9/14] sm:aspect-[9/13] w-full bg-brand-charcoal overflow-hidden cursor-pointer"
                  onClick={() => handleTogglePlayInline(review.id)}
                >
                  {/* Video Player */}
                  <video
                    ref={el => { videoRefs.current[review.id] = el; }}
                    poster={review.posterUrl}
                    playsInline
                    loop
                    muted={isMuted}
                    preload="metadata"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    onEnded={() => setActivePlayingId(null)}
                    onError={(e) => {
                      const target = e.currentTarget;
                      if (!target.dataset.failed && review.fallbackVideoUrl) {
                        target.dataset.failed = '1';
                        target.src = review.fallbackVideoUrl;
                        target.load();
                      }
                    }}
                  >
                    <source src={review.videoUrl} type="video/mp4" />
                    {review.fallbackVideoUrl && <source src={review.fallbackVideoUrl} type="video/mp4" />}
                  </video>

                  {/* Dark gradient overlays for readability & luxury feel */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-black/40 pointer-events-none" />

                  {/* Top Bar: Badge and Fullscreen Expand button */}
                  <div className="absolute top-3.5 left-3.5 right-3.5 flex items-center justify-between z-20 pointer-events-auto">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/60 backdrop-blur-md text-[11px] font-semibold text-white border border-white/15 shadow-md">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>{review.productType}</span>
                    </span>

                    <button
                      type="button"
                      id={`btn-fullscreen-${review.id}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleOpenModal(review);
                      }}
                      className="w-9 h-9 rounded-full bg-black/60 hover:bg-brand-emerald text-white backdrop-blur-md flex items-center justify-center border border-white/20 transition-all hover:scale-110 shadow-md active:scale-95"
                      title="Katta ekranda bemalol ko‘rish"
                    >
                      <Maximize2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Center Big Play / Pause Button with Ripple Effect */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    {!isPlaying ? (
                      <div className="relative pointer-events-auto">
                        <div className="w-16 h-16 sm:w-18 sm:h-18 rounded-full bg-white/90 text-brand-emerald-dark flex items-center justify-center shadow-2xl backdrop-blur-md border border-white transition-all transform group-hover:scale-110 group-hover:bg-brand-emerald group-hover:text-white">
                          <Play className="w-7 h-7 fill-current translate-x-0.5" />
                        </div>
                        <span className="absolute -inset-2 rounded-full bg-white/30 animate-ping pointer-events-none" />
                      </div>
                    ) : (
                      <div className="opacity-0 group-hover:opacity-100 transition-opacity pointer-events-auto">
                        <div className="w-14 h-14 rounded-full bg-black/60 text-white backdrop-blur-md flex items-center justify-center border border-white/20">
                          <Pause className="w-6 h-6 fill-current" />
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Inline Bottom Floating Controls (Volume, Fullscreen watch prompt) */}
                  <div className="absolute bottom-3.5 left-3.5 right-3.5 flex items-center justify-between z-20 pointer-events-auto">
                    <button
                      type="button"
                      id={`btn-mute-${review.id}`}
                      onClick={(e) => handleToggleMuteInline(review.id, e)}
                      className="w-8 h-8 rounded-full bg-black/60 hover:bg-black/80 text-white backdrop-blur-md flex items-center justify-center border border-white/20 transition-all"
                      title={isMuted ? "Ovozni yoqish" : "Ovozni o‘chirish"}
                    >
                      {isMuted ? <VolumeX className="w-4 h-4 text-amber-300" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
                    </button>

                    <button
                      type="button"
                      id={`btn-theater-${review.id}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleOpenModal(review);
                      }}
                      className="px-3 py-1 rounded-full bg-white/90 hover:bg-white text-brand-emerald-dark text-xs font-bold shadow-lg backdrop-blur-md transition-all hover:scale-105 active:scale-95 flex items-center gap-1"
                    >
                      <span>To‘liq ko‘rish</span>
                      <Maximize2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                {/* Review Text and Customer Info Card Footer */}
                <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between bg-white space-y-4">
                  {/* Rating Stars & Verified badge */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1 text-amber-400">
                      {[...Array(review.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-current text-amber-400" />
                      ))}
                      <span className="text-xs font-bold text-brand-charcoal/80 ml-1">5.0</span>
                    </div>
                    <span className="text-[11px] font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-emerald-600" />
                      <span>Tasdiqlangan</span>
                    </span>
                  </div>

                  {/* Customer Quote */}
                  <div className="relative">
                    <Quote className="w-6 h-6 text-brand-emerald/15 absolute -top-2 -left-1 pointer-events-none" />
                    <p className="text-xs sm:text-sm text-brand-charcoal/80 font-normal leading-relaxed pl-4 italic">
                      "{review.reviewText}"
                    </p>
                  </div>

                  {/* Product Type & Order Button */}
                  <div className="pt-3 border-t border-brand-emerald/10 flex items-center justify-between">
                    <div>
                      <h4 className="font-serif font-bold text-sm sm:text-base text-brand-emerald-dark">
                        {review.productType}
                      </h4>
                      <p className="text-[11px] text-brand-emerald font-medium flex items-center gap-1 mt-0.5">
                        <CheckCircle2 className="w-3 h-3 text-brand-emerald" />
                        <span>Real o‘rnatilgan obyekt</span>
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleOrder(review.productType)}
                      className="p-2 rounded-xl bg-brand-emerald/10 hover:bg-brand-emerald text-brand-emerald-dark hover:text-white transition-all shadow-sm active:scale-95 group/btn"
                      title="Shu modeldan buyurtma qilish"
                    >
                      <ArrowRight className="w-4 h-4 transition-transform group-hover/btn:translate-x-0.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom CTA bar */}
        <div className="mt-12 sm:mt-16 text-center">
          <div className="inline-flex flex-col sm:flex-row items-center gap-4 p-4 sm:p-6 bg-white rounded-3xl shadow-lg border border-brand-emerald/10 max-w-2xl mx-auto">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-400/20 text-amber-600 flex items-center justify-center shrink-0">
                <Sparkles className="w-5 h-5" />
              </div>
              <div className="text-left">
                <h4 className="font-serif font-bold text-sm text-brand-emerald-dark">Sizga ham xuddi shunday sifatli jaluzi kerakmi?</h4>
                <p className="text-xs text-brand-charcoal/60">Mutaxassisimiz barcha mato namunalari bilan xonadoningizga boradi.</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => handleOrder("Video sharhdagi jaluzilar")}
              className="w-full sm:w-auto px-5 py-2.5 rounded-2xl bg-gradient-to-r from-brand-emerald-dark to-brand-emerald hover:from-brand-emerald hover:to-brand-emerald-dark text-white font-bold text-xs uppercase tracking-wider shadow-md hover:shadow-xl transition-all whitespace-nowrap active:scale-95"
            >
              O‘lchov buyurtma qilish
            </button>
          </div>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* FULL-SCREEN THEATER VIDEO MODAL ("vidoni bemalol ko'rsa bo'ladigan")     */}
      {/* ========================================================================= */}
      {modalVideo && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-xl animate-fadeIn"
          onClick={handleCloseModal}
        >
          <div 
            className="relative w-full max-w-4xl bg-brand-charcoal rounded-3xl overflow-hidden shadow-2xl border border-white/20 flex flex-col md:flex-row max-h-[92vh]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              type="button"
              id="btn-close-video-modal"
              onClick={handleCloseModal}
              className="absolute top-4 right-4 z-40 w-10 h-10 rounded-full bg-black/70 hover:bg-brand-emerald text-white flex items-center justify-center backdrop-blur-md border border-white/20 transition-all hover:scale-110 active:scale-95 cursor-pointer shadow-lg"
              title="Yopish (Esc)"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Left/Main Side: Big Video Player with Custom Controls */}
            <div className="relative flex-1 bg-black flex items-center justify-center min-h-[300px] md:min-h-[500px]">
              <video
                ref={modalVideoRef}
                poster={modalVideo.posterUrl}
                playsInline
                autoPlay
                muted={isModalMuted}
                className="w-full h-full max-h-[75vh] object-contain cursor-pointer"
                onClick={handleModalTogglePlay}
                onError={(e) => {
                  const target = e.currentTarget;
                  if (!target.dataset.failed && modalVideo.fallbackVideoUrl) {
                    target.dataset.failed = '1';
                    target.src = modalVideo.fallbackVideoUrl;
                    target.load();
                    target.play().catch(() => {});
                  }
                }}
                onTimeUpdate={() => {
                  if (modalVideoRef.current) {
                    setModalCurrentTime(modalVideoRef.current.currentTime);
                  }
                }}
                onLoadedMetadata={() => {
                  if (modalVideoRef.current) {
                    setModalDuration(modalVideoRef.current.duration);
                  }
                }}
                onEnded={() => setIsModalPlaying(false)}
              >
                <source src={modalVideo.videoUrl} type="video/mp4" />
                {modalVideo.fallbackVideoUrl && <source src={modalVideo.fallbackVideoUrl} type="video/mp4" />}
              </video>

              {/* Big Center Play/Pause button on modal video */}
              {!isModalPlaying && (
                <div 
                  className="absolute inset-0 flex items-center justify-center bg-black/40 cursor-pointer"
                  onClick={handleModalTogglePlay}
                >
                  <div className="w-20 h-20 rounded-full bg-brand-emerald text-white flex items-center justify-center shadow-2xl transform hover:scale-110 transition-transform">
                    <Play className="w-8 h-8 fill-current translate-x-0.5" />
                  </div>
                </div>
              )}

              {/* Modal Video Bottom Controls Bar */}
              <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/95 via-black/70 to-transparent flex flex-col gap-2">
                {/* Progress Bar (Seekable) */}
                <div 
                  className="w-full h-2 bg-white/25 hover:h-3 rounded-full cursor-pointer relative transition-all group/seek"
                  onClick={handleModalSeek}
                >
                  <div 
                    className="h-full bg-gradient-to-r from-amber-400 to-emerald-400 rounded-full relative"
                    style={{ width: `${modalDuration ? (modalCurrentTime / modalDuration) * 100 : 0}%` }}
                  >
                    <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3.5 h-3.5 bg-white rounded-full shadow opacity-0 group-hover/seek:opacity-100 transition-opacity" />
                  </div>
                </div>

                {/* Controls Buttons */}
                <div className="flex items-center justify-between text-white text-xs pt-1">
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={handleModalTogglePlay}
                      className="p-1.5 hover:text-emerald-400 transition-colors"
                      title={isModalPlaying ? "Pauza" : "Ijro"}
                    >
                      {isModalPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current" />}
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        if (modalVideoRef.current) {
                          modalVideoRef.current.currentTime = 0;
                          modalVideoRef.current.play();
                          setIsModalPlaying(true);
                        }
                      }}
                      className="p-1.5 hover:text-amber-400 transition-colors"
                      title="Boshidan qaytarish"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        if (modalVideoRef.current) {
                          const nextMute = !isModalMuted;
                          modalVideoRef.current.muted = nextMute;
                          setIsModalMuted(nextMute);
                        }
                      }}
                      className="p-1.5 hover:text-emerald-400 transition-colors flex items-center gap-1"
                      title={isModalMuted ? "Ovozni yoqish" : "Ovozni o‘chirish"}
                    >
                      {isModalMuted ? <VolumeX className="w-5 h-5 text-amber-400" /> : <Volume2 className="w-5 h-5 text-emerald-400" />}
                    </button>

                    <span className="text-[11px] text-white/80 font-mono">
                      {formatTime(modalCurrentTime)} / {formatTime(modalDuration || 32)}
                    </span>
                  </div>

                  <span className="text-[11px] font-medium text-emerald-300 bg-emerald-950/60 border border-emerald-500/30 px-3 py-1 rounded-full">
                    {modalVideo.productType}
                  </span>
                </div>
              </div>
            </div>

            {/* Right Side: Customer Review & Fast Order Box */}
            <div className="w-full md:w-80 lg:w-96 bg-brand-cream p-6 sm:p-8 flex flex-col justify-between overflow-y-auto space-y-6">
              <div className="space-y-4">
                {/* Rating & Verified Tag */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-amber-500">
                    {[...Array(modalVideo.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                    <span className="text-xs font-bold text-brand-charcoal ml-1">5.0</span>
                  </div>
                  <span className="text-xs font-semibold text-emerald-800 bg-emerald-100 border border-emerald-300 px-3 py-0.5 rounded-full flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Tasdiqlangan</span>
                  </span>
                </div>

                {/* Product / Review Info */}
                <div>
                  <h3 className="font-serif text-xl font-bold text-brand-emerald-dark">
                    {modalVideo.productType}
                  </h3>
                  <p className="text-xs text-brand-emerald font-medium mt-1 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-brand-emerald" />
                    <span>Real mijoz video sharhi</span>
                  </p>
                </div>

                {/* Full Quote */}
                <div className="p-4 rounded-2xl bg-white border border-brand-emerald/10 shadow-sm relative">
                  <Quote className="w-8 h-8 text-brand-emerald/10 absolute top-2 right-2 pointer-events-none" />
                  <p className="text-xs sm:text-sm text-brand-charcoal/80 font-normal leading-relaxed italic">
                    "{modalVideo.reviewText}"
                  </p>
                </div>

                {/* Key Benefits */}
                <div className="space-y-2 text-xs text-brand-charcoal/70 pt-2">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-brand-emerald shrink-0" />
                    <span>1 yil rasmiy kafolat bilan o‘rnatilgan</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-brand-emerald shrink-0" />
                    <span>Chang o‘tkazmaydigan ekologik mato</span>
                  </div>
                </div>
              </div>

              {/* Order Button inside Modal */}
              <div className="pt-4 border-t border-brand-emerald/10 space-y-3">
                <button
                  type="button"
                  id="btn-order-modal-review"
                  onClick={() => handleOrder(modalVideo.productType)}
                  className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-brand-emerald-dark to-brand-emerald hover:from-brand-emerald hover:to-brand-emerald-dark text-white font-bold text-xs uppercase tracking-wider shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 active:scale-95 cursor-pointer"
                >
                  <span>Shu modeldan buyurtma berish</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <p className="text-[11px] text-center text-brand-charcoal/50">
                  O‘lchov va katalog bilan borish xizmati mavjud
                </p>
              </div>
            </div>

          </div>
        </div>
      )}

    </section>
  );
}

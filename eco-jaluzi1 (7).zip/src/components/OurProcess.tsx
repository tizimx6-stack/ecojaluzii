import React, { useState, useEffect } from 'react';
import { HelpCircle, PhoneCall, Ruler, Palette, Cpu, CheckCircle, Play } from 'lucide-react';
import { dbService } from '../services/db';
import { ProcessStep } from '../types';

export default function OurProcess() {
  const [steps, setSteps] = useState<ProcessStep[]>([]);
  const [activeVideoModal, setActiveVideoModal] = useState<string | null>(null);

  const loadSteps = () => {
    setSteps(dbService.getProcessSteps());
  };

  useEffect(() => {
    loadSteps();
    const handleUpdate = () => loadSteps();
    window.addEventListener('cms_update', handleUpdate);
    return () => window.removeEventListener('cms_update', handleUpdate);
  }, []);

  const getStepIcon = (index: number) => {
    switch (index % 5) {
      case 0: return <PhoneCall className="w-5 h-5" />;
      case 1: return <Ruler className="w-5 h-5" />;
      case 2: return <Palette className="w-5 h-5" />;
      case 3: return <Cpu className="w-5 h-5" />;
      default: return <CheckCircle className="w-5 h-5" />;
    }
  };

  return (
    <section id="process" className="py-24 bg-brand-beige/20 border-b border-brand-emerald/5">
      <div className="max-w-7xl mx-auto px-6 sm:px-12">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-20 flex flex-col items-center gap-4">
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-brand-emerald/5 text-brand-emerald text-xs font-semibold uppercase tracking-wider">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Xizmat ko‘rsatish tartibi</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-brand-emerald-dark">
            Hammasi juda oson va tezkor.
          </h2>
          <div className="h-1 w-12 bg-brand-emerald-light rounded" />
          <p className="text-brand-charcoal/60 font-light max-w-xl text-sm leading-relaxed">
            Biz buyurtmani qabul qilishdan tortib to montajigacha bo‘lgan barcha ishlarni eng yuqori darajada amalga oshiramiz.
          </p>
        </div>

        {/* Steps container */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 relative z-10">
          {steps.map((step, index) => (
            <div key={step.id || index} className="flex flex-col bg-brand-cream rounded-2xl border border-brand-emerald/15 p-5 shadow-sm hover:shadow-md transition-all group">
              
              {/* Top media / icon preview if present */}
              {(step.image || step.videoUrl) && (
                <div className="relative w-full h-36 rounded-xl overflow-hidden mb-4 bg-brand-charcoal/10">
                  {step.mediaType === 'video' && step.videoUrl ? (
                    <div 
                      onClick={() => setActiveVideoModal(step.videoUrl || null)}
                      className="w-full h-full cursor-pointer relative group/vid"
                    >
                      <video 
                        src={step.videoUrl} 
                        poster={step.image}
                        className="w-full h-full object-cover"
                        muted 
                        playsInline
                      />
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center group-hover/vid:bg-black/40 transition-all">
                        <div className="w-10 h-10 rounded-full bg-brand-emerald text-white flex items-center justify-center shadow-lg">
                          <Play className="w-4 h-4 fill-current ml-0.5" />
                        </div>
                      </div>
                    </div>
                  ) : (
                    <img 
                      src={step.image || 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=600'} 
                      alt={step.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  )}
                  <span className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded-full bg-brand-emerald-dark text-white text-[10px] font-bold shadow">
                    {step.stepNumber || `0${index + 1}`}
                  </span>
                </div>
              )}

              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-brand-emerald/10 text-brand-emerald flex items-center justify-center font-bold">
                  {getStepIcon(index)}
                </div>
                {!step.image && !step.videoUrl && (
                  <span className="px-2 py-0.5 rounded-full bg-amber-500 text-brand-cream text-[10px] font-bold">
                    {step.stepNumber || `0${index + 1}`}
                  </span>
                )}
              </div>

              {/* Text explanation */}
              <div className="space-y-2 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-serif text-base font-bold text-brand-emerald-dark mb-1">
                    {step.title}
                  </h3>
                  <p className="text-brand-charcoal/70 text-xs font-light leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>

            </div>
          ))}
        </div>

      </div>

      {/* Video Modal Preview if clicked */}
      {activeVideoModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="relative w-full max-w-3xl bg-black rounded-2xl overflow-hidden shadow-2xl border border-white/20">
            <button 
              type="button"
              onClick={() => setActiveVideoModal(null)}
              className="absolute top-4 right-4 z-10 p-2 rounded-full bg-white/20 hover:bg-white/40 text-white transition-all"
            >
              ✕
            </button>
            <video 
              src={activeVideoModal} 
              controls 
              autoPlay 
              className="w-full max-h-[80vh] object-contain"
            />
          </div>
        </div>
      )}
    </section>
  );
}

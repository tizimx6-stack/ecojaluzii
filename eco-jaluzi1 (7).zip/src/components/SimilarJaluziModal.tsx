import React, { useState, useMemo } from 'react';
import { Product, PortfolioProject } from '../types';
import {
  JALUZI_MODELS_BY_CATEGORY,
  ALL_JALUZI_MODELS,
  detectJaluziKeyword
} from '../data/jaluziModels';
import {
  X, CheckCircle2, ShoppingCart, Info, Eye, Layers, Sparkles,
  ArrowRight, Phone, Ruler, ShieldCheck, Check, ChevronRight,
  Filter, Grid, Camera, ChevronLeft
} from 'lucide-react';

interface SimilarJaluziModalProps {
  isOpen: boolean;
  targetProduct: Product | null;
  allProducts: Product[];
  allProjects: PortfolioProject[];
  onClose: () => void;
  onOrderProduct: (product: Product) => void;
  onViewProduct: (product: Product) => void;
}

const CATEGORY_TABS = [
  { key: 'plisse', label: 'Plisse jaluzilar', icon: '🪟' },
  { key: 'combo', label: 'Combo (Zebra) jaluzilar', icon: '☀️' },
  { key: 'roller', label: 'Roller (Rulonli) jaluzilar', icon: '📜' },
  { key: 'wood', label: 'Wood (Yog‘och) jaluzilar', icon: '🪵' },
  { key: 'bambuk', label: 'Bambuk jaluzilar', icon: '🎋' },
  { key: 'dikey', label: 'Dikey vertikal pardalar', icon: '🏛️' },
  { key: 'alyumin', label: 'Alyumin jaluzilar', icon: '🏢' },
  { key: 'rim', label: 'Rim pardalari', icon: '✨' },
];

export default function SimilarJaluziModal({
  isOpen,
  targetProduct,
  allProducts,
  allProjects,
  onClose,
  onOrderProduct,
  onViewProduct,
}: SimilarJaluziModalProps) {
  // Current active jaluzi model
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);
  const [activeCategoryKey, setActiveCategoryKey] = useState<string>('plisse');
  const [selectedColor, setSelectedColor] = useState<string>('');

  // Update active category & product whenever targetProduct opens
  React.useEffect(() => {
    if (targetProduct) {
      const detectedKey = detectJaluziKeyword(targetProduct);
      setActiveCategoryKey(detectedKey);

      // Pick the first matching jaluzi model for this category
      const categoryModels = JALUZI_MODELS_BY_CATEGORY[detectedKey] || ALL_JALUZI_MODELS;
      const initialModel = categoryModels[0] || targetProduct;
      setActiveProduct(initialModel);
      if (initialModel.availableColors && initialModel.availableColors.length > 0) {
        setSelectedColor(initialModel.availableColors[0]);
      }
    }
  }, [targetProduct]);

  // Current category's jaluzi models
  const currentCategoryModels = useMemo(() => {
    return JALUZI_MODELS_BY_CATEGORY[activeCategoryKey] || [];
  }, [activeCategoryKey]);

  // Related installed project photos for this jaluzi category
  const relatedProjects = useMemo(() => {
    return allProjects.filter((proj) => {
      const projText = `${proj.category} ${proj.title} ${proj.description || ''}`.toLowerCase();
      if (activeCategoryKey === 'wood') {
        return projText.includes('wood') || projText.includes('yog‘och') || projText.includes('yogoch');
      }
      if (activeCategoryKey === 'roller') {
        return projText.includes('roller') || projText.includes('rollo') || projText.includes('rulon');
      }
      return projText.includes(activeCategoryKey);
    });
  }, [allProjects, activeCategoryKey]);

  const handleCategoryChange = (key: string) => {
    setActiveCategoryKey(key);
    const models = JALUZI_MODELS_BY_CATEGORY[key] || [];
    if (models.length > 0) {
      setActiveProduct(models[0]);
      if (models[0].availableColors && models[0].availableColors.length > 0) {
        setSelectedColor(models[0].availableColors[0]);
      }
    }
  };

  const handleSelectDifferentJaluzi = (product: Product) => {
    setActiveProduct(product);
    if (product.availableColors && product.availableColors.length > 0) {
      setSelectedColor(product.availableColors[0]);
    }
    // Smooth scroll to top of modal
    const modalContent = document.getElementById('similar-jaluzi-modal-content');
    if (modalContent) {
      modalContent.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  if (!isOpen || !activeProduct) return null;

  const currentTab = CATEGORY_TABS.find(t => t.key === activeCategoryKey) || CATEGORY_TABS[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-brand-charcoal/85 backdrop-blur-md animate-fadeIn">
      {/* Backdrop */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Modal Window Container */}
      <div className="relative bg-brand-cream w-full max-w-6xl rounded-3xl overflow-hidden shadow-2xl border border-brand-emerald/20 z-10 flex flex-col max-h-[94vh]">
        
        {/* Top Header Bar */}
        <div className="p-4 sm:p-5 border-b border-brand-emerald/10 bg-white/95 backdrop-blur-md flex items-center justify-between gap-4 sticky top-0 z-30 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-brand-emerald text-white flex items-center justify-center shadow-md flex-shrink-0">
              <span className="text-xl sm:text-2xl">{currentTab.icon}</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-md bg-amber-400 text-brand-emerald-dark text-[10px] font-extrabold uppercase tracking-wider">
                  O‘xshash Jaluzi Modellari
                </span>
                <span className="text-xs text-brand-emerald font-bold hidden sm:inline-block">
                  • {currentTab.label} ({currentCategoryModels.length} ta model)
                </span>
              </div>
              <h2 className="font-serif text-base sm:text-xl md:text-2xl font-bold text-brand-emerald-dark leading-tight line-clamp-1">
                {currentTab.label} va Montaj Modellari
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 sm:p-2.5 rounded-full bg-brand-beige hover:bg-brand-emerald hover:text-white text-brand-emerald-dark transition-all duration-200 shadow-sm border border-brand-emerald/10 flex-shrink-0"
            title="Yopish"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Modal Content */}
        <div id="similar-jaluzi-modal-content" className="overflow-y-auto p-4 sm:p-6 md:p-8 space-y-6 sm:space-y-8">
          
          {/* CATEGORY SWITCHER TABS */}
          <div className="bg-white/80 p-2 rounded-2xl border border-brand-emerald/15 shadow-2xs">
            <div className="text-[11px] font-extrabold uppercase tracking-wider text-brand-emerald-dark/60 mb-2 px-2 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-brand-emerald" />
              <span>Jaluzi turini almashtirish:</span>
            </div>
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
              {CATEGORY_TABS.map((tab) => {
                const isSelected = tab.key === activeCategoryKey;
                return (
                  <button
                    key={tab.key}
                    type="button"
                    onClick={() => handleCategoryChange(tab.key)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 flex-shrink-0 ${
                      isSelected
                        ? 'bg-brand-emerald text-white shadow-md scale-102'
                        : 'bg-brand-beige/80 text-brand-emerald-dark hover:bg-brand-emerald/10 border border-brand-emerald/10'
                    }`}
                  >
                    <span>{tab.icon}</span>
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* ACTIVE JALUZI SPOTLIGHT CARD */}
          <div className="bg-white rounded-3xl p-5 sm:p-7 border border-brand-emerald/15 shadow-md">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-center">
              
              {/* Image Preview */}
              <div className="lg:col-span-5 relative h-64 sm:h-80 rounded-2xl overflow-hidden bg-brand-charcoal/5 shadow-inner border border-brand-emerald/10 group">
                <img
                  src={activeProduct.image}
                  alt={activeProduct.name}
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    e.currentTarget.src = "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80";
                  }}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute top-3 left-3">
                  <span className="px-3 py-1 rounded-full bg-brand-emerald-dark/95 backdrop-blur-md text-white text-xs font-bold shadow-md flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                    <span>Tanlangan Jaluzi</span>
                  </span>
                </div>
                <div className="absolute bottom-3 right-3">
                  <span className="px-3.5 py-1.5 rounded-xl bg-amber-400 text-brand-emerald-dark text-xs sm:text-sm font-extrabold shadow-lg">
                    {activeProduct.pricePerSqm.toLocaleString()} so‘m/m² dan
                  </span>
                </div>
              </div>

              {/* Info & Details */}
              <div className="lg:col-span-7 space-y-4">
                <div>
                  <div className="text-xs font-bold uppercase tracking-wider text-brand-emerald mb-1 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-brand-emerald"></span>
                    <span>{activeProduct.category}</span>
                  </div>
                  <h3 className="font-serif text-xl sm:text-2xl md:text-3xl font-bold text-brand-emerald-dark leading-snug">
                    {activeProduct.name}
                  </h3>
                  <p className="text-brand-charcoal/75 text-xs sm:text-sm md:text-base font-light mt-2 leading-relaxed">
                    {activeProduct.description}
                  </p>
                </div>

                {/* Material & Specs */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="bg-brand-beige/70 p-3 rounded-xl border border-brand-emerald/10">
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-brand-emerald block mb-0.5">
                      Mato / Materiali:
                    </span>
                    <span className="text-xs sm:text-sm font-bold text-brand-emerald-dark">
                      {activeProduct.material}
                    </span>
                  </div>

                  <div className="bg-brand-beige/70 p-3 rounded-xl border border-brand-emerald/10">
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-brand-emerald block mb-0.5">
                      Kafolat & O‘rnatish:
                    </span>
                    <span className="text-xs sm:text-sm font-bold text-brand-emerald-dark">
                      3 yil to‘liq kafolat + Bepul montaj
                    </span>
                  </div>
                </div>

                {/* Color swatches */}
                {activeProduct.availableColors && activeProduct.availableColors.length > 0 && (
                  <div className="space-y-1.5">
                    <span className="text-xs font-bold text-brand-charcoal/80 flex items-center gap-1.5">
                      <span>Mavjud rang variantlari:</span>
                      {selectedColor && (
                        <span className="text-brand-emerald font-extrabold">({selectedColor})</span>
                      )}
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {activeProduct.availableColors.map((color, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setSelectedColor(color)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                            selectedColor === color
                              ? 'bg-brand-emerald text-white border-brand-emerald shadow-sm scale-105'
                              : 'bg-white text-brand-emerald-dark border-brand-emerald/20 hover:border-brand-emerald'
                          }`}
                        >
                          {color}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Benefits */}
                {activeProduct.benefits && activeProduct.benefits.length > 0 && (
                  <div className="space-y-1 py-1">
                    {activeProduct.benefits.map((b, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs text-brand-emerald-dark/90">
                        <CheckCircle2 className="w-3.5 h-3.5 text-brand-emerald flex-shrink-0" />
                        <span>{b}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* CTA Action Buttons */}
                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOrderProduct(activeProduct);
                    }}
                    className="flex-1 min-w-[200px] py-3.5 px-6 rounded-2xl bg-brand-emerald hover:bg-brand-emerald-light text-white font-bold text-xs sm:text-sm uppercase tracking-wider transition-all duration-300 shadow-lg hover:shadow-xl flex items-center justify-center gap-2 active:scale-95"
                  >
                    <ShoppingCart className="w-4 h-4 text-amber-300" />
                    <span>Shu jaluziga buyurtma berish</span>
                  </button>

                  <a
                    href="tel:+998901234567"
                    className="py-3.5 px-5 rounded-2xl bg-brand-beige hover:bg-brand-emerald/10 text-brand-emerald-dark font-bold text-xs sm:text-sm transition-all border border-brand-emerald/20 flex items-center gap-2"
                  >
                    <Phone className="w-4 h-4 text-brand-emerald" />
                    <span>Usta bilan bog‘lanish</span>
                  </a>
                </div>
              </div>

            </div>
          </div>

          {/* ALL JALUZI MODELS IN THIS CATEGORY */}
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-brand-emerald/10 pb-3">
              <div className="flex items-center gap-2">
                <Grid className="w-5 h-5 text-brand-emerald" />
                <h3 className="font-serif text-lg sm:text-xl font-bold text-brand-emerald-dark">
                  Barcha {currentTab.label} ({currentCategoryModels.length} ta model)
                </h3>
              </div>
              <span className="text-xs text-brand-charcoal/60 hidden sm:inline">
                Kerakli modelni tanlang
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {currentCategoryModels.map((item) => {
                const isCurrent = item.id === activeProduct.id;
                return (
                  <div
                    key={item.id}
                    onClick={() => handleSelectDifferentJaluzi(item)}
                    className={`group relative bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border flex flex-col cursor-pointer ${
                      isCurrent
                        ? 'border-brand-emerald ring-2 ring-brand-emerald shadow-md'
                        : 'border-brand-emerald/15 hover:border-brand-emerald/40 hover:-translate-y-1'
                    }`}
                  >
                    {/* Image */}
                    <div className="relative h-48 overflow-hidden bg-brand-charcoal/10">
                      <img
                        src={item.image}
                        alt={item.name}
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          e.currentTarget.src = "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80";
                        }}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      />
                    </div>

                    {/* Content */}
                    <div className="p-4 sm:p-5 flex flex-col flex-grow justify-between gap-3">
                      <div>
                        <h4 className="font-serif text-base font-bold text-brand-emerald-dark group-hover:text-brand-emerald transition-colors line-clamp-1">
                          {item.name}
                        </h4>
                        <p className="text-brand-charcoal/70 text-xs font-light line-clamp-2 mt-1 leading-relaxed">
                          {item.description}
                        </p>
                      </div>

                      {/* Material tag */}
                      <div className="bg-brand-beige/60 p-2.5 rounded-xl border border-brand-emerald/10 text-[11px] text-brand-emerald-dark font-medium">
                        <span className="font-bold text-brand-emerald">Mato: </span>
                        <span className="line-clamp-1">{item.material}</span>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-2 pt-2 border-t border-brand-emerald/10">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleSelectDifferentJaluzi(item);
                          }}
                          className="flex-1 py-2 px-3 rounded-xl bg-brand-emerald/10 hover:bg-brand-emerald/20 text-brand-emerald-dark text-xs font-bold transition-colors flex items-center justify-center gap-1"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Ko‘rish</span>
                        </button>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onClose();
                            onOrderProduct(item);
                          }}
                          className="flex-1 py-2 px-3 rounded-xl bg-brand-emerald hover:bg-brand-emerald-dark text-white text-xs font-bold transition-colors flex items-center justify-center gap-1 shadow-sm"
                        >
                          <ShoppingCart className="w-3.5 h-3.5" />
                          <span>Buyurtma</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* REAL INSTALLED WORKS FOR THIS JALUZI TYPE */}
          {relatedProjects.length > 0 && (
            <div className="bg-brand-beige/60 rounded-3xl p-5 sm:p-7 border border-brand-emerald/15 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400 text-brand-emerald-dark flex items-center justify-center shadow-sm flex-shrink-0">
                  <Camera className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-serif text-base sm:text-lg font-bold text-brand-emerald-dark">
                    Real o‘rnatilgan montaj suratlari ({currentTab.label})
                  </h4>
                  <p className="text-xs text-brand-charcoal/70">
                    Xonadonlar va kottejlarga o‘rnatilgan tayyor ishlarimiz
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {relatedProjects.slice(0, 6).map((proj) => (
                  <div key={proj.id} className="relative h-48 rounded-2xl overflow-hidden shadow-sm group">
                    <img
                      src={proj.image}
                      alt={proj.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-brand-charcoal/90 via-transparent to-transparent" />
                    <div className="absolute bottom-3 left-3 right-3 text-white">
                      <span className="text-[10px] uppercase font-bold text-amber-300 block">
                        {proj.category}
                      </span>
                      <span className="text-xs font-bold line-clamp-1">
                        {proj.title}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Bottom Trust Banner */}
          <div className="bg-brand-emerald-dark rounded-2xl p-4 sm:p-6 text-brand-cream flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3 text-center sm:text-left">
              <div className="w-10 h-10 rounded-full bg-brand-cream/10 flex items-center justify-center text-amber-300 flex-shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h5 className="font-bold text-sm text-white">
                  O‘lchash va Katalog Bilan Borish — 100% Bepul!
                </h5>
                <p className="text-xs text-brand-cream/70">
                  Mutaxassis barcha mato va jaluzi namunalari bilan uyingizga boradi.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                onClose();
                onOrderProduct(activeProduct);
              }}
              className="py-2.5 px-6 rounded-xl bg-amber-400 hover:bg-amber-300 text-brand-emerald-dark font-bold text-xs uppercase tracking-wider shadow-md transition-all active:scale-95 whitespace-nowrap"
            >
              Bepul o‘lchovga chaqirish
            </button>
          </div>

        </div>
      </div>
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { dbService } from '../services/db';
import { telegramService } from '../services/telegram';
import { Send, CheckCircle2, MessageCircle, PhoneCall, Sparkles, MapPin, ClipboardList } from 'lucide-react';

interface OrderFormProps {
  prefilledNotes?: string;
  onSuccess?: () => void;
}

export default function OrderForm({ prefilledNotes = '', onSuccess }: OrderFormProps) {
  // Form values
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [selectedBlindType, setSelectedBlindType] = useState('Bambuk jaluzi');
  const [customBlindType, setCustomBlindType] = useState('');
  const [numberOfWindows, setNumberOfWindows] = useState<number>(1);
  const [comments, setComments] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  const adminConfig = dbService.getAdminConfig();

  // Prefill name with Telegram Web App user if available
  useEffect(() => {
    const tgUser = telegramService.getTelegramUser();
    if (tgUser) {
      if (tgUser.first_name) {
        setName(tgUser.first_name);
      } else if (tgUser.username) {
        setName(tgUser.username);
      }
    }
  }, []);

  // Prefill notes when provided
  useEffect(() => {
    if (prefilledNotes) {
      setComments(prev => prefilledNotes + (prev ? '\n' + prev : ''));
    }
  }, [prefilledNotes]);

  // Listen to custom prefill-order-notes event
  useEffect(() => {
    const handlePrefillEvent = (e: CustomEvent<string>) => {
      if (e.detail) {
        setComments(prev => e.detail + (prev ? '\n' + prev : ''));
        // Smooth scroll to form
        const formSection = document.querySelector('#order-form');
        if (formSection) {
          formSection.scrollIntoView({ behavior: 'smooth' });
        }
      }
    };
    window.addEventListener('prefill-order-notes' as any, handlePrefillEvent);
    return () => {
      window.removeEventListener('prefill-order-notes' as any, handlePrefillEvent);
    };
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;

    const finalTypeOfBlinds = selectedBlindType === 'Boshqa' ? (customBlindType || 'Boshqa turdagi jaluzi') : selectedBlindType;
    const formattedAddress = address || 'Mijoz manzilni kiritmadi (O‘lchov paytida o‘rganiladi)';
    const formattedComments = comments || 'Izoh yozilmadi';

    // Call local database
    dbService.addOrder({
      name,
      phone,
      address: formattedAddress,
      typeOfBlinds: finalTypeOfBlinds,
      numberOfWindows,
      comments: formattedComments
    });

    const orderPayload = {
      name,
      phone,
      address: formattedAddress,
      typeOfBlinds: finalTypeOfBlinds,
      numberOfWindows,
      comments: formattedComments,
      date: new Date().toISOString().split('T')[0]
    };

    // Send asynchronously to Telegram Bot for Admin
    telegramService.sendOrder(orderPayload, adminConfig);

    // Send confirmation to the client directly if they are inside the Telegram Web App
    const tgUser = telegramService.getTelegramUser();
    if (tgUser && tgUser.id) {
      telegramService.sendCustomerConfirmation(tgUser.id, orderPayload, adminConfig);
    }

    setIsSubmitted(true);
    if (onSuccess) onSuccess();

    // Reset form fields
    setName('');
    setPhone('');
    setAddress('');
    setComments('');
    setNumberOfWindows(1);
    setSelectedBlindType('Bambuk jaluzi');
    setCustomBlindType('');
  };

  return (
    <section id="order-form" className="py-24 bg-brand-beige/20 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-6 sm:px-12">
        <div className="max-w-4xl mx-auto bg-brand-cream rounded-3xl overflow-hidden shadow-2xl border border-brand-emerald/10 grid grid-cols-1 md:grid-cols-12">
          
          {/* Left Block: Direct Call Channels (5 cols) */}
          <div className="md:col-span-5 bg-brand-emerald p-8 sm:p-10 text-brand-cream flex flex-col justify-between">
            <div className="space-y-6">
              <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-brand-cream text-xs font-semibold uppercase tracking-wider w-fit">
                <Sparkles className="w-3.5 h-3.5 text-amber-200" />
                <span>Tezkor bog‘lanish</span>
              </div>

              <div className="space-y-3">
                <h3 className="font-serif text-2xl font-bold text-white">Biz doim aloqadamiz!</h3>
                <p className="text-brand-beige/70 text-xs font-light leading-relaxed">
                  Agar kalkulyator yoki sayt orqali buyurtma berishga qiynalsangiz, quyidagi kanallar orqali to‘g‘ridan-to‘g‘ri murojaat qiling.
                </p>
              </div>

              {/* Contact list details */}
              <div className="space-y-4 pt-6 text-xs font-light">
                {adminConfig.address && (
                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-amber-200 flex-shrink-0 mt-0.5" />
                    <div className="space-y-0.5">
                      <span className="font-bold text-white block">Bizning manzil:</span>
                      <span className="text-brand-beige/80">{adminConfig.address}</span>
                    </div>
                  </div>
                )}

                <div className="flex items-start gap-3">
                  <PhoneCall className="w-5 h-5 text-amber-200 flex-shrink-0 mt-0.5" />
                  <div className="space-y-0.5">
                    <span className="font-bold text-white block">Telefon raqamimiz:</span>
                    <a href={`tel:${adminConfig.phoneNumber}`} className="text-amber-200 font-semibold hover:underline">
                      {adminConfig.phoneNumber}
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Action Buttons */}
            <div className="space-y-3 pt-8 border-t border-white/10 mt-6">
              <a
                href={adminConfig.adminTelegram || adminConfig.telegramLink}
                target="_blank"
                rel="noreferrer"
                className="w-full py-3 bg-white/10 hover:bg-white/20 text-brand-cream font-semibold text-xs tracking-wider uppercase rounded-xl transition-all flex items-center justify-center gap-2 border border-white/10"
              >
                <Send className="w-4 h-4 text-sky-300" />
                <span>Telegram orqali bog‘lanish</span>
              </a>
              <a
                href={`tel:${adminConfig.phoneNumber}`}
                className="w-full py-3 bg-amber-500 hover:bg-amber-600 text-brand-cream font-semibold text-xs tracking-wider uppercase rounded-xl transition-all flex items-center justify-center gap-2 shadow-md"
              >
                <PhoneCall className="w-4 h-4" />
                <span>To‘g‘ridan-to‘g‘ri qo‘ng‘iroq</span>
              </a>
            </div>
          </div>

          {/* Right Block: Dynamic Form (7 cols) */}
          <div className="md:col-span-7 p-8 sm:p-10 flex flex-col justify-center">
            {isSubmitted ? (
              <div className="text-center space-y-6 py-12 flex flex-col items-center">
                <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center shadow-inner animate-bounce">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-serif text-2xl font-bold text-brand-emerald-dark">
                    Buyurtmangiz qabul qilindi!
                  </h3>
                  <p className="text-brand-charcoal/70 text-sm font-light leading-relaxed max-w-sm mx-auto">
                    Muvaffaqiyatli ro‘yxatdan o‘tdi. Tez orada <span translate="no" className="notranslate">ECO JALUZI</span> mutaxassisi siz bilan bog‘lanib, o‘lchov vaqti va tafsilotlarini kelishib oladi.
                  </p>
                </div>

                <button
                  onClick={() => setIsSubmitted(false)}
                  className="px-6 py-2.5 bg-brand-emerald hover:bg-brand-emerald-dark text-brand-cream text-xs font-semibold rounded-lg transition-colors"
                >
                  Yangi buyurtma yuborish
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="border-b border-brand-emerald/10 pb-3 mb-2 flex items-center gap-2">
                  <ClipboardList className="w-5 h-5 text-brand-emerald" />
                  <h4 className="font-serif text-lg font-bold text-brand-emerald-dark">O‘lchovga ariza</h4>
                </div>

                {/* Field: Name */}
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-brand-emerald-dark uppercase tracking-wider block">Sizning ismingiz</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ismingizni kiriting"
                    className="w-full bg-brand-beige border border-brand-emerald/15 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-emerald"
                  />
                </div>

                {/* Field: Phone */}
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-brand-emerald-dark uppercase tracking-wider block">Telefon raqamingiz</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => {
                      // Only allow digits and plus sign
                      const filtered = e.target.value.replace(/[^0-9+]/g, '');
                      setPhone(filtered);
                    }}
                    placeholder="Masalan: +998901234567"
                    className="w-full bg-brand-beige border border-brand-emerald/15 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-emerald"
                  />
                </div>

                {/* Parameters group: type and windows count */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-brand-emerald-dark uppercase tracking-wider block">Jaluzi turi</label>
                    <select
                      value={selectedBlindType}
                      onChange={(e) => setSelectedBlindType(e.target.value)}
                      className="w-full bg-brand-beige border border-brand-emerald/15 rounded-xl px-3 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-brand-emerald"
                    >
                      <option value="Bambuk jaluzi">Bambuk jaluzi</option>
                      <option value="Wood jaluzi">Wood jaluzi</option>
                      <option value="Alyumin gorizontal">Alyumin gorizontal</option>
                      <option value="Honeycomb jaluzi">Honeycomb jaluzi</option>
                      <option value="Roller Jaluzi">Roller Jaluzi</option>
                      <option value="Combo jaluzi">Combo jaluzi</option>
                      <option value="Premium Pardalar (Dikey)">Premium Pardalar (Dikey)</option>
                      <option value="Plisse jaluzi">Plisse jaluzi</option>
                      <option value="Boshqa">Boshqa (Kiritish) ✍️</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-brand-emerald-dark uppercase tracking-wider block">Derazalar soni</label>
                    <input
                      type="number"
                      min="1"
                      max="100"
                      value={numberOfWindows}
                      onChange={(e) => setNumberOfWindows(parseInt(e.target.value) || 1)}
                      className="w-full bg-brand-beige border border-brand-emerald/15 rounded-xl px-3 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-brand-emerald font-semibold"
                    />
                  </div>
                </div>

                {/* Field: Custom blind type description if "Boshqa" selected */}
                {selectedBlindType === 'Boshqa' && (
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-brand-emerald-dark uppercase tracking-wider block">Boshqa jaluzi nomi</label>
                    <input
                      type="text"
                      required
                      value={customBlindType}
                      onChange={(e) => setCustomBlindType(e.target.value)}
                      placeholder="Jaluzi turi nomini kiriting"
                      className="w-full bg-brand-beige border border-brand-emerald/15 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-emerald"
                    />
                  </div>
                )}

                {/* Field: Address */}
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-brand-emerald-dark uppercase tracking-wider block">Manzilingiz</label>
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Masalan: Toshkent, Chilonzor 6-daha, 12-uy"
                    className="w-full bg-brand-beige border border-brand-emerald/15 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-emerald"
                  />
                </div>

                {/* Field: Comments */}
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-brand-emerald-dark uppercase tracking-wider block">Qo‘shimcha izoh yoki so‘rov</label>
                  <textarea
                    rows={3}
                    value={comments}
                    onChange={(e) => setComments(e.target.value)}
                    placeholder="O‘lchov olinishi uchun qulay vaqt yoki o‘lcham tafsilotlari"
                    className="w-full bg-brand-beige border border-brand-emerald/15 rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-brand-emerald resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-4 bg-brand-emerald hover:bg-brand-emerald-dark text-brand-cream text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-md flex items-center justify-center gap-2 hover:scale-[1.01]"
                >
                  <Send className="w-4 h-4 text-amber-200" />
                  <span>Arizani yuborish</span>
                </button>
              </form>
            )}
          </div>

        </div>
      </div>
    </section>
  );
}

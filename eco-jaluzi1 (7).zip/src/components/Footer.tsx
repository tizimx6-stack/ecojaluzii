import React, { useState, useEffect } from 'react';
import Logo from './Logo';
import { dbService } from '../services/db';
import { Phone, MapPin, Send, Instagram, Facebook, ArrowUp, ArrowUpRight } from 'lucide-react';

export default function Footer() {
  const [config, setConfig] = useState(dbService.getAdminConfig());

  useEffect(() => {
    const handleUpdate = () => {
      setConfig(dbService.getAdminConfig());
    };
    window.addEventListener('cms_update', handleUpdate);
    return () => window.removeEventListener('cms_update', handleUpdate);
  }, []);

  const handleScrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (id: string) => {
    const element = document.querySelector(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-brand-charcoal text-brand-cream border-t border-brand-emerald/20">
      
      {/* Top Footer Block */}
      <div className="max-w-7xl mx-auto px-6 sm:px-12 py-16 grid grid-cols-1 md:grid-cols-12 gap-10">
        
        {/* Info Column (5 cols) */}
        <div className="md:col-span-5 space-y-6">
          <Logo size="md" className="brightness-110" />
          <p className="text-brand-beige/75 text-sm font-light leading-relaxed max-w-sm">
            “Har bir derazaga mukammal yechim.” <br />
            <span translate="no" className="notranslate">ECO JALUZI</span> — bu sizning uyingiz, ofisingiz yoki restoraningiz uchun zamonaviy dizayn, yuqori sifatli materiallar va professional montaj kafolatidir.
          </p>

          {/* Social Icons list */}
          <div className="flex items-center gap-3 pt-2">
            <a
              href={config.telegramLink}
              target="_blank"
              rel="noreferrer"
              className="w-10 h-10 rounded-xl bg-white/5 text-brand-cream hover:bg-brand-emerald hover:text-white flex items-center justify-center transition-all shadow-md"
              title="Telegram"
            >
              <Send className="w-4 h-4" />
            </a>
            <a
              href={config.instagramLink}
              target="_blank"
              rel="noreferrer"
              className="w-10 h-10 rounded-xl bg-white/5 text-brand-cream hover:bg-brand-emerald hover:text-white flex items-center justify-center transition-all shadow-md"
              title="Instagram"
            >
              <Instagram className="w-4 h-4" />
            </a>
            {config.facebookLink && (
              <a
                href={config.facebookLink}
                target="_blank"
                rel="noreferrer"
                className="w-10 h-10 rounded-xl bg-white/5 text-brand-cream hover:bg-brand-emerald hover:text-white flex items-center justify-center transition-all shadow-md"
                title="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
            )}
          </div>
        </div>

        {/* Links Column 1: Navigation (3 cols) */}
        <div className="md:col-span-3 space-y-4">
          <h4 className="font-serif text-base font-bold text-amber-200">Tezkor havolalar</h4>
          <ul className="space-y-2.5 text-xs font-light text-brand-beige/80">
            <li>
              <button onClick={() => scrollToSection('#home')} className="hover:text-amber-200 transition-colors flex items-center gap-1">
                <span>Bosh sahifa</span>
                <ArrowUpRight className="w-3 h-3 opacity-0 hover:opacity-100" />
              </button>
            </li>
            <li>
              <button onClick={() => scrollToSection('#products')} className="hover:text-amber-200 transition-colors flex items-center gap-1">
                <span>Mahsulotlarimiz</span>
                <ArrowUpRight className="w-3 h-3 opacity-0 hover:opacity-100" />
              </button>
            </li>
            <li>
              <button onClick={() => scrollToSection('#portfolio')} className="hover:text-amber-200 transition-colors flex items-center gap-1">
                <span>Bizning portfolio</span>
                <ArrowUpRight className="w-3 h-3 opacity-0 hover:opacity-100" />
              </button>
            </li>
            <li>
              <button onClick={() => scrollToSection('#why-us')} className="hover:text-amber-200 transition-colors flex items-center gap-1">
                <span>Nega biz?</span>
                <ArrowUpRight className="w-3 h-3 opacity-0 hover:opacity-100" />
              </button>
            </li>
          </ul>
        </div>

        {/* Links Column 2: Direct Contacts (4 cols) */}
        <div className="md:col-span-4 space-y-4">
          <h4 className="font-serif text-base font-bold text-amber-200">Bog‘lanish</h4>
          <ul className="space-y-4 text-xs font-light text-brand-beige/80">
            
            {/* Address */}
            {config.address && (
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-brand-emerald-light flex-shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-white block mb-0.5">Bosh ofis manzili:</span>
                  <span>{config.address}</span>
                </div>
              </li>
            )}

            {/* Phone */}
            <li className="flex items-start gap-2.5">
              <Phone className="w-4 h-4 text-brand-emerald-light flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-white block mb-0.5">Ish vaqti va telefon:</span>
                <a href={`tel:${config.phoneNumber}`} className="text-amber-200 font-bold text-sm hover:underline block">
                  {config.phoneNumber}
                </a>
                <span className="text-[10px] text-brand-beige/50">Har kuni: 09:00 - 20:00</span>
              </div>
            </li>

          </ul>
        </div>

      </div>

      {/* Bottom Legal Copyright Block */}
      <div className="border-t border-white/5 py-8 bg-brand-charcoal">
        <div className="max-w-7xl mx-auto px-6 sm:px-12 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-light text-brand-beige/40">
          <div>
            &copy; {new Date().getFullYear()} <span translate="no" className="notranslate">ECO JALUZI</span>. Barcha huquqlar himoyalangan.
          </div>
          
          {/* Scroll to Top floating button alignment */}
          <button
            onClick={handleScrollToTop}
            className="px-4 py-2 bg-white/5 hover:bg-brand-emerald text-brand-cream hover:text-white rounded-xl border border-white/10 transition-all flex items-center gap-2 group"
          >
            <span>Tepaga qaytish</span>
            <ArrowUp className="w-3.5 h-3.5 transition-transform group-hover:-translate-y-0.5" />
          </button>
        </div>
      </div>

    </footer>
  );
}

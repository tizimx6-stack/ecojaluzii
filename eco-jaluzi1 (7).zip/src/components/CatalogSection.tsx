import React, { useState } from 'react';
import { Product } from '../types';
import {
  FolderOpen, Sparkles, ShoppingCart, Info, ArrowRight,
  CheckCircle2, Layers, ShieldCheck, Sun, Zap, Award
} from 'lucide-react';

interface CatalogSectionProps {
  onSelectProduct: (product: Product) => void;
  onOrderProduct: (product: Product) => void;
}

export interface CatalogCategoryItem {
  id: string;
  name: string;
  subtitle: string;
  tag: string;
  image: string;
  material: string;
  colors: string[];
  pricePerSqm: number;
  description: string;
  benefits: string[];
  recommendedRooms: string;
  features: string[];
}

export const CATALOG_ITEMS: CatalogCategoryItem[] = [
  {
    id: 'cat-bambuk',
    name: 'Bambuk jaluzi',
    subtitle: '100% tabiiy va ekologik toza bambuk matosi',
    tag: '100% Tabiiy',
    image: '/catalog_bambuk.jpg',
    material: 'Tabiiy bosilgan bambuk chiviqlari va iplari',
    colors: ['Tabiiy bambuk', 'Karamel', 'Qovurilgan yong‘oq', 'Zaytun'],
    pricePerSqm: 270000,
    description: 'Bambuk jaluzilari tabiiy bambuk chiviqlarining ingichka qilib to‘qilishi orqali tayyorlanadi. Xonaga sharqona osoyishtalik, ekologik toza muhit va shinamlik olib kiradi.',
    benefits: [
      '100% ekologik toza tabiiy xomashyo',
      'Yengil vazn va derazaga yuk tushirmaslik',
      'Havoni toza aylantiruvchi tabiiy nafas olish',
      'Noyob sharqona va zamonaviy stil'
    ],
    recommendedRooms: 'Choyxona, dam olish zonalari, yozgi ayvon, shinam uylar',
    features: ['Tabiiy bambuk', 'Ekologik toza', 'Nafis to‘qima']
  },
  {
    id: 'cat-wood',
    name: 'Wood jaluzi',
    subtitle: 'Yog‘och fakturali zamonaviy eko dizayn',
    tag: 'Eko Trend',
    image: '/catalog_wood.jpg',
    material: 'Yuqori sifatli qattiq yog‘och va Faux Wood',
    colors: ['Yengil dub', 'Tik daraxti', 'Kulrang yog‘och', 'Tabiiy qarag‘ay'],
    pricePerSqm: 330000,
    description: 'Wood kolleksiyasi zamonaviy interyerda tabiiylik va issiq muhit yaratish uchun eng yaxshi tanlovdir. Lamellarning tabiiy tolali chiziqlari ko‘zni quvontiradi.',
    benefits: [
      'Tabiiy daraxtning nozik tekstura va hidi',
      'Quyoshda qizib ketmaydigan issiqlik izolyatsiyasi',
      'O‘zgacha mebel bilan ajoyib uyg‘unlik',
      'Mustahkam zanglamas metall ichki karniz'
    ],
    recommendedRooms: 'Kabinet, kottejlar, mehmonxonalar, studiyalar',
    features: ['Eko dizayn', 'Yog‘och tekstura', 'Oliy sifat']
  },
  {
    id: 'cat-alyumini',
    name: 'Alyumin gorizontal',
    subtitle: 'Namlikka o‘ta chidamli yengil metall lamellar',
    tag: 'Chidamli & Amaliy',
    image: '/catalog_alyumin.jpg',
    material: 'Anodlangan yengil va elastik alyuminiy (16mm / 25mm)',
    colors: ['Kumush metallik', 'Mat oq', 'Oltinrang', 'Qora grafit'],
    pricePerSqm: 130000,
    description: 'Namlik, bug‘ va harorat o‘zgarishlaridan aslo qo‘rqmaydigan mustahkam gorizontal alyuminiy jaluzilar. Yuvish va tozalash eng oson bo‘lgan tizim.',
    benefits: [
      '100% suv, namlik va issiqlikka chidamlilik',
      'Yong‘inga mutlaqo xavfsiz material',
      'Nam shimgich bilan soniyalarda tozalanish',
      'Kichik va ixcham boshqaruv'
    ],
    recommendedRooms: 'Oshxona, vanna xonasi, basseyn, tibbiyot muassasalari, ofislar',
    features: ['100% suvga chidamli', 'Yong‘inga xavfsiz', 'Hamyonbop narx']
  },
  {
    id: 'cat-honeycomb',
    name: 'Honeycomb jaluzi',
    subtitle: 'Asalari uyasi shaklidagi termo-himoya',
    tag: 'Energiya tejamkor',
    image: '/catalog_honeycomb.jpg',
    material: 'Ikki qavatli termo-izolyatsion uyali mato',
    colors: ['Oq marvarid', 'Qaymoqrang', 'Kofe', 'Och kulrang'],
    pricePerSqm: 310000,
    description: 'Honeycomb (uyali) jaluzilar xona haroratini barqaror ushlash uchun havo qatlamini hosil qiladi. Yozda issiqdan, qishda esa sovuqdan himoyalab, konditsioner va isitish xarajatlarini kamaytiradi.',
    benefits: [
      'Yuqori darajadagi issiqlik va sovuq izolyatsiyasi',
      'Ovozni yutish va akustikani yaxshilash',
      'Ip va arqonlar ichkarida yashiringan toza ko‘rinish',
      'Yumshoq diffuz yorug‘lik taratish'
    ],
    recommendedRooms: 'Yotoqxona, kabinet, quyosh tushadigan janubiy derazalar',
    features: ['Termo-izolyatsiya', 'Shovqin kamaytiruvchi', 'Ko‘rinmas iplar']
  },
  {
    id: 'cat-roller',
    name: 'Roller Jaluzi',
    subtitle: 'Minimalist rulonli parda tizimi (Rollo)',
    tag: 'Klassik & Qulay',
    image: '/catalog_rollo.jpg',
    material: 'Yevropa matosi (Blackout & Dimout)',
    colors: ['Oq', 'Kulrang', 'Antratsit', 'Qum rang', 'Bej'],
    pricePerSqm: 150000,
    description: 'Ixcham va minimalist rulonli jaluzi. To‘g‘ridan-to‘g‘ri deraza oynasi romiga yoki teshigiga o‘rnatiladi. Xonani 100% qorong‘ulashtirish yoki yumshoq yorug‘lik filtri yaratish uchun ideal yechim.',
    benefits: [
      '100% Blackout (quyosh nurini to‘liq to‘sish)',
      'Ixcham dizayn — deraza tokchasini bo‘sh qoldiradi',
      'Suv va namlikka bardoshli maxsus modellar',
      'Oddiy va ishonchli zanjirli mexanizm'
    ],
    recommendedRooms: 'Yotoqxona, uy kinoteatri, oshxona, balkon',
    features: ['100% Blackout', 'Ixcham o‘lcham', 'Namlikka chidamli']
  },
  {
    id: 'cat-combo',
    name: 'Combo jaluzi',
    subtitle: 'Kun va tunning zamonaviy geometrik uyg‘unligi',
    tag: 'Qulaylik',
    image: '/catalog_combo.jpg',
    material: 'Zich tolali kompozit parda matosi',
    colors: ['Binafsharang', 'Qumli bej', 'Och marvarid', 'Shokolad'],
    pricePerSqm: 190000,
    description: 'Combo tizimi shaffof va qalin qismlarni o‘zaro harakatlantirish orqali yorug‘lik darajasini millimetrigacha sozlash imkonini yaratadi.',
    benefits: [
      'Deraza romiga moslashuvchan o‘lcham',
      'Ranglarning juda keng assortimenti'
    ],
    recommendedRooms: 'Oshxona, yotoqxona, bolalar xonasi, ish joylari',
    features: ['Kun-tun nazorati', 'Qulay mexanizm', 'Zamonaviy naqshlar']
  },
  {
    id: 'cat-premium-pardalar',
    name: 'Premium Pardalar (Dikey)',
    subtitle: 'Dikey va hashamatli dizaynerlik pardalari',
    tag: 'Elegentlik',
    image: '/catalog_dikey.jpg',
    material: 'Turkiya va Yevropa baxmal, tyul va ipak matolari',
    colors: ['Zumrad', 'Krem-oltin', 'Royal Ko‘k', 'Qaymoq'],
    pricePerSqm: 320000,
    description: 'Dikey parda va klassik pardalarning eng so‘nggi Yevropa dizayn tendensiyalari asosidagi uyg‘unligi. Xonaga boy, saroyona va o‘zgacha joziba baxsh etadi.',
    benefits: [
      'Nafis to‘kiluvchi vertikal burmalar va chiziqlar',
      'Yuqori sifatli va uzoq vaqt shaklini yo‘qotmaydigan mato',
      'Shaxsiy dizaynerlik eskizlari asosida tikish',
      'Mukammal to‘liq to‘plam va sifat kafolati'
    ],
    recommendedRooms: 'Mehmonxonalar, to‘yxonalar, qabul zallari, shinam uylar',
    features: ['Individual dizayn', 'Turkiya matosi', 'Saroyona joziba']
  },
  {
    id: 'cat-plisse',
    name: 'Plisse Jaluzi',
    subtitle: 'Buklanuvchi akkordeon shaklidagi nafis mato',
    tag: 'Zamonaviy Yechim',
    image: '/catalog_plisse.jpg',
    material: 'Maxsus teksturali gofre mato',
    colors: ['Oq', 'Krem', 'Platina', 'Grafit', 'Oltinrang'],
    pricePerSqm: 290000,
    description: 'Plisse jaluzilari istalgan nostandart shakldagi oynalar (uchburchak, trapezoid, arka, mansarda) uchun mukammal mos keladi. Pastdan yuqoriga yoki yuqoridan pastga erkin ochiladi.',
    benefits: [
      'Yuqoridan va pastdan ikki tomonlama ochilish',
      'Har qanday murakkab shakldagi derazalar uchun mos',
      'Deraza romiga zich yopishib turadi',
      'Yuvish va tozalash imkoniyati mavjud'
    ],
    recommendedRooms: 'Mansardalar, vitrajlar, lodjiya, zamonaviy kvartiralar',
    features: ['Top-Down / Bottom-Up', 'Arka va trapez oynalar', 'Yengil profil']
  }
];

export default function CatalogSection({ onSelectProduct, onOrderProduct }: CatalogSectionProps) {
  const [selectedItem, setSelectedItem] = useState<CatalogCategoryItem>(CATALOG_ITEMS[0]);

  const handleOpenProduct = (item: CatalogCategoryItem) => {
    const prod: Product = {
      id: item.id,
      name: item.name,
      description: item.description,
      material: item.material,
      availableColors: item.colors,
      pricePerSqm: item.pricePerSqm,
      image: item.image,
      category: item.name,
      benefits: item.benefits,
      installationInfo: `Tavsiya etiladigan xonalar: ${item.recommendedRooms}. O‘lcham olish va yetkazib berish xizmatlari mavjud.`
    };
    onSelectProduct(prod);
  };

  const handleOrder = (item: CatalogCategoryItem) => {
    const prod: Product = {
      id: item.id,
      name: item.name,
      description: item.description,
      material: item.material,
      availableColors: item.colors,
      pricePerSqm: item.pricePerSqm,
      image: item.image,
      category: item.name,
      benefits: item.benefits,
      installationInfo: `Tavsiya etiladigan xonalar: ${item.recommendedRooms}`
    };
    onOrderProduct(prod);
  };

  return (
    <section id="catalog" className="py-20 bg-brand-cream border-b border-brand-emerald/10 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-12">
        {/* Header Section */}
        <div className="text-center max-w-3xl mx-auto mb-14 flex flex-col items-center gap-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-brand-emerald/10 text-brand-emerald text-xs font-bold uppercase tracking-widest border border-brand-emerald/15">
            <FolderOpen className="w-4 h-4" />
            <span>JALUZILAR KATALOGI</span>
          </div>

          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-brand-emerald-dark">
            Barcha turdagi jaluzi va parda modellari
          </h2>
          <div className="h-1 w-16 bg-brand-emerald rounded-full" />
          <p className="text-brand-charcoal/70 font-light max-w-2xl text-sm sm:text-base leading-relaxed">
            Quyidagi katalogdan o‘zingizga ma’qul bo‘lgan jaluzi turini tanlang. Har bir modelning xususiyatlari, namunalari va afzalliklari bilan batafsil tanishishingiz mumkin.
          </p>
        </div>

        {/* Jaluzi Categories Horizontal/Grid Selector Tabs */}
        <div className="mb-12">
          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-4 gap-2.5 sm:gap-3.5">
            {CATALOG_ITEMS.map((item, index) => {
              const isSelected = selectedItem.id === item.id;
              return (
                <button
                  key={item.id}
                  id={`catalog-tab-${item.id}`}
                  onClick={() => setSelectedItem(item)}
                  className={`group relative p-2.5 sm:p-3 rounded-2xl text-left transition-all duration-300 border flex flex-col justify-between gap-2.5 overflow-hidden ${
                    isSelected
                      ? 'bg-brand-emerald text-brand-cream shadow-lg border-brand-emerald scale-[1.02] ring-2 ring-brand-emerald/30'
                      : 'bg-brand-beige/80 hover:bg-brand-beige text-brand-emerald-dark border-brand-emerald/10 hover:border-brand-emerald/30 shadow-sm hover:shadow-md'
                  }`}
                >
                  <div className="flex items-center gap-2.5 w-full">
                    <div className="w-12 h-12 rounded-xl overflow-hidden flex-shrink-0 bg-white border border-brand-emerald/20 shadow-sm">
                      <img
                        src={item.image}
                        alt={item.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500 brightness-[1.03] contrast-[1.03]"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <span
                          className={`text-[9px] font-bold font-mono px-1.5 py-0.2 rounded ${
                            isSelected
                              ? 'bg-white/20 text-white'
                              : 'bg-brand-emerald/10 text-brand-emerald'
                          }`}
                        >
                          {String(index + 1).padStart(2, '0')}
                        </span>
                      </div>
                      <h4
                        className={`font-serif text-xs font-bold tracking-tight truncate ${
                          isSelected ? 'text-white' : 'text-brand-emerald-dark'
                        }`}
                      >
                        {item.name}
                      </h4>
                    </div>
                  </div>

                  <p
                    className={`text-[10px] font-light line-clamp-1 ${
                      isSelected ? 'text-brand-cream/80' : 'text-brand-charcoal/60'
                    }`}
                  >
                    {item.subtitle}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Active Selected Jaluzi Interactive Showcase Card */}
        <div className="bg-brand-beige rounded-3xl border border-brand-emerald/15 shadow-xl overflow-hidden transition-all duration-500">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-0">
            {/* Left Image Showcase */}
            <div className="lg:col-span-6 relative min-h-[320px] sm:min-h-[420px] lg:min-h-[500px] overflow-hidden bg-brand-cream group">
              <img
                src={selectedItem.image}
                alt={selectedItem.name}
                referrerPolicy="no-referrer"
                onError={(e) => {
                  e.currentTarget.src = 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=800&q=80';
                }}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 brightness-[1.02] contrast-[1.02]"
              />
            </div>

            {/* Right Detailed Information */}
            <div className="lg:col-span-6 p-6 sm:p-8 lg:p-10 flex flex-col justify-between gap-6">
              <div className="space-y-4">
                {/* Title & Badge */}
                <div className="space-y-1">
                  <div className="inline-flex items-center gap-1.5 text-xs font-bold text-brand-emerald uppercase tracking-wider">
                    <Layers className="w-4 h-4" />
                    <span>Katalog toifasi</span>
                  </div>
                  <h3 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold text-brand-emerald-dark">
                    {selectedItem.name}
                  </h3>
                  <p className="text-xs sm:text-sm text-brand-charcoal/60 font-medium">
                    {selectedItem.subtitle}
                  </p>
                </div>

                {/* Description */}
                <p className="text-brand-charcoal/80 text-xs sm:text-sm leading-relaxed font-light">
                  {selectedItem.description}
                </p>

                {/* Material & Specs */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div className="p-3.5 bg-brand-cream rounded-2xl border border-brand-emerald/10">
                    <span className="text-[10px] font-bold text-brand-charcoal/50 uppercase block mb-1">
                      Materiali
                    </span>
                    <span className="text-xs font-bold text-brand-emerald-dark">
                      {selectedItem.material}
                    </span>
                  </div>
                  <div className="p-3.5 bg-brand-cream rounded-2xl border border-brand-emerald/10">
                    <span className="text-[10px] font-bold text-brand-charcoal/50 uppercase block mb-1">
                      Mos xonalar
                    </span>
                    <span className="text-xs font-bold text-brand-emerald-dark line-clamp-1">
                      {selectedItem.recommendedRooms}
                    </span>
                  </div>
                </div>

                {/* Benefits List */}
                <div className="space-y-2 pt-1">
                  <span className="text-[11px] font-bold text-brand-emerald-dark uppercase tracking-wider block">
                    Asosiy afzalliklari:
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {selectedItem.benefits.map((benefit, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-brand-charcoal/80 font-light">
                        <CheckCircle2 className="w-4 h-4 text-brand-emerald flex-shrink-0 mt-0.5" />
                        <span>{benefit}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-brand-emerald/10 flex flex-col sm:flex-row items-center gap-3">
                <button
                  id={`catalog-details-btn-${selectedItem.id}`}
                  onClick={() => handleOpenProduct(selectedItem)}
                  className="w-full sm:flex-1 py-3.5 px-5 rounded-2xl text-xs sm:text-sm font-bold text-brand-emerald-dark bg-brand-emerald/10 hover:bg-brand-emerald/20 transition-all flex items-center justify-center gap-2"
                >
                  <Info className="w-4 h-4" />
                  <span>Batafsil ma'lumot</span>
                </button>

                <button
                  id={`catalog-order-btn-${selectedItem.id}`}
                  onClick={() => handleOrder(selectedItem)}
                  className="w-full sm:flex-1 py-3.5 px-5 rounded-2xl text-xs sm:text-sm font-bold text-white bg-brand-emerald-dark hover:bg-brand-emerald transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2"
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span>O‘lcham olishga buyurtma</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

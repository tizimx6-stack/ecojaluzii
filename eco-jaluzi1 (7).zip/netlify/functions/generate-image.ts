import { GoogleGenAI } from "@google/genai";

export const handler = async (event: any) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const { prompt, baseImage } = body;

    let finalPrompt = prompt || "premium high-quality window blinds shade shutters curtain zebra jaluzi in a modern room";

    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey) {
      const ai = new GoogleGenAI({ apiKey });
      try {
        const imageResponse = await ai.models.generateContent({
          model: 'gemini-3.1-flash-lite-image',
          contents: {
            parts: [
              { text: "Photorealistic premium high-quality: " + finalPrompt }
            ]
          },
          config: {
            imageConfig: {
              aspectRatio: "1:1",
              imageSize: "1K"
            }
          }
        });

        let generatedBase64 = "";
        if (imageResponse.candidates && imageResponse.candidates[0]?.content?.parts) {
          for (const part of imageResponse.candidates[0].content.parts) {
            if (part.inlineData) {
              generatedBase64 = part.inlineData.data;
              break;
            }
          }
        }

        if (generatedBase64) {
          return { statusCode: 200, headers, body: JSON.stringify({ image: "data:image/jpeg;base64," + generatedBase64 }) };
        }
      } catch (e: any) {
        console.warn("Gemini image generation in function failed, falling back to pollinations...", e.message);
      }
    }

    // Fallback to pollinations.ai
    const seed = Math.floor(Math.random() * 1000000);
    const pollinationsUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent("Highly realistic professional interior design featuring premium window blinds/jaluzi: " + finalPrompt)}?seed=${seed}&width=800&height=800&nologo=true&model=flux`;

    return { statusCode: 200, headers, body: JSON.stringify({ image: pollinationsUrl }) };
  } catch (error: any) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: "Dizayn yaratishda xatolik yuz berdi." }) };
  }
};

# ECO JALUZI Project Instructions & Rules

## Design & Stability Directives
1. **Preserve UI/UX & Design**: Never modify, redesign, or alter the visual layout, colors, fonts, animations, or styling of the application unless explicitly requested by the user.
2. **Netlify Compatibility**:
   - All backend API requests (`/api/ai-chat`, `/api/generate-image`) are mapped to Netlify Serverless Functions in `netlify/functions/`.
   - Never remove or break `netlify.toml` redirects.
3. **Asset & Image Referencing**:
   - Video feed items use Instagram Reel posters (`poster`) with `referrerPolicy="no-referrer"`.
   - All `<img>` tags referencing external image hosts (e.g. `i.ibb.co`) must retain `referrerPolicy="no-referrer"` to avoid `ERR_HTTP2_PROTOCOL_ERROR`.
   - Favicons are served from `/public/favicon.ico` and `/public/favicon.svg`.

import urllib.request
import re

pages = [
    ("https://ibb.co/Xrgy3b1R", "Bolalar honasi"),
    ("https://ibb.co/RGZWRVw5", "Dikey jaluzi"),
    ("https://ibb.co/M574dLHJ", "Eco Jaluz"),
    ("https://ibb.co/KcBtwLSX", "Jaluz tanlash"),
    ("https://ibb.co/SXf30VkD", "Rolo jaluzi"),
    ("https://ibb.co/gbvVH2DK", "Oshxona"),
    ("https://ibb.co/S7rtYZQB", "Quyosh nuridan"),
    ("https://ibb.co/cKSptPbC", "Sifati va kafolati")
]

results = []
for url, name in pages:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
        html = urllib.request.urlopen(req, timeout=5).read().decode('utf-8')
        # Look for og:image or direct img src
        og = re.findall(r'<meta property="og:image" content="([^"]+)"', html)
        img = re.findall(r'<img [^>]*src="(https://i\.ibb\.co/[^"]+)"', html)
        results.append(f"{name} ({url}):\n  OG: {og}\n  IMG: {img}\n")
    except Exception as e:
        results.append(f"{name} ({url}): ERROR {e}\n")

with open("scrape_out.txt", "w") as f:
    f.writelines(results)
print("DONE")

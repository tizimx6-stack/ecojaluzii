import { GoogleGenAI } from "@google/genai";

export default async function handler(req: any, res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { prompt } = req.body || {};
    const finalPrompt = prompt || "premium high-quality window blinds shade shutters curtain zebra jaluzi in a modern room";

    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey) {
      const ai = new GoogleGenAI({ apiKey });
      try {
        const imageResponse = await ai.models.generateContent({
          model: 'gemini-3.1-flash-lite-image',
          contents: {
            parts: [
              { text: "Photorealistic premium high-quality: " + finalPrompt }
            ]
          },
          config: {
            imageConfig: {
              aspectRatio: "1:1",
              imageSize: "1K"
            }
          }
        });

        let generatedBase64 = "";
        if (imageResponse.candidates && imageResponse.candidates[0]?.content?.parts) {
          for (const part of imageResponse.candidates[0].content.parts) {
            if (part.inlineData) {
              generatedBase64 = part.inlineData.data;
              break;
            }
          }
        }

        if (generatedBase64) {
          return res.status(200).json({ image: "data:image/jpeg;base64," + generatedBase64 });
        }
      } catch (e: any) {
        console.warn("Gemini image generation in vercel function failed, falling back to pollinations...", e.message);
      }
    }

    // Fallback image using Pollinations
    const encoded = encodeURIComponent(finalPrompt);
    const fallbackUrl = `https://image.pollinations.ai/prompt/${encoded}?width=800&height=800&nologo=true`;
    return res.status(200).json({ image: fallbackUrl });
  } catch (error: any) {
    console.error("Vercel generate-image error:", error);
    return res.status(500).json({ error: error.message || 'Image generation failed' });
  }
}

import { GoogleGenAI } from "@google/genai";

export default async function handler(req: any, res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { message, image, history, lang, productsContext } = req.body || {};

    const apiKey = process.env.GEMINI_API_KEY;
    let ai: GoogleGenAI | null = null;
    if (apiKey) {
      ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build'
          }
        }
      });
    }

    if (ai) {
      let langInstruction = "";
      if (lang === 'ru') {
        langInstruction = "Разговаривайте с клиентом исключительно на русском языке. Давайте полные, вежливые, подробные и структурированные ответы.";
      } else if (lang === 'en') {
        langInstruction = "Speak with the client exclusively in English. Provide full, polite, detailed, and structured answers.";
      } else {
        langInstruction = "Mijoz bilan FAQAT O'ZBEK TILIDA gaplashing. Har doim to'liq, muloyim, batafsil, tushunarli va chiroyli tartiblangan javob bering.";
      }

      const systemInstruction = `Siz "ECO JALUZI" kompaniyasining aqlli, do'stona, samimiy va professional virtual AI maslahatchisiz.

ASOSIY QOIDALAR VA VAZIFALAR:
1. Salomlashish va odob-axloq:
   - Agar mijoz salom bersa, albatta salomiga iliq va samimiy alik oling, o'zingiz ham salom berib, hol-ahvol so'rang va qanday yordam bera olishingizni so'rang.
2. To'liq va batafsil javob berish:
   - Mijozning har qanday savoliga har tomonlama to'liq, tushunarli, qiziqarli va professional darajada batafsil javob bering.
3. NARXLARNI HISOBLAMASLIK QOIDASI (QAT'IY TALAB):
   - Siz sun'iy intellekt sifatida mijozga qat'iy narx hisob-kitob qilmang.
   - Narxlar tanlangan mato toifasi, zichligi, mexanizm turi va deraza o'lchamiga qarab individual hisoblanishini tushuntiring.
   - Mutaxassisimiz barcha mato namunalari (katalog) bilan mijoz xonadoniga borib, aniq o'lchov olib, yakuniy smetani hisoblab berishini ayting.
4. QAT'IY TAQIQLANGAN SO'Z ("bepul"):
   - "Bepul", "bepulga", "besplatno", "free" so'zlarini UMUMAN ISHLATMANG!
5. Aloqa ma'lumotlari:
   - Telefon: +998 94 000 99 77
   - Telegram: @eco_jaluzi
6. Foydalanuvchi tanlagan til qoidasi:
   - ${langInstruction}

MAHSULOTLAR VA KATALOG MA'LUMOTLARI:
${productsContext || "Rollo, Combo (Kun-tun), Dikey pardalar, Plisse, Alyumin gorizontal, Tabiiy Yog'och (Wood), Bambuk va Print foto jaluzilar mavjud."}`;

      const contents: any[] = [];
      if (history && Array.isArray(history)) {
        for (const msg of history) {
          contents.push({
            role: msg.role === 'user' ? 'user' : 'model',
            parts: [{ text: msg.text }]
          });
        }
      }

      const userParts: any[] = [{ text: message || "Assalomu alaykum" }];
      if (image && typeof image === 'string' && image.startsWith('data:image/')) {
        const matches = image.match(/^data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+);base64,(.+)$/);
        if (matches && matches.length === 3) {
          userParts.push({
            inlineData: {
              mimeType: matches[1],
              data: matches[2]
            }
          });
        }
      }

      contents.push({
        role: 'user',
        parts: userParts
      });

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents,
        config: {
          systemInstruction: {
            parts: [{ text: systemInstruction }]
          },
          temperature: 0.7
        }
      });

      const replyText = response.text || "Assalomu alaykum! Sizga qanday yordam bera olaman?";
      return res.status(200).json({ reply: replyText });
    }

    // Fallback response if GEMINI_API_KEY is not set
    let fallbackText = "Assalomu alaykum! ECO JALUZI virtual maslahatchisi xizmatingizda. Sizga qaysi turdagi jaluzi (Rollo, Combo, Dikey, Plisse, Yog'och yoki Alyumin) bo'yicha ma'lumot kerak? Savolingizni bering, batafsil tushuntirib beraman!";
    if (lang === 'ru') {
      fallbackText = "Здравствуйте! Виртуальный консультант ECO JALUZI к вашим услугам. Какой вид жалюзи вас интересует (Rollo, Combo, Dikey, Plisse, Деревянные или Алюминиевые)? Задайте ваш вопрос, я подробно отвечу!";
    } else if (lang === 'en') {
      fallbackText = "Hello! ECO JALUZI virtual assistant at your service. Which type of blinds are you interested in (Rollo, Combo, Dikey, Plisse, Wood, or Aluminum)? Feel free to ask!";
    }

    return res.status(200).json({ reply: fallbackText });
  } catch (error: any) {
    console.error("Vercel ai-chat error:", error);
    return res.status(500).json({ error: error.message || 'Internal server error' });
  }
}

import urllib.request
import re

pages = [
    ("https://ibb.co/Xrgy3b1R", "Bolalar honasi"),
    ("https://ibb.co/RGZWRVw5", "Dikey jaluzi"),
    ("https://ibb.co/M574dLHJ", "Eco Jaluz"),
    ("https://ibb.co/KcBtwLSX", "Jaluz tanlash"),
    ("https://ibb.co/SXf30VkD", "Rolo jaluzi"),
    ("https://ibb.co/gbvVH2DK", "Oshxona"),
    ("https://ibb.co/S7rtYZQB", "Quyosh nuridan"),
    ("https://ibb.co/cKSptPbC", "Sifati va kafolati")
]

for url, name in pages:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
        html = urllib.request.urlopen(req).read().decode('utf-8')
        # find all image urls in the html
        matches = re.findall(r'https://[a-zA-Z0-9\.\-/_\\]+\.(?:png|jpg|jpeg)', html)
        print("PAGE:", url, name)
        for m in set(matches):
            print("   ->", m)
    except Exception as e:
        print("ERROR:", url, e)
